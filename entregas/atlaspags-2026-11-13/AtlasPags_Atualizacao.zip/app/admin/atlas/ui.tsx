'use client';
import {useCallback,useEffect,useState} from 'react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {BRAVUS_PAYMENT_ORIGIN} from '@/lib/checkout-brand';
type Configuration={configured:boolean;webhookConfigured:boolean;testMode:boolean|null};
export default function Settings(){
 const [config,setConfig]=useState<Configuration|null>(null),[token,setToken]=useState(''),[secret,setSecret]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),[saved,setSaved]=useState(false),[copied,setCopied]=useState(false);
 const webhookUrl=BRAVUS_PAYMENT_ORIGIN+'/api/webhooks/atlas';
 const load=useCallback(async()=>{const r=await fetch('/api/admin/atlas',{cache:'no-store'}),d=await r.json();if(!r.ok)throw Error(d.error);setConfig(d);},[]);
 useEffect(()=>{load().catch(()=>setError('Não foi possível carregar a configuração.'));},[load]);
 return <main className="pay-shell"><div className="pay-brand"><img src="/assets/bravus-logo.jpg" alt="Bravus Brasil"/><strong>BRAVUS BRASIL</strong></div><section className="pay-card"><h1>Atlas Pags</h1><p>{config?.configured?'Chave cadastrada com segurança.':'Cadastre a chave secreta gerada em Integrações → API e Webhooks na Atlas Pags.'}</p>
 {config?.configured&&<p className={config.testMode?'error':'success'} role="status">{config.testMode?'Ambiente de teste: as cobranças são simuladas e não movimentam dinheiro.':'Chave de produção cadastrada.'}</p>}
 <form onSubmit={async e=>{e.preventDefault();if(busy)return;setBusy(true);setError('');setSaved(false);try{const r=await fetch('/api/admin/atlas',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token,...(secret.trim()?{webhookSecret:secret}:{})})}),d=await r.json();if(!r.ok)throw Error(d.error);setToken('');setSecret('');await load();setSaved(true);}catch(e){setError((e as Error).message);}finally{setBusy(false);}}}>
 <label className="field"><span>Chave secreta da API Atlas</span><Input type="password" autoComplete="new-password" value={token} onChange={e=>setToken(e.target.value)} placeholder="atlas_sk_live_…" required maxLength={1024} disabled={busy}/></label>
 <label className="field"><span>Segredo do webhook (opcional)</span><Input type="password" autoComplete="new-password" value={secret} onChange={e=>setSecret(e.target.value)} placeholder="whsec_…" maxLength={1024} disabled={busy}/></label>
 <p className="muted">A validação consulta a lista de cobranças sem gerar pagamento. Deixe o segredo do webhook vazio para manter o já cadastrado.</p>
 <Button className="action" disabled={busy||config===null}>{busy?'Validando…':'Validar e salvar credenciais'}</Button></form>
 {error&&<p className="error" role="alert">{error}</p>}{saved&&<p className="success" role="status">Credenciais salvas. Selecione Usar Atlas Pags no painel de gateways ou inclua a Atlas nas regras automáticas.</p>}
 <h2>Confirmação automática dos pagamentos</h2><p>Na Atlas, cadastre um endpoint com este endereço e os eventos transaction.pending, transaction.paid, transaction.failed, transaction.expired, transaction.refunded e transaction.chargeback. Copie o segredo desse endpoint para o campo acima.</p>
 <label className="field"><span>URL do webhook Atlas</span><Input value={webhookUrl} readOnly onFocus={e=>e.target.select()}/></label><Button type="button" variant="outline" onClick={async()=>{try{await navigator.clipboard.writeText(webhookUrl);setCopied(true);}catch{setError('Selecione e copie o endereço do webhook.');}}}>{copied?'Endereço copiado!':'Copiar URL do webhook'}</Button>
 <p className="muted">{config?.webhookConfigured?'Segredo do webhook cadastrado.':'Sem webhook, o pagamento continua disponível para consulta na página do PIX.'}</p>
 <p className="muted">A Atlas opera apenas com PIX e exige nome, e-mail e CPF/CNPJ do comprador. BRAVUS e Bio Camisas compartilham esta configuração.</p><a href="/admin/gateways">Voltar ao painel de gateways</a></section></main>;
}
