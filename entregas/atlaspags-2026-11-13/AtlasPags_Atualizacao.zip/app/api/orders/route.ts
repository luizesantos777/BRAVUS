import {createPayment} from '@/lib/create-payment';
import {fallbackPolicy,gatewayForAmount,gatewaySelection} from '@/lib/gateways';
import {readFallbackRequest,runPaymentFallback} from '@/lib/payment-fallback';
import {InputError as FirebotInputError} from '@/lib/firebot';
import {InputError} from '@/lib/poseidon';
import {publicGuard,json,readBody,database,validId} from '@/lib/payments';
import {checkoutBrandForRequest,checkoutResponse} from '@/lib/checkout-brand';
export const dynamic='force-dynamic';
export async function POST(req:Request){return checkoutResponse(req,await createOrder(req));}
async function createOrder(req:Request){
 const deny=await publicGuard(req);if(deny)return deny;
 try{
  const b=await readBody(req);
  b.checkoutOrigin=checkoutBrandForRequest(req).origin;
  if(!Number.isSafeInteger(b.amount)||b.amount<600||b.amount>300000||typeof b.requestId!=='string'||!validId(b.requestId))return json({error:'Informe um valor entre R$ 6,00 e R$ 3.000,00.'},400);
  if(b.sellerName!==undefined&&(typeof b.sellerName!=='string'||b.sellerName.trim().length<2||b.sellerName.trim().length>100||/[\x00-\x1f<>]/.test(b.sellerName)))return json({error:'Informe o nome do vendedor (2 a 100 caracteres).'},400);
  if(b.paymentMethod&&b.paymentMethod!=='pix'&&b.paymentMethod!=='credit_card')return json({error:'Forma de pagamento indisponível.'},400);
  b.sellerName=typeof b.sellerName==='string'?b.sellerName.trim():null;
  const policy=await fallbackPolicy(),selection=await gatewaySelection(),ip=req.headers.get('cf-connecting-ip')||'';
  const saved=await readFallbackRequest(b.requestId);
  // Recover the recorded chain even after the owner changes routing or disables fallback.
  if(saved)return await runPaymentFallback(b,ip,policy,{provider:selection.provider,selection,byTicket:false},saved);
  const previous=await database().prepare('SELECT provider,seller_name FROM payment_orders WHERE request_id=?').bind(b.requestId).first();
  if(previous){
   if(previous.seller_name!==(b.sellerName||null))return json({error:'Este pedido já foi iniciado com outro vendedor.'},409);
   const provider=previous.provider==='beehive_card'?'beehive':previous.provider;
   if((previous.provider==='beehive_card')!==(b.paymentMethod==='credit_card'))return json({error:'Este pedido já foi iniciado com outra forma de pagamento.'},409);
   return await createPayment(b,provider,ip);
  }
  // Ticket rules and fallback apply to PIX. Card links remain with Beehive.
  const route=b.paymentMethod==='credit_card'?{provider:selection.provider,selection,byTicket:false,available:true}:await gatewayForAmount(b.amount,policy,selection);
  if(!route.available)return json({error:'As gateways estão temporariamente indisponíveis. Aguarde alguns minutos ou contate o vendedor.',code:'GATEWAYS_UNAVAILABLE'},409);
  if(typeof b.provider==='string'&&b.provider!==route.provider)return json({error:'A forma de pagamento foi atualizada. Confira os dados e tente novamente.',code:'GATEWAY_CHANGED'},409);
  if(b.paymentMethod==='credit_card'&&route.provider!=='beehive')return json({error:'Forma de pagamento indisponível.'},400);
  if(policy.enabled&&b.paymentMethod!=='credit_card')return await runPaymentFallback(b,ip,policy,route,null);
  return await createPayment(b,route.provider,ip);
 }catch(error){
  if(error instanceof InputError||error instanceof FirebotInputError)return json({error:error.message},400);
  return json({error:'Não foi possível gerar o link. Recupere o mesmo pedido para conferir o resultado.'},503);
 }
}
