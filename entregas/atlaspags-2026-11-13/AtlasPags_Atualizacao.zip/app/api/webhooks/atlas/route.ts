import {atlasWebhook} from '@/lib/atlas-webhook';
export const dynamic='force-dynamic';
export const POST=atlasWebhook;
