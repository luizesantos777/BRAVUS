import {panelGuard} from '@/lib/gateway-access';
import {json,readBody,credentials} from '@/lib/payments';
import {gatewaySelection,gateways,isGateway,selectGateway,fallbackPolicy,saveFallbackPolicy,gatewayHealth,lastGatewaySwitch} from '@/lib/gateways';
export const dynamic='force-dynamic';
export async function GET(req:Request){const denied=await panelGuard(req);if(denied)return denied;try{
 const selection=await gatewaySelection();
 const providers=await Promise.all(gateways.map(async id=>{const health=await gatewayHealth(id);return {id,configured:!!await credentials(id),pausedUntil:health?.epoch===selection.epoch?health.failedUntil:null};}));
 return json({active:selection.provider,providers,fallback:await fallbackPolicy(),lastSwitch:await lastGatewaySwitch()});
}catch{return json({error:'Não foi possível carregar as gateways. Atualize a página.'},503);}}
export async function POST(req:Request){const denied=await panelGuard(req);if(denied)return denied;try{
 const b=await readBody(req);
 if(b.fallback!==undefined){
  if(b.provider!==undefined)return json({error:'Salve a gateway padrão e as regras separadamente.'},400);
  try{return json({fallback:await saveFallbackPolicy(b.fallback)});}catch(error){return json({error:(error as Error).message},400);}
 }
 if(!isGateway(b.provider))return json({error:'Escolha uma gateway válida.'},400);
 if(!await selectGateway(b.provider))return json({error:'Cadastre as credenciais desta gateway antes de ativá-la.'},409);
 return json({active:b.provider});
}catch{return json({error:'Não foi possível salvar. Atualize a página para conferir a configuração.'},503);}}
