import {readBeehive} from '@/lib/beehive';
import {readElevaPayment} from '@/lib/eleva';
import {gestaoStatus} from '@/lib/gestao';
import {json,database,buck,validId} from '@/lib/payments';
export const dynamic='force-dynamic';
export async function GET(_req:Request,ctx:{params:Promise<{id:string}>}){const {id}=await ctx.params;if(!validId(id))return json({error:'Pagamento não encontrado.'},404);try{const db=database();const row=await db.prepare('SELECT id,request_id,amount,state,pix_code,qr,checked_at,provider,transaction_id,seller_name FROM payment_orders WHERE id=?').bind(id).first();if(!row||!row.pix_code&&row.state!=='paid')return json({error:'Pagamento não encontrado ou indisponível.'},404);
if(row.provider==='beehive')return await readBeehive(row);
if(row.provider==='eleva')return await readElevaPayment(row);
if(row.provider==='gestao'){
 if(row.state!=='paid'&&row.checked_at<Date.now()-30000){const claim=await db.prepare('UPDATE payment_orders SET checked_at=? WHERE id=? AND checked_at=?').bind(Date.now(),id,row.checked_at).run();if(claim.meta?.changes){try{if(await gestaoStatus(row)){row.state='paid';await db.prepare('UPDATE payment_orders SET state=? WHERE id=?').bind('paid',id).run();}}catch{}}}
 return json({amount:row.amount,paid:row.state==='paid',code:row.state==='paid'?null:row.pix_code,qrUrl:row.state==='paid'?null:row.qr,provider:'gestao',canVerify:true});
}
if(['poseidon','firebot'].includes(row.provider))return json({amount:row.amount,paid:false,code:row.pix_code,qrUrl:row.qr,provider:row.provider,canVerify:false});
if(row.state!=='paid'&&row.checked_at<Date.now()-30000){const claim=await db.prepare('UPDATE payment_orders SET checked_at=? WHERE id=? AND checked_at=?').bind(Date.now(),id,row.checked_at).run();if(claim.meta?.changes){try{const response=await buck('/v1/transactions/external_id/'+id);if(response.ok){const {data}=await response.json() as any;if(data?.status==='paid'&&data.total_amount===row.amount){row.state='paid';await db.prepare('UPDATE payment_orders SET state=? WHERE id=?').bind('paid',id).run();}}}catch{}}}
return json({amount:row.amount,paid:row.state==='paid',code:row.state==='paid'?null:row.pix_code,...(typeof row.qr==='string'&&row.qr.startsWith('data:image/')?{qrUrl:row.state==='paid'?null:row.qr}:{qr:row.state==='paid'?null:row.qr})});}catch{return json({error:'Pagamento temporariamente indisponível. Tente novamente.'},503);}}
