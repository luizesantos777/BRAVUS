import {syncCard} from '@/lib/beehive-card';
import {database,json,validId} from '@/lib/payments';
import {syncBeehive} from '@/lib/beehive';
export const dynamic='force-dynamic';
export async function POST(req:Request){try{
 const raw=await req.text();if(raw.length>65536)return json({error:'Payload inválido.'},413);
 const event=JSON.parse(raw),ref=event?.data?.externalRef;
 if(event.type!=='transaction'||typeof ref!=='string'||!validId(ref))return json({received:true});
 const db=database(),row=await db.prepare('SELECT * FROM payment_orders WHERE request_id=?').bind(ref).first();
 if(!row||!['beehive','beehive_card'].includes(row.provider)||!row.transaction_id||row.transaction_id.startsWith('link:')||String(event.objectId)!==row.transaction_id||row.state==='paid')return json({received:true});
 const claim=await db.prepare('UPDATE payment_orders SET checked_at=? WHERE id=? AND checked_at<?').bind(Date.now(),row.id,Date.now()-30000).run();
 // A webhook is only a notification: confirm identity, amount and paid status via authenticated GET.
 if(claim.meta?.changes&&!await (row.provider==='beehive_card'?syncCard(row):syncBeehive(row)))return json({error:'Consulta indisponível.'},503);
 return json({received:true});
 }catch{return json({error:'Não foi possível confirmar o evento.'},503);}}
