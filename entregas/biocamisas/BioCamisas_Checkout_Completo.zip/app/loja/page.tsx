import Shop from './ui';
export const metadata={title:'Bravus Brasil | Camisas UV, polos e personalizadas',description:'Camisas UV e polos em modelos individuais de pesca, agro, country, fé e para a sua equipe. Monte seu pedido Bravus Brasil.',robots:{index:true,follow:true},referrer:'no-referrer'};
export default function Page(){return <Shop/>;}
