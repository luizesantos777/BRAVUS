import type { CheckoutBrand } from '@/lib/checkout-brand';

export default function CheckoutMark({ brand }: { brand: CheckoutBrand }) {
  return brand.id === 'biocamisas'
    ? <span className="checkout-monogram" aria-hidden="true">BC</span>
    : <img src="/assets/bravus-logo.jpg" alt={brand.name} />;
}
