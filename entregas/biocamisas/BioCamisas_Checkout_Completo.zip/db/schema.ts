import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const settings = sqliteTable('payment_settings', { key: text('key').primaryKey(), value: text('value').notNull() });
export const orders = sqliteTable('payment_orders', {
 id: text('id').primaryKey(), requestId: text('request_id').notNull().unique(), amount: integer('amount').notNull(),
 provider: text('provider').notNull().default('buckpay'), payloadHash: text('payload_hash'), transactionId: text('transaction_id'),
 sellerName: text('seller_name'), state: text('state').notNull(), pixCode: text('pix_code'), qr: text('qr'), createdAt: integer('created_at').notNull(), checkedAt: integer('checked_at').notNull().default(0)
});
