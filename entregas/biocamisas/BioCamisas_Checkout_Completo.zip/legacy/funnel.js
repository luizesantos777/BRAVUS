const steps=[
  {
    "n": "01",
    "id": "etapa-1",
    "title": "Primeira resposta",
    "hint": "Quando o cliente chegar pelo anúncio.",
    "text": "Olá! 👋 Seja bem-vindo(a) à Bravus Brasil 🇧🇷☀️\n\nVi que você se interessou pelas nossas camisas UV. Temos modelos Brasil, Texas, Pesca, Fé e devoção, Infantil, Agro e temáticos no catálogo. 👕\n\n👕 R$ 39,90 a unidade, ou o kit com 4 camisas por R$ 99,89.\n\n🔥 A partir de 5 camisas, consigo manter o valor promocional de R$ 24,97 por unidade.\n\n🚚 Comprando 8 camisas ou mais, você ganha frete expresso gratuito!\n\nQual opção você prefere?"
  },
  {
    "n": "02",
    "id": "etapa-2",
    "title": "Oferta",
    "hint": "Envie a oferta separadamente e, após a resposta, continue com a mensagem abaixo.",
    "messages": [
      {
        "label": "OFERTA · VALORES E QUANTIDADES",
        "text": "👕 R$ 39,90 a unidade, ou o kit com 4 camisas por R$ 99,89.\n\n🔥 A partir de 5 camisas, consigo manter o valor promocional de R$ 24,97 por unidade.\n\n🚚 Comprando 8 camisas ou mais, você ganha frete expresso gratuito!\n\nQual opção você prefere?"
      },
      {
        "label": "ENTENDER O USO",
        "text": "Perfeito! 👕🔥\nNossas camisas são ideais para quem fica exposto ao sol, como pesca, agro, trabalho e dia a dia.\n\nVocê vai usar mais para trabalho, pesca ou passeio?"
      }
    ]
  },
  {
    "n": "03",
    "id": "etapa-3",
    "title": "Modelagem e tamanho",
    "hint": "Guia na p. 46; tabelas nas pp. 47–53; cores na p. 54. Somente as sete tabelas atualizadas: adultos até G8 e infantil cavada de 2 a 16.",
    "text": "Vamos conferir a modelagem e o tamanho antes de fechar? 👕\n\nO catálogo tem tabelas próprias para camisa manga longa, manga curta, cavada, baby look, polo longa, moletom e infantil cavada.\n\nMe diga qual modelo você quer e o tamanho que costuma usar. Compare uma peça que veste bem, aberta e sem esticar, com a tabela correspondente. Se precisar, envie as medidas de peito, comprimento e manga que eu te ajudo. 😊"
  },
  {
    "n": "04",
    "id": "etapa-4",
    "title": "Enviar catálogo",
    "hint": "Camisas em detalhe: pp. 15–45. Brasil 15–22; Texas 23–30; Pesca 31–38; Fé 39–41; Infantil 42–43; Agro 44–45.",
    "text": "Aqui está nosso catálogo completo da Bravus Brasil! 👕🤠\n\nhttps://pagamento.bravuspix.shop/catalogo/bravus-completo.pdf?v=76f3cdae87\n\nMe envie a foto ou o nome do modelo, a cor, o tamanho e a quantidade. Vou conferir os detalhes e a disponibilidade para você. 😊"
  },
  {
    "n": "05",
    "id": "etapa-5",
    "title": "Confirmar modelo e cor",
    "hint": "Consulte a cartela da p. 54 e confirme as opções do modelo escolhido.",
    "text": "Me envie o nome ou a foto de cada modelo, a cor, a modelagem e a quantidade. 👕\n\nVocê quer manga longa, curta, cavada ou com capuz? Prefere gola redonda ou gola com zíper? Vou conferir as opções para a peça escolhida antes de confirmar. 😊"
  },
  {
    "n": "06",
    "id": "etapa-6",
    "title": "Passar valor",
    "hint": "Quando o cliente perguntar o preço.",
    "text": "R$ 39,90 a unidade, ou o kit com 4 camisas por R$ 99,89.\n\nA partir de 5 camisas, consigo manter o valor promocional de R$ 24,97 por unidade.\n\n🚚 Comprando 8 camisas ou mais, você ganha frete expresso gratuito!\n\nQual opção você prefere?"
  },
  {
    "n": "07",
    "id": "etapa-7",
    "title": "Fechamento",
    "hint": "Quando o cliente decidir o que vai levar. Pedidos com 8 camisas ou mais têm frete expresso gratuito. Para menos de 8, consulte o frete pelo CEP.",
    "text": "Perfeito! ✅📦\n\nVou registrar seu pedido em nosso sistema para darmos continuidade à sua compra.\n\n📋 Me envie os seguintes dados para o cadastro:\n\n👤 Nome completo:\n📱 Telefone:\n📍 CEP:\n🏠 Endereço:\n🔢 Número:\n📌 Bairro:\n🌆 Cidade/Estado:\n\n✅ Assim que receber seus dados, seguimos para a confirmação do pedido e pagamento."
  },
  {
    "n": "08",
    "id": "etapa-8",
    "title": "Pagamento",
    "hint": "Depois de receber os dados, gere o PIX no checkout e envie o link de pagamento ao cliente.",
    "payment": true
  },
  {
    "n": "09",
    "id": "etapa-9",
    "title": "Se o cliente sumir",
    "hint": "Após algumas horas sem resposta sobre os modelos.",
    "text": "Oi! Tudo bem? 😊\nPassando para saber se conseguiu ver os modelos que te enviei.\n\nSe precisar, posso te ajudar a escolher o tamanho ideal. 👕☀️"
  },
  {
    "n": "📏",
    "id": "tabelas",
    "title": "Tabelas de medidas",
    "hint": "Copie os links ou abra as tabelas na seção de medidas abaixo. Use a modelagem do pedido. As tabelas adultas vão até G8; infantil cavada de 2 a 16.",
    "text": "📏 Confira nossas tabelas de medidas atualizadas!\n\nCamisa manga longa: https://pagamento.bravuspix.shop/catalogo/tabelas/camisa_longa.png\nCamisa manga curta: https://pagamento.bravuspix.shop/catalogo/tabelas/manga_curta.png\nCamisa cavada: https://pagamento.bravuspix.shop/catalogo/tabelas/cavada.png\nPolo manga longa: https://pagamento.bravuspix.shop/catalogo/tabelas/polo_longa.png\nMoletom: https://pagamento.bravuspix.shop/catalogo/tabelas/moletom.png\nBaby look feminina: https://pagamento.bravuspix.shop/catalogo/tabelas/baby_look.png\nInfantil cavada (2 a 16): https://pagamento.bravuspix.shop/catalogo/tabelas/infantil_cavada.png\n\nCompare com uma peça sua, estendida e sem esticar, e me diga os tamanhos de cada modelo. 😊"
  },
  {
    "n": "+",
    "id": "outras-linhas",
    "title": "Ofertas do catálogo",
    "hint": "Preços por produto. Confirme modelos, tamanhos e estoque. Frete expresso gratuito apenas para pedidos com 8 camisas ou mais; consulte frete dos demais pedidos.",
    "text": "Confira as ofertas do nosso catálogo Bravus! 🤠\n\n👕 Camisas: R$ 39,90 a unidade; kit com 4 por R$ 99,89. A partir de 5 camisas, R$ 24,97 por unidade.\n🚚 Comprando 8 camisas ou mais, você ganha frete expresso gratuito!\n\n👔 Polos: R$ 39,90 a unidade ou 4 por R$ 99,89.\n👖 Jeans flare: R$ 59,90 a unidade ou 3 por R$ 119,90.\n🧢 Bonés country e pesca: R$ 25,00 a unidade ou 4 por R$ 60,00.\n🤠 Chapéus country: R$ 39,90 a unidade ou 4 por R$ 99,90. A partir de 5 chapéus, R$ 24,98 por unidade.\n👢 Botas texanas e country: 1 par por R$ 99,89 ou 2 pares por R$ 179,89. A partir de 3 pares, R$ 59,93 por par (40% de desconto sobre o valor original de R$ 99,89 por par).\n✨ Fivela com canivete de brinde: R$ 189,99.\n🔪 Canivetes: R$ 39,90 a unidade ou 4 por R$ 99,89.\n\nhttps://pagamento.bravuspix.shop/catalogo/bravus-completo.pdf?v=76f3cdae87\n\nQuais modelos você gostou? Me envie as fotos para eu conferir os tamanhos e a disponibilidade. 😊"
  },
  {
    "n": "↗",
    "id": "acompanhamento",
    "title": "Acompanhamento",
    "hint": "Depois que o pedido estiver registrado.",
    "text": "Seu pedido já foi registrado. Vou te enviar também nosso link de acompanhamento, por onde você poderá acompanhar as atualizações do seu pedido até a entrega. 📦\n\n🔗 https://rastreio-brasilraiz.netlify.app/\n\nQualquer dúvida durante o processo, pode falar com a gente por aqui! 👊"
  }
];
let current=0,timer;const $=id=>document.getElementById(id);
const icon='<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="12" height="13" rx="2"/><path d="M15 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h3"/></svg>';
function notify(text){$('toast').textContent=text;$('toast').classList.add('visible');clearTimeout(timer);timer=setTimeout(()=>$('toast').classList.remove('visible'),2800)}
const instagramUrl='https://www.instagram.com/bravusvta_brasil?igsh=MWx0dW42OXBjMGhqOQ==&igsi=MWx0dW42OXBjMGhqOQ==';
document.querySelector('[data-copy-instagram]')?.addEventListener('click',async e=>{const button=e.currentTarget;try{await navigator.clipboard.writeText(instagramUrl);button.innerHTML='<span aria-hidden="true">✓</span> Instagram <b>copiado</b>';notify('Link do Instagram copiado. Agora é só colar no WhatsApp.');setTimeout(()=>{button.innerHTML='<span aria-hidden="true">◎</span> Instagram <b>copiar</b>'},2200)}catch{const area=document.createElement('textarea');area.value=instagramUrl;area.style.position='fixed';area.style.opacity='0';document.body.append(area);area.select();document.execCommand('copy');area.remove();notify('Link do Instagram copiado. Agora é só colar no WhatsApp.')}})
const companyDetails="N. Loja Comercio de Roupas LTDA\nCNPJ: 16.881.650/0001-23\nAv. Marechal Tito, nº 864, São Miguel Paulista, São Paulo - SP\nCEP: 08010-090";
const addressButton=document.createElement('button');addressButton.className='quick-address';addressButton.type='button';addressButton.dataset.copyAddress='';addressButton.setAttribute('aria-label','Copiar razão social, CNPJ e endereço da empresa');addressButton.innerHTML='<span aria-hidden="true">⌖</span> DADOS DA EMPRESA <b>copiar</b>';addressButton.title=companyDetails;document.querySelector('.quick-actions')?.append(addressButton);
addressButton.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(companyDetails)}catch{const area=document.createElement('textarea');area.value=companyDetails;area.style.position='fixed';area.style.opacity='0';document.body.append(area);area.select();document.execCommand('copy');area.remove()}addressButton.innerHTML='<span aria-hidden="true">✓</span> DADOS DA EMPRESA <b>copiado</b>';notify('Dados da empresa copiados. Agora é só colar no WhatsApp.');setTimeout(()=>{addressButton.innerHTML='<span aria-hidden="true">⌖</span> DADOS DA EMPRESA <b>copiar</b>'},2200)})
async function copyText(text,button,pre){try{if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(text)}else{const area=document.createElement('textarea');area.value=text;area.style.position='fixed';area.style.opacity='0';document.body.append(area);area.select();const ok=document.execCommand('copy');area.remove();if(!ok)throw Error('copy failed')}button.textContent='✓ Copiado!';notify('Mensagem copiada. Agora é só colar no WhatsApp.');setTimeout(()=>button.innerHTML=icon+'Copiar mensagem',2000)}catch{const range=document.createRange();range.selectNodeContents(pre);const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);notify('Selecionei a mensagem. Use a opção Copiar do seu dispositivo.')}}
function card(label,text){const article=document.createElement('article');article.className='card';const top=document.createElement('div');top.className='card-top';const name=document.createElement('span');name.textContent=label;const button=document.createElement('button');button.className='copy';button.innerHTML=icon+'Copiar mensagem';button.setAttribute('aria-label','Copiar mensagem: '+label);const pre=document.createElement('p');pre.className='message';pre.textContent=text;button.addEventListener('click',()=>copyText(pre.textContent,button,pre));top.append(name,button);article.append(top,pre);$('messages').append(article);return pre}
steps.forEach(s=>{const a=document.createElement('a');a.href='#'+s.id;a.className='step';const number=document.createElement('span');number.className='num';number.textContent=s.n;const label=document.createElement('span');label.textContent=s.title;a.append(number,label);$('steps').append(a)});
function render(){const index=steps.findIndex(s=>location.hash==='#'+s.id);current=index<0?0:index;const s=steps[current];document.querySelectorAll('.step').forEach((a,i)=>{if(i===current)a.setAttribute('aria-current','step');else a.removeAttribute('aria-current')});$('stage-label').textContent=s.payment?'ETAPA 08':s.n==='↗'?'PÓS-VENDA':'ETAPA '+s.n;$('stage-title').textContent=s.title;$('position').textContent=(current+1)+' / '+steps.length;$('stage-hint').textContent=s.hint;$('messages').replaceChildren();if(s.payment){const checkout=document.createElement('div');checkout.className='payment-checkout';const details=document.createElement('div');const title=document.createElement('strong');title.textContent='Checkout para pedido manual';const hint=document.createElement('p');hint.textContent='Abra o checkout para cadastrar o pedido.';details.append(title,hint);const link=document.createElement('a');link.className='checkout-link';link.href='https://pagamento.bravuspix.shop/checkout';link.target='_blank';link.rel='noopener noreferrer';link.textContent='Abrir checkout ↗';link.setAttribute('aria-label','Abrir checkout para pedido manual em nova aba');checkout.append(details,link);$('messages').append(checkout);const note=document.createElement('p');note.className='instruction';note.textContent='Gere o PIX no checkout e envie o link de pagamento ao cliente.';$('messages').append(note);const field=document.createElement('fieldset');field.className='variant';field.innerHTML='<legend>Tipo de pedido</legend><label><input type="radio" name="pedido" value="envio" checked> Pronta entrega</label><label><input type="radio" name="pedido" value="producao"> Personalizado / produção</label>';$('messages').append(field);const texts={envio:'Após a confirmação do pagamento, seguimos com a preparação do pedido e encaminhamos o rastreio quando houver o envio. 📦🚚',producao:'Após a confirmação do pagamento e aprovação da arte, seguimos com a produção. O rastreio será enviado após a postagem. 📦🚚'};const pre=card('APÓS A CONFIRMAÇÃO DO PAGAMENTO',texts.envio);field.addEventListener('change',e=>{pre.textContent=texts[e.target.value]})}else if(s.messages){s.messages.forEach(m=>card(m.label,m.text))}else card('MENSAGEM PARA O CLIENTE',s.text);$('prev').disabled=current===0;$('next').disabled=current===steps.length-1;}
$('prev').addEventListener('click',()=>{if(current>0)location.hash=steps[current-1].id});$('next').addEventListener('click',()=>{if(current<steps.length-1)location.hash=steps[current+1].id});window.addEventListener('hashchange',render);render();
document.addEventListener('click',e=>{const link=e.target instanceof Element?e.target.closest('a[href="/checkout"]'):null;if(link)link.href='https://pagamento.bravuspix.shop/checkout'},true);
document.querySelectorAll('a[href^="https://pagamento.bravuspix.shop/checkout"]').forEach(link=>{link.href='https://pagamento.bravuspix.shop/checkout'});
