export const newShirts=[
  {
    "id": "catalogo-texas-0",
    "name": "Texas Country · Branco",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-texas-0.webp",
    "color": "Branco",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-texas-1",
    "name": "Texas Country · Cinza claro",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-texas-1.webp",
    "color": "Cinza claro",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-texas-2",
    "name": "Texas Country · Preto",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-texas-2.webp",
    "color": "Preto",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-texas-3",
    "name": "Texas Country · Verde militar",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-texas-3.webp",
    "color": "Verde militar",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-texas-4",
    "name": "Texas Country · Azul marinho",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-texas-4.webp",
    "color": "Azul marinho",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-texas-5",
    "name": "Texas Country · Bege",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-texas-5.webp",
    "color": "Bege",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-texas-6",
    "name": "Texas Country · Amarelo",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-texas-6.webp",
    "color": "Amarelo",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-texas-7",
    "name": "Texas Country · Vermelho",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-texas-7.webp",
    "color": "Vermelho",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-texas-8",
    "name": "Texas Country · Vinho",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-texas-8.webp",
    "color": "Vinho",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-texas-9",
    "name": "Texas Country · Roxo",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-texas-9.webp",
    "color": "Roxo",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-texas-10",
    "name": "Texas Country · Laranja",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-texas-10.webp",
    "color": "Laranja",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-texas-11",
    "name": "Texas Country · Turquesa",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-texas-11.webp",
    "color": "Turquesa",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-agro-0",
    "name": "Agro • Fazenda e Campo · Branco",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-agro-0.webp",
    "color": "Branco",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-agro-1",
    "name": "Agro • Fazenda e Campo · Cinza claro",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-agro-1.webp",
    "color": "Cinza claro",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-agro-2",
    "name": "Agro • Fazenda e Campo · Preto",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-agro-2.webp",
    "color": "Preto",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-agro-3",
    "name": "Agro • Fazenda e Campo · Verde militar",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-agro-3.webp",
    "color": "Verde militar",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-agro-4",
    "name": "Agro • Fazenda e Campo · Azul marinho",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-agro-4.webp",
    "color": "Azul marinho",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-agro-5",
    "name": "Agro • Fazenda e Campo · Bege",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-agro-5.webp",
    "color": "Bege",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-agro-6",
    "name": "Agro • Fazenda e Campo · Amarelo",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-agro-6.webp",
    "color": "Amarelo",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-agro-7",
    "name": "Agro • Fazenda e Campo · Vermelho",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-agro-7.webp",
    "color": "Vermelho",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-agro-8",
    "name": "Agro • Fazenda e Campo · Vinho",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-agro-8.webp",
    "color": "Vinho",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-agro-9",
    "name": "Agro • Fazenda e Campo · Roxo",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-agro-9.webp",
    "color": "Roxo",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-agro-10",
    "name": "Agro • Fazenda e Campo · Laranja",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-agro-10.webp",
    "color": "Laranja",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-agro-11",
    "name": "Agro • Fazenda e Campo · Turquesa",
    "category": "Agro & Country",
    "image": "/assets/shirts/catalogo-agro-11.webp",
    "color": "Turquesa",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-pesca-0",
    "name": "Pesca • Rio e Natureza · Branco",
    "category": "Pesca",
    "image": "/assets/shirts/catalogo-pesca-0.webp",
    "color": "Branco",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-pesca-1",
    "name": "Pesca • Rio e Natureza · Cinza claro",
    "category": "Pesca",
    "image": "/assets/shirts/catalogo-pesca-1.webp",
    "color": "Cinza claro",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-pesca-2",
    "name": "Pesca • Rio e Natureza · Preto",
    "category": "Pesca",
    "image": "/assets/shirts/catalogo-pesca-2.webp",
    "color": "Preto",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-pesca-3",
    "name": "Pesca • Rio e Natureza · Verde militar",
    "category": "Pesca",
    "image": "/assets/shirts/catalogo-pesca-3.webp",
    "color": "Verde militar",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-pesca-4",
    "name": "Pesca • Rio e Natureza · Azul marinho",
    "category": "Pesca",
    "image": "/assets/shirts/catalogo-pesca-4.webp",
    "color": "Azul marinho",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-pesca-5",
    "name": "Pesca • Rio e Natureza · Bege",
    "category": "Pesca",
    "image": "/assets/shirts/catalogo-pesca-5.webp",
    "color": "Bege",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-pesca-6",
    "name": "Pesca • Rio e Natureza · Amarelo",
    "category": "Pesca",
    "image": "/assets/shirts/catalogo-pesca-6.webp",
    "color": "Amarelo",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-pesca-7",
    "name": "Pesca • Rio e Natureza · Vermelho",
    "category": "Pesca",
    "image": "/assets/shirts/catalogo-pesca-7.webp",
    "color": "Vermelho",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-pesca-8",
    "name": "Pesca • Rio e Natureza · Vinho",
    "category": "Pesca",
    "image": "/assets/shirts/catalogo-pesca-8.webp",
    "color": "Vinho",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-pesca-9",
    "name": "Pesca • Rio e Natureza · Roxo",
    "category": "Pesca",
    "image": "/assets/shirts/catalogo-pesca-9.webp",
    "color": "Roxo",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-pesca-10",
    "name": "Pesca • Rio e Natureza · Laranja",
    "category": "Pesca",
    "image": "/assets/shirts/catalogo-pesca-10.webp",
    "color": "Laranja",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "catalogo-pesca-11",
    "name": "Pesca • Rio e Natureza · Turquesa",
    "category": "Pesca",
    "image": "/assets/shirts/catalogo-pesca-11.webp",
    "color": "Turquesa",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "polo-0",
    "name": "Polo TXC · Branco",
    "category": "Polos",
    "image": "/assets/shirts/polo-0.webp",
    "color": "Branco",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho.",
    "variants": {
      "Branco": "/assets/shirts/polo-0.webp",
      "Preto": "/assets/shirts/polo-1.webp",
      "Azul marinho": "/assets/shirts/polo-2.webp",
      "Vermelho": "/assets/shirts/polo-3.webp",
      "Verde militar": "/assets/shirts/polo-4.webp",
      "Bege": "/assets/shirts/polo-5.webp",
      "Cinza claro": "/assets/shirts/polo-6.webp",
      "Azul celeste": "/assets/shirts/polo-7.webp",
      "Azul royal": "/assets/shirts/polo-8.webp",
      "Rosa pink": "/assets/shirts/polo-9.webp"
    },
    "availableColors": [
      "Branco",
      "Preto",
      "Azul marinho",
      "Vermelho",
      "Verde militar",
      "Bege",
      "Cinza claro",
      "Azul celeste",
      "Azul royal",
      "Rosa pink"
    ],
    "availableSizes": [
      "P",
      "M",
      "G",
      "GG",
      "XG",
      "XXG"
    ]
  },
  {
    "id": "polo-1",
    "name": "Polo TXC · Preto",
    "category": "Polos",
    "image": "/assets/shirts/polo-1.webp",
    "color": "Preto",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho.",
    "variants": {
      "Branco": "/assets/shirts/polo-0.webp",
      "Preto": "/assets/shirts/polo-1.webp",
      "Azul marinho": "/assets/shirts/polo-2.webp",
      "Vermelho": "/assets/shirts/polo-3.webp",
      "Verde militar": "/assets/shirts/polo-4.webp",
      "Bege": "/assets/shirts/polo-5.webp",
      "Cinza claro": "/assets/shirts/polo-6.webp",
      "Azul celeste": "/assets/shirts/polo-7.webp",
      "Azul royal": "/assets/shirts/polo-8.webp",
      "Rosa pink": "/assets/shirts/polo-9.webp"
    },
    "availableColors": [
      "Branco",
      "Preto",
      "Azul marinho",
      "Vermelho",
      "Verde militar",
      "Bege",
      "Cinza claro",
      "Azul celeste",
      "Azul royal",
      "Rosa pink"
    ],
    "availableSizes": [
      "P",
      "M",
      "G",
      "GG",
      "XG",
      "XXG"
    ]
  },
  {
    "id": "polo-2",
    "name": "Polo TXC · Azul marinho",
    "category": "Polos",
    "image": "/assets/shirts/polo-2.webp",
    "color": "Azul marinho",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho.",
    "variants": {
      "Branco": "/assets/shirts/polo-0.webp",
      "Preto": "/assets/shirts/polo-1.webp",
      "Azul marinho": "/assets/shirts/polo-2.webp",
      "Vermelho": "/assets/shirts/polo-3.webp",
      "Verde militar": "/assets/shirts/polo-4.webp",
      "Bege": "/assets/shirts/polo-5.webp",
      "Cinza claro": "/assets/shirts/polo-6.webp",
      "Azul celeste": "/assets/shirts/polo-7.webp",
      "Azul royal": "/assets/shirts/polo-8.webp",
      "Rosa pink": "/assets/shirts/polo-9.webp"
    },
    "availableColors": [
      "Branco",
      "Preto",
      "Azul marinho",
      "Vermelho",
      "Verde militar",
      "Bege",
      "Cinza claro",
      "Azul celeste",
      "Azul royal",
      "Rosa pink"
    ],
    "availableSizes": [
      "P",
      "M",
      "G",
      "GG",
      "XG",
      "XXG"
    ]
  },
  {
    "id": "polo-3",
    "name": "Polo TXC · Vermelho",
    "category": "Polos",
    "image": "/assets/shirts/polo-3.webp",
    "color": "Vermelho",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho.",
    "variants": {
      "Branco": "/assets/shirts/polo-0.webp",
      "Preto": "/assets/shirts/polo-1.webp",
      "Azul marinho": "/assets/shirts/polo-2.webp",
      "Vermelho": "/assets/shirts/polo-3.webp",
      "Verde militar": "/assets/shirts/polo-4.webp",
      "Bege": "/assets/shirts/polo-5.webp",
      "Cinza claro": "/assets/shirts/polo-6.webp",
      "Azul celeste": "/assets/shirts/polo-7.webp",
      "Azul royal": "/assets/shirts/polo-8.webp",
      "Rosa pink": "/assets/shirts/polo-9.webp"
    },
    "availableColors": [
      "Branco",
      "Preto",
      "Azul marinho",
      "Vermelho",
      "Verde militar",
      "Bege",
      "Cinza claro",
      "Azul celeste",
      "Azul royal",
      "Rosa pink"
    ],
    "availableSizes": [
      "P",
      "M",
      "G",
      "GG",
      "XG",
      "XXG"
    ]
  },
  {
    "id": "polo-4",
    "name": "Polo TXC · Verde militar",
    "category": "Polos",
    "image": "/assets/shirts/polo-4.webp",
    "color": "Verde militar",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho.",
    "variants": {
      "Branco": "/assets/shirts/polo-0.webp",
      "Preto": "/assets/shirts/polo-1.webp",
      "Azul marinho": "/assets/shirts/polo-2.webp",
      "Vermelho": "/assets/shirts/polo-3.webp",
      "Verde militar": "/assets/shirts/polo-4.webp",
      "Bege": "/assets/shirts/polo-5.webp",
      "Cinza claro": "/assets/shirts/polo-6.webp",
      "Azul celeste": "/assets/shirts/polo-7.webp",
      "Azul royal": "/assets/shirts/polo-8.webp",
      "Rosa pink": "/assets/shirts/polo-9.webp"
    },
    "availableColors": [
      "Branco",
      "Preto",
      "Azul marinho",
      "Vermelho",
      "Verde militar",
      "Bege",
      "Cinza claro",
      "Azul celeste",
      "Azul royal",
      "Rosa pink"
    ],
    "availableSizes": [
      "P",
      "M",
      "G",
      "GG",
      "XG",
      "XXG"
    ]
  },
  {
    "id": "polo-5",
    "name": "Polo TXC · Bege",
    "category": "Polos",
    "image": "/assets/shirts/polo-5.webp",
    "color": "Bege",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho.",
    "variants": {
      "Branco": "/assets/shirts/polo-0.webp",
      "Preto": "/assets/shirts/polo-1.webp",
      "Azul marinho": "/assets/shirts/polo-2.webp",
      "Vermelho": "/assets/shirts/polo-3.webp",
      "Verde militar": "/assets/shirts/polo-4.webp",
      "Bege": "/assets/shirts/polo-5.webp",
      "Cinza claro": "/assets/shirts/polo-6.webp",
      "Azul celeste": "/assets/shirts/polo-7.webp",
      "Azul royal": "/assets/shirts/polo-8.webp",
      "Rosa pink": "/assets/shirts/polo-9.webp"
    },
    "availableColors": [
      "Branco",
      "Preto",
      "Azul marinho",
      "Vermelho",
      "Verde militar",
      "Bege",
      "Cinza claro",
      "Azul celeste",
      "Azul royal",
      "Rosa pink"
    ],
    "availableSizes": [
      "P",
      "M",
      "G",
      "GG",
      "XG",
      "XXG"
    ]
  },
  {
    "id": "polo-6",
    "name": "Polo TXC · Cinza claro",
    "category": "Polos",
    "image": "/assets/shirts/polo-6.webp",
    "color": "Cinza claro",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho.",
    "variants": {
      "Branco": "/assets/shirts/polo-0.webp",
      "Preto": "/assets/shirts/polo-1.webp",
      "Azul marinho": "/assets/shirts/polo-2.webp",
      "Vermelho": "/assets/shirts/polo-3.webp",
      "Verde militar": "/assets/shirts/polo-4.webp",
      "Bege": "/assets/shirts/polo-5.webp",
      "Cinza claro": "/assets/shirts/polo-6.webp",
      "Azul celeste": "/assets/shirts/polo-7.webp",
      "Azul royal": "/assets/shirts/polo-8.webp",
      "Rosa pink": "/assets/shirts/polo-9.webp"
    },
    "availableColors": [
      "Branco",
      "Preto",
      "Azul marinho",
      "Vermelho",
      "Verde militar",
      "Bege",
      "Cinza claro",
      "Azul celeste",
      "Azul royal",
      "Rosa pink"
    ],
    "availableSizes": [
      "P",
      "M",
      "G",
      "GG",
      "XG",
      "XXG"
    ]
  },
  {
    "id": "polo-7",
    "name": "Polo TXC · Azul celeste",
    "category": "Polos",
    "image": "/assets/shirts/polo-7.webp",
    "color": "Azul celeste",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho.",
    "variants": {
      "Branco": "/assets/shirts/polo-0.webp",
      "Preto": "/assets/shirts/polo-1.webp",
      "Azul marinho": "/assets/shirts/polo-2.webp",
      "Vermelho": "/assets/shirts/polo-3.webp",
      "Verde militar": "/assets/shirts/polo-4.webp",
      "Bege": "/assets/shirts/polo-5.webp",
      "Cinza claro": "/assets/shirts/polo-6.webp",
      "Azul celeste": "/assets/shirts/polo-7.webp",
      "Azul royal": "/assets/shirts/polo-8.webp",
      "Rosa pink": "/assets/shirts/polo-9.webp"
    },
    "availableColors": [
      "Branco",
      "Preto",
      "Azul marinho",
      "Vermelho",
      "Verde militar",
      "Bege",
      "Cinza claro",
      "Azul celeste",
      "Azul royal",
      "Rosa pink"
    ],
    "availableSizes": [
      "P",
      "M",
      "G",
      "GG",
      "XG",
      "XXG"
    ]
  },
  {
    "id": "polo-8",
    "name": "Polo TXC · Azul royal",
    "category": "Polos",
    "image": "/assets/shirts/polo-8.webp",
    "color": "Azul royal",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho.",
    "variants": {
      "Branco": "/assets/shirts/polo-0.webp",
      "Preto": "/assets/shirts/polo-1.webp",
      "Azul marinho": "/assets/shirts/polo-2.webp",
      "Vermelho": "/assets/shirts/polo-3.webp",
      "Verde militar": "/assets/shirts/polo-4.webp",
      "Bege": "/assets/shirts/polo-5.webp",
      "Cinza claro": "/assets/shirts/polo-6.webp",
      "Azul celeste": "/assets/shirts/polo-7.webp",
      "Azul royal": "/assets/shirts/polo-8.webp",
      "Rosa pink": "/assets/shirts/polo-9.webp"
    },
    "availableColors": [
      "Branco",
      "Preto",
      "Azul marinho",
      "Vermelho",
      "Verde militar",
      "Bege",
      "Cinza claro",
      "Azul celeste",
      "Azul royal",
      "Rosa pink"
    ],
    "availableSizes": [
      "P",
      "M",
      "G",
      "GG",
      "XG",
      "XXG"
    ]
  },
  {
    "id": "polo-9",
    "name": "Polo TXC · Rosa pink",
    "category": "Polos",
    "image": "/assets/shirts/polo-9.webp",
    "color": "Rosa pink",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho.",
    "variants": {
      "Branco": "/assets/shirts/polo-0.webp",
      "Preto": "/assets/shirts/polo-1.webp",
      "Azul marinho": "/assets/shirts/polo-2.webp",
      "Vermelho": "/assets/shirts/polo-3.webp",
      "Verde militar": "/assets/shirts/polo-4.webp",
      "Bege": "/assets/shirts/polo-5.webp",
      "Cinza claro": "/assets/shirts/polo-6.webp",
      "Azul celeste": "/assets/shirts/polo-7.webp",
      "Azul royal": "/assets/shirts/polo-8.webp",
      "Rosa pink": "/assets/shirts/polo-9.webp"
    },
    "availableColors": [
      "Branco",
      "Preto",
      "Azul marinho",
      "Vermelho",
      "Verde militar",
      "Bege",
      "Cinza claro",
      "Azul celeste",
      "Azul royal",
      "Rosa pink"
    ],
    "availableSizes": [
      "P",
      "M",
      "G",
      "GG",
      "XG",
      "XXG"
    ]
  },
  {
    "id": "pescaria-familia-0",
    "name": "Pescaria em Família · Rosa pink",
    "category": "Pesca",
    "image": "/assets/shirts/pescaria-familia-0.webp",
    "color": "Rosa pink",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "pescaria-familia-1",
    "name": "Pescaria em Família · Azul royal",
    "category": "Pesca",
    "image": "/assets/shirts/pescaria-familia-1.webp",
    "color": "Azul royal",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "pescaria-familia-2",
    "name": "Pescaria em Família · Turquesa",
    "category": "Pesca",
    "image": "/assets/shirts/pescaria-familia-2.webp",
    "color": "Turquesa",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "pescaria-familia-3",
    "name": "Pescaria em Família · Vermelho",
    "category": "Pesca",
    "image": "/assets/shirts/pescaria-familia-3.webp",
    "color": "Vermelho",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "pescaria-familia-4",
    "name": "Pescaria em Família · Verde militar",
    "category": "Pesca",
    "image": "/assets/shirts/pescaria-familia-4.webp",
    "color": "Verde militar",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "pescaria-familia-5",
    "name": "Pescaria em Família · Laranja",
    "category": "Pesca",
    "image": "/assets/shirts/pescaria-familia-5.webp",
    "color": "Laranja",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "pescaria-familia-6",
    "name": "Pescaria em Família · Cinza chumbo",
    "category": "Pesca",
    "image": "/assets/shirts/pescaria-familia-6.webp",
    "color": "Cinza chumbo",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "pescaria-familia-7",
    "name": "Pescaria em Família · Branco",
    "category": "Pesca",
    "image": "/assets/shirts/pescaria-familia-7.webp",
    "color": "Branco",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "pescaria-familia-8",
    "name": "Pescaria em Família · Preto",
    "category": "Pesca",
    "image": "/assets/shirts/pescaria-familia-8.webp",
    "color": "Preto",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "pega-nada-0",
    "name": "Equipe Pega Nada · Cinza chumbo",
    "category": "Pesca",
    "image": "/assets/shirts/pega-nada-0.webp",
    "color": "Cinza chumbo",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "pega-nada-1",
    "name": "Equipe Pega Nada · Roxo",
    "category": "Pesca",
    "image": "/assets/shirts/pega-nada-1.webp",
    "color": "Roxo",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "rela-jacare",
    "name": "Relâ no Jacaré · Camuflada",
    "category": "Pesca",
    "image": "/assets/shirts/rela-jacare.webp",
    "color": "Verde militar",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  },
  {
    "id": "pega-nada-militar",
    "name": "Equipe Pega Nada · Verde militar",
    "category": "Pesca",
    "image": "/assets/shirts/pega-nada-militar.webp",
    "color": "Verde militar",
    "detail": "Personalize nome, equipe e detalhes. Confira a referência e escolha seu tamanho."
  }
];
