const KEY='bravus-payment-attempt';
const LEGACY='bravus-payment-request';
export type Attempt={requestId:string;sellerName:string;amount:string;provider:string;values:Record<string,string>;paymentMethod?:'pix'|'credit_card';url?:string};
export function restoreAttempt(storage:Storage):{attempt?:Attempt;legacy:boolean}{
 const raw=storage.getItem(KEY);
 if(raw){try{const a=JSON.parse(raw);if(typeof a.requestId==='string'&&typeof a.sellerName==='string'&&typeof a.amount==='string'&&typeof a.provider==='string'&&a.values&&typeof a.values==='object')return {attempt:a,legacy:false};}catch{}return {legacy:true};}
 return {legacy:!!storage.getItem(LEGACY)};
}
export function saveAttempt(storage:Storage,attempt:Attempt){storage.setItem(KEY,JSON.stringify(attempt));storage.removeItem(LEGACY);}
export function clearAttempt(storage:Storage){storage.removeItem(KEY);storage.removeItem(LEGACY);}
