import assert from 'node:assert/strict';
import test from 'node:test';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {build} from 'esbuild';

const db=new DatabaseSync(':memory:');
for(const name of ['0000_bitter_king_bedlam','0001_stale_reaper','0002_complex_roulette'])db.exec(readFileSync('drizzle/'+name+'.sql','utf8'));
globalThis.__env={ADMIN_EMAIL:'owner@example.test',PAYMENT_VAULT_KEY:Buffer.alloc(32,33).toString('base64'),DB:{prepare(sql){const execute=(args=[])=>({async first(){return db.prepare(sql).get(...args)},async all(){return {results:db.prepare(sql).all(...args)}},async run(){return {meta:{changes:Number(db.prepare(sql).run(...args).changes)}}}});return {...execute(),bind(...args){return execute(args)}}}}};
globalThis.__headers=new Headers();
const directory=mkdtempSync(join(tmpdir(),'biocamisas-domains-'));
const plugin={name:'test-runtime',setup(b){b.onResolve({filter:/^(cloudflare:workers|next\/headers)$/},x=>({path:x.path,namespace:'mock'}));b.onLoad({filter:/.*/,namespace:'mock'},x=>({contents:x.path==='cloudflare:workers'?'export const env=globalThis.__env':'export async function headers(){return globalThis.__headers}',loader:'js'}));}};
async function load(entry,name){const outfile=join(directory,name+'.mjs');await build({entryPoints:[entry],outfile,bundle:true,platform:'node',format:'esm',plugins:[plugin]});return import(outfile);}
const brands=await load('lib/checkout-brand.ts','brands'),payments=await load('lib/payments.ts','payments'),orders=await load('app/api/orders/route.ts','orders'),settings=await load('app/api/settings/route.ts','settings'),access=await load('lib/gateway-access.ts','access'),login=await load('app/api/admin/gateway-access/route.ts','login'),gateways=await load('lib/gateways.ts','gateways');
const bio='https://biocamisas.shop',bravus='https://pagamento.bravuspix.shop';
const req=(body,origin=bio,destination=origin)=>new Request(destination+'/api/orders',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify(body)});
let posts=0;
globalThis.fetch=async(url,init)=>{
  assert.equal(url,'https://api.realtechdev.com.br/v1/transactions');assert.equal(init.method,'POST');posts++;
  const payload=JSON.parse(init.body);assert.equal(payload.amount,10000);
  return Response.json({data:{total_amount:10000,pix:{code:'000201-synthetic-only',qrcode_base64:'aGVsbG8='}}},{status:201});
};

test('a marca depende somente dos domínios conhecidos, com origem canônica e proteção de retorno',async()=>{
  assert.equal(brands.checkoutBrandForOrigin(bio).name,'Bio Camisas');
  assert.equal(brands.checkoutBrandForOrigin('https://www.biocamisas.shop').origin,bio);
  for(const origin of [null,'http://biocamisas.shop','https://biocamisas.shop.attacker.test','https://biocamisas.shop@attacker.test','https://biocamisas.shop:444','https://biocamisas.shop/'])assert.equal(brands.checkoutBrandForOrigin(origin).id,'bravus');
  assert.equal(brands.checkoutBrandForHeaders(new Headers({host:'www.biocamisas.shop'})).id,'biocamisas');
  assert.equal(brands.checkoutBrandForHeaders(new Headers({host:'unknown.test','x-forwarded-host':'biocamisas.shop'})).id,'bravus');
  assert.equal(brands.checkoutBrandForHeaders(new Headers({host:'localhost','x-checkout-origin':bio})).id,'biocamisas');
  assert.equal(brands.checkoutBrandForHeaders(new Headers({host:'biocamisas.shop','x-checkout-origin':bravus})).id,'bravus');
  const id=crypto.randomUUID();
  const mapped=await brands.checkoutResponse(req({}),Response.json({url:bravus+'/pagar/'+id},{headers:{'Cache-Control':'no-store','X-Test':'preserved'}}));
  assert.equal((await mapped.json()).url,bio+'/pagar/'+id);assert.equal(mapped.headers.get('X-Test'),'preserved');assert.match(mapped.headers.get('Cache-Control'),/no-store/);
  for(const url of ['https://outside.test/pagar/'+id,bravus+'/admin/gateways',bravus+'/pagar/'+id+'?secret=1',bravus+'/pagar/not-an-id']){
    const response=Response.json({url});assert.equal(await brands.checkoutResponse(req({}),response),response);assert.equal((await response.json()).url,url);
  }
});

test('BIO e BRAVUS usam as mesmas credenciais e recuperam o mesmo PIX sem uma segunda cobrança',async()=>{
  await payments.saveCredentials('fake-shared-token','fake-user-agent','buckpay');
  await gateways.selectGateway('buckpay');
  const body={amount:10000,sellerName:'Vendedor sintético',requestId:crypto.randomUUID()};
  assert.equal((await orders.POST(req(body,'https://attacker.test',bio))).status,403);assert.equal(posts,0);
  for(const origin of [bio,bravus]){
    const response=await settings.GET(new Request(origin+'/api/settings'));assert.equal(response.status,200);
    assert.deepEqual(await response.json(),{configured:true,provider:'buckpay'});
  }
  const first=await orders.POST(req(body));assert.equal(first.status,200);const result=await first.json();
  assert.match(result.url,/^https:\/\/biocamisas\.shop\/pagar\/[a-f0-9-]+$/);
  assert.deepEqual(await (await orders.POST(req(body))).json(),result);
  assert.equal((await (await orders.POST(req(body,bravus))).json()).url,result.url.replace(bio,bravus));
  assert.equal((await (await orders.POST(req(body,'https://www.biocamisas.shop'))).json()).url,result.url);
  assert.equal((await orders.POST(req({...body,amount:20000}))).status,409);
  assert.equal(posts,1);assert.equal(db.prepare('SELECT count(*) AS n FROM payment_orders').get().n,1);
  assert.equal(db.prepare("SELECT count(*) AS n FROM payment_settings WHERE key='buckpay'").get().n,1);
  assert.ok(!JSON.stringify(result).includes('fake-shared-token'));
});

test('os dois domínios compartilham a senha e as regras sem liberar administração pública',async()=>{
  assert.equal((await access.panelGuard(req({}))).status,403);
  await access.setPanelPassword('fixture-shared-password');
  const response=await login.POST(req({action:'login',password:'fixture-shared-password'}));assert.equal(response.status,200);
  const cookie=response.headers.get('set-cookie');assert.match(cookie,/__Host-bravus-gateway=.*HttpOnly; Secure; SameSite=Strict/);assert.ok(!cookie.includes('Domain='));
  globalThis.__headers=new Headers({cookie:cookie.split(';')[0]});
  assert.equal(await access.panelGuard(req({})),null);assert.equal(await access.panelGuard(req({},bravus)),null);
  assert.equal((await access.panelGuard(req({},'https://attacker.test',bio))).status,403);
  const policy={enabled:false,autoSwitch:true,order:['buckpay','beehive'],ticketRouting:{enabled:false,rules:[]}};
  await gateways.saveFallbackPolicy(policy);assert.deepEqual(await gateways.fallbackPolicy(),policy);
  globalThis.__headers=new Headers();
});

test('links de cartão usam Bio Camisas e preservam o pedido e a gateway ao reabrir pela BRAVUS',async()=>{
  await payments.saveCredentials('fake-card-token','fake-public-key','beehive');await gateways.selectGateway('beehive');
  const body={amount:10000,paymentMethod:'credit_card',sellerName:'Vendedor sintético',requestId:crypto.randomUUID()};
  const response=await orders.POST(req(body));assert.equal(response.status,200);const result=await response.json();
  assert.match(result.url,/^https:\/\/biocamisas\.shop\/cartao\/[a-f0-9-]+$/);
  assert.deepEqual(await (await orders.POST(req(body))).json(),result);
  assert.equal((await (await orders.POST(req(body,bravus))).json()).url,result.url.replace(bio,bravus));
  assert.equal(db.prepare("SELECT count(*) AS n FROM payment_orders WHERE provider='beehive_card'").get().n,1);assert.equal(posts,1);
});

test.after(()=>{db.close();rmSync(directory,{recursive:true,force:true});});
