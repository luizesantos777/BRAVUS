'use client';
import {useEffect,useState} from 'react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import RoutingControls from './routing-controls';
import type {FallbackPolicy} from '@/lib/gateways';
const names:Record<string,string>={beehive:'Beehive Pay',eleva:'Eleva Payments',gestao:'Gestão Pay',firebot:'Firebot',poseidon:'Poseidon',buckpay:'BuckPay'};
const descriptions:Record<string,string>={beehive:'PIX e links de cartão de crédito',eleva:'PIX com confirmação de pagamento',gestao:'PIX com consulta de pagamento',firebot:'PIX para pedidos digitais',poseidon:'PIX para pedidos físicos',buckpay:'PIX com consulta de pagamento'};
type Panel={active:string;providers:{id:string;configured:boolean;pausedUntil?:number|null}[];fallback:FallbackPolicy;lastSwitch?:{from:string;to:string;scope?:string;at:number}|null};
export default function Settings(){
 const [data,setData]=useState<Panel|null>(null),[busy,setBusy]=useState(''),[error,setError]=useState(''),[notice,setNotice]=useState(''),[token,setToken]=useState(''),[agent,setAgent]=useState('');
 async function load(){const r=await fetch('/api/admin/gateways',{cache:'no-store'});const d=await r.json();if(!r.ok)throw Error(d.error);setData(d);}
 useEffect(()=>{load().catch(e=>setError(e.message));const refresh=()=>load().catch(()=>{});const timer=setInterval(refresh,30000);window.addEventListener('focus',refresh);return()=>{clearInterval(timer);window.removeEventListener('focus',refresh);};},[]);
 async function activate(id:string){if(busy)return;setBusy(id);setError('');setNotice('');try{
 const r=await fetch('/api/admin/gateways',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({provider:id})});const d=await r.json();if(!r.ok)throw Error(d.error);
 await load();setNotice(names[d.active]+' ativada para novos pedidos.');
 }catch(e){setError((e as Error).message);await load().catch(()=>setData(null));}finally{setBusy('');}}
 async function configureBuck(e:React.FormEvent){e.preventDefault();if(busy)return;setBusy('buckpay');setError('');setNotice('');try{const r=await fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token,agent})});const d=await r.json();if(!r.ok)throw Error(d.error);setToken('');setAgent('');await load();setNotice('BuckPay cadastrada. Clique em Usar BuckPay para selecioná-la.');}catch(e){setError((e as Error).message);}finally{setBusy('');}}
 return <main className="pay-shell gateway-page"><header className="pay-brand"><img src="/assets/bravus-logo.jpg" alt="Bravus Brasil"/><div><strong>BRAVUS BRASIL</strong><small>Painel privado de pagamentos</small></div></header>
 <span className="secure">Controle da loja</span><h1>Gateways e regras de pagamento</h1><p className="muted">Defina a gateway padrão, as faixas de ticket e a ordem das reservas para novos pedidos.</p>
 {data&&<div className="gateway-current"><span>GATEWAY PADRÃO</span><strong>{data.providers.find(p=>p.id===data.active)?.configured?names[data.active]:'Nenhuma configurada'}</strong><p>Os pagamentos já gerados continuam na gateway original.</p></div>}
 {data?.lastSwitch&&<p className="muted" role="status">Último desvio automático: {names[data.lastSwitch.from]} → {names[data.lastSwitch.to]}{data.lastSwitch.scope==='ticket'?' para pedidos da faixa de ticket':''}, em {new Date(data.lastSwitch.at).toLocaleString('pt-BR')}.</p>}
 {data&&<RoutingControls initial={data.fallback} providers={data.providers} onSaved={load}/>}
 {error&&<p role="alert" className="error">{error}</p>}{notice&&<p role="status" className="success">{notice}</p>}
 {!data&&!error&&<p role="status">Carregando gateways…</p>}{!data&&error&&<Button className="action" onClick={()=>{setError('');load().catch(e=>setError(e.message));}}>Tentar novamente</Button>}
 <div className="gateway-grid">{data?.providers.map(p=>{const active=p.configured&&data.active===p.id,paused=!!p.pausedUntil&&p.pausedUntil>Date.now();return <section className={'pay-card gateway-card'+(active?' selected':'')} key={p.id}>
 <div className="gateway-card-head"><h2>{names[p.id]}</h2><span className={'gateway-badge'+(active?' on':'')}>{active?'Ativa':p.configured?'Cadastrada':'Não configurada'}</span></div>
 <p className="muted">{descriptions[p.id]}</p>{paused&&<p className="field-note">Pausa automática até {new Date(p.pausedUntil!).toLocaleTimeString('pt-BR')}. Selecionar esta gateway libera novas tentativas.</p>}
 <Button className="action" disabled={!p.configured||!!busy||(active&&!paused)} onClick={()=>activate(p.id)}>{busy===p.id?'Salvando…':active&&!paused?'✓ Padrão':paused?'Reativar '+names[p.id]:'Usar '+names[p.id]}</Button>
 {p.id!=='buckpay'?<a className="gateway-config" href={'/admin/'+p.id}>{p.configured?'Gerenciar credenciais':'Cadastrar credenciais'}</a>:p.configured?<p className="muted">Credenciais salvas com segurança.</p>:<details><summary>Cadastrar BuckPay</summary><form onSubmit={configureBuck}><label className="field"><span>Token BuckPay</span><Input type="password" autoComplete="new-password" value={token} onChange={e=>setToken(e.target.value)} minLength={40} maxLength={40} required disabled={!!busy}/></label><label className="field"><span>User-Agent fornecido pela BuckPay</span><Input value={agent} onChange={e=>setAgent(e.target.value)} maxLength={500} required disabled={!!busy}/></label><Button className="action" disabled={!!busy}>Salvar credenciais</Button></form></details>}
 </section>})}</div><p className="muted">Cadastrar uma gateway não gera cobrança. As chaves ficam protegidas no servidor.</p><Button variant="outline" className="action" onClick={async()=>{try{const r=await fetch('/api/admin/gateway-access',{method:'DELETE'});if(!r.ok)throw Error();window.location.reload();}catch{setError('Não foi possível bloquear o painel. Tente novamente.');}}}>🔒 Bloquear painel</Button><footer className="gateway-footer"><a href="/checkout" target="_blank" rel="noopener noreferrer">Abrir checkout ↗</a><a href="/">Voltar aos funis</a></footer></main>;
}
