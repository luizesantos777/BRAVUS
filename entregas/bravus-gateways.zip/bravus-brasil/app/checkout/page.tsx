import Checkout from './ui';
import {panelUnlocked} from '@/lib/gateway-access';
export const dynamic='force-dynamic';
export default async function Page(){return <Checkout canConfigure={await panelUnlocked()}/>}
