import type {Metadata,Viewport} from 'next';
import './globals.css';
export const metadata:Metadata={title:'Bravus Brasil · Pagamento seguro',description:'Pagamento do seu pedido Bravus Brasil com PIX ou cartão.',robots:{index:false,follow:false}};
export const viewport:Viewport={width:'device-width',initialScale:1};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body>{children}</body></html>}
