import {gatewayEnabled} from '@/lib/gateway-status';
import {panelGuard} from '@/lib/gateway-access';
import {gatewayForAmount,gatewaySelection,preserveGatewaySelection} from '@/lib/gateways';
import {publicGuard,json,readBody,credentials,saveCredentials} from '@/lib/payments';
export const dynamic='force-dynamic';
export async function GET(req:Request){const deny=await publicGuard(req);if(deny)return deny;try{
 const raw=new URL(req.url).searchParams.get('amount');
 if(raw!==null&&(!/^\d{1,6}$/.test(raw)||Number(raw)<600||Number(raw)>300000))return json({error:'Informe um valor entre R$ 6,00 e R$ 3.000,00.'},400);
 const method=new URL(req.url).searchParams.get('method');if(method!==null&&method!=='pix'&&method!=='credit_card')return json({error:'Forma de pagamento indisponível.'},400);
 const selected=await gatewaySelection();
 const route=method==='credit_card'?{provider:selected.provider,available:!selected.suspended}:await gatewayForAmount(raw===null?undefined:Number(raw),undefined,selected);
 return json({configured:route.available&&await gatewayEnabled(route.provider),provider:route.provider});
}catch{return json({error:'Não foi possível consultar a configuração.'},503);}}
export async function POST(req:Request){const deny=await panelGuard(req);if(deny)return deny;try{const b=await readBody(req);if(await credentials()&&b.replace!==true)return json({error:'As credenciais BuckPay já estão configuradas e bloqueadas para alteração.'},409);if(typeof b.token!=='string'||b.token.length!==40||/[\r\n\s]/.test(b.token)||typeof b.agent!=='string'||!b.agent.trim()||b.agent.length>500||/[\r\n]/.test(b.agent))return json({error:'Informe o token de 40 caracteres e o User-Agent fornecidos pela BuckPay.'},400);if(b.activate===false)await preserveGatewaySelection();await saveCredentials(b.token,b.agent.trim());return json({configured:true});}catch{return json({error:'Não foi possível salvar. Tente novamente.'},503);}}
