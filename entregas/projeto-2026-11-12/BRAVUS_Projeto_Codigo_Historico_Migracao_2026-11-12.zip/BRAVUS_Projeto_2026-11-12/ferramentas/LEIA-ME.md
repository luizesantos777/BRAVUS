# Recuperar as mídias do ZIP original

O arquivo `Bravus_Brasil_Atualizado_Codex.zip` enviado anteriormente tem mais de 32 MiB e não pôde ser baixado para este ambiente. A exportação de código informa 101 arquivos de mídia omitidos, relacionados em `MIDIAS_PENDENTES.txt`.

No seu computador, extraia este pacote e mantenha o ZIP original em uma pasta acessível. Instale Python 3 se necessário e execute, na pasta desta entrega:

```sh
python ferramentas/restaurar_midias.py "/caminho/Bravus_Brasil_Atualizado_Codex.zip"
```

Em sistemas onde o comando é `python3`, use `python3` no lugar de `python`.

O programa procura os caminhos da lista dentro do arquivo original, copia somente as mídias solicitadas para `checkout-loja-funis/public/` e mantém arquivos já existentes. Não extrai código, banco ou segredos do arquivo original. Ao final, informa quantas mídias continuam pendentes. Se houver nomes ambíguos no ZIP, ele não escolhe uma cópia arbitrariamente.

Nenhum download de mídia é feito pelo importador; tudo acontece no seu computador. Guarde o ZIP original: ele continua sendo a fonte das mídias ausentes neste pacote.
