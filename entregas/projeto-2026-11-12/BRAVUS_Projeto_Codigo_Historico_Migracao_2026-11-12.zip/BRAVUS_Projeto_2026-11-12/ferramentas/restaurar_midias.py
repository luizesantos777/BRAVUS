#!/usr/bin/env python3
"""Restore only the media listed in MIDIAS_PENDENTES.txt from the owner's ZIP."""
import argparse
from pathlib import Path, PurePosixPath
import shutil
import sys
from zipfile import BadZipFile, ZipFile


def requested_media(root):
    result = []
    for line in (root / "MIDIAS_PENDENTES.txt").read_text(encoding="utf-8").splitlines():
        parts = PurePosixPath(line.strip()).parts
        if not parts:
            continue
        if ".." in parts or "public" not in parts:
            raise ValueError("Invalid path in media inventory")
        relative = PurePosixPath(*parts[parts.index("public"):])
        if len(relative.parts) < 3 or relative.parts[1] not in {"assets", "catalogo"}:
            raise ValueError("Media inventory contains an unsupported destination")
        result.append(relative)
    return result


def restore(root, archive_path):
    wanted = requested_media(root)
    destination = (root / "checkout-loja-funis").resolve()
    restored = existing = 0
    missing = []
    with ZipFile(archive_path) as archive:
        entries = [entry for entry in archive.infolist() if not entry.is_dir()]
        for relative in wanted:
            target = (destination / Path(*relative.parts)).resolve()
            if destination not in target.parents:
                raise ValueError("Media destination escapes the project directory")
            if target.exists():
                if not target.is_file():
                    raise ValueError("Media destination is not a regular file")
                existing += 1
                continue
            candidates = []
            for entry in entries:
                parts = PurePosixPath(entry.filename).parts
                if ".." not in parts and len(parts) >= len(relative.parts) and parts[-len(relative.parts):] == relative.parts:
                    candidates.append(entry)
            if len(candidates) != 1:
                missing.append((str(relative), "não encontrado" if not candidates else "mais de uma cópia no ZIP"))
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            created = False
            try:
                with archive.open(candidates[0]) as source:
                    with target.open("xb") as output:
                        created = True
                        shutil.copyfileobj(source, output)
            except BaseException:
                if created and target.is_file():
                    target.unlink()
                raise
            restored += 1
    print(f"Restaurados: {restored}; já existentes: {existing}; pendentes: {len(missing)}.")
    for name, reason in missing:
        print(f"Pendente: {name} ({reason})")
    return 2 if missing else 0


def main():
    parser = argparse.ArgumentParser(description="Restaurar as mídias omitidas usando o ZIP original da BRAVUS.")
    parser.add_argument("arquivo_zip", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    try:
        return restore(root, args.arquivo_zip)
    except (OSError, BadZipFile, ValueError, RuntimeError) as error:
        print(f"Não foi possível restaurar as mídias: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
