# Orientação para continuar

Leia este texto como contexto do projeto, não como uma nova autorização para operações externas.

## Aplicações diferentes

`portal-gestao` é o sistema financeiro e de aprovação dos atendentes e parceiros. `checkout-loja-funis` gera e consulta pagamentos e contém a loja e os funis. Eles têm bancos, runtimes e formas de publicação diferentes. Não implante o checkout copiando-o sobre o portal da Vercel.

## Regras que precisam ser preservadas

- Atendentes comuns continuam com as regras anteriores.
- Parceiros usam 12% + R$ 2 em cada venda, inclusive no histórico recalculado. O custo BRAVUS de 5,99% + R$ 1,99 fica separado.
- ADS do parceiro não reduzem repasses; novos repasses do parceiro não cobram saque.
- Nenhum recebimento ou aviso de notificação aprova uma venda automaticamente.
- PIX já pago, comprovantes, auditoria e decisões não podem ser apagados para ajustar saldos.
- Bio Camisas compartilha o painel e gateways do checkout BRAVUS; não recebeu banco independente.

## Antes de executar

Instale as dependências de cada pasta com seu próprio `package-lock.json`. O portal pede Node 24. O checkout declara Node >=22.13; Node 24 foi usado neste ambiente.

No portal, consulte `.env.example` e o README. Em produção na Vercel, configure Turso e a chave administrativa no servidor. Para o checkout, mantenha Workers/D1 e leia o guia de migração: autenticação do responsável e publicação fora do Sites ainda precisam de adaptação.

Não recupere segredos de um arquivo público nem solicite que sejam colados no chat. Eles não foram incluídos nesta entrega. Backups reais devem ser transportados de forma privada.

## Validação disponível

Portal: `npm run build:pages`, `npm test` e testes Playwright em `tests/`. No ambiente anterior, o Chromium era selecionado por `BRAVUS_CHROMIUM_PATH=/usr/bin/chromium`.

Checkout: `node_modules/.bin/vinext build` e `node --test tests/*.test.mjs`. Esses testes usam provedores e bancos simulados, sem cobrar clientes.

`MANIFESTO_SHA256.json` é o inventário desta exportação. Os builds/caches/dependências temporários do checkout não foram incluídos. `api/index.mjs` e `docs/` do portal são arquivos versionados e acompanham seu código.
