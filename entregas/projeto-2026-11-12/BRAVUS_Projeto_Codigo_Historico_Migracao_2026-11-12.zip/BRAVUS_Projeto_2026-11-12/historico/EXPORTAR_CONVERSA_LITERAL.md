# Como guardar as mensagens literais

O ZIP do projeto contém **um resumo técnico**, não uma exportação integral das mensagens da conta. Este ambiente não fornece uma ferramenta para exportar a conversa completa nem para recuperar literalmente todas as respostas, capturas, anexos e propostas antigas.

Para obter a cópia disponibilizada pela sua conta ChatGPT, abra as configurações da conta, procure **Controles de dados → Exportar dados** e siga as instruções de confirmação e recebimento do arquivo. A disponibilidade e os nomes dos menus podem variar conforme a conta e o produto. Se a opção não aparecer, consulte a página de ajuda/exportação de dados da conta.

Guarde a exportação recebida de forma privada. Ela pode conter outras conversas e informações da conta. Se este trabalho estiver distribuído entre ChatGPT, Sites e Codex, confira se o arquivo recebido inclui todos os produtos e chats desejados; esta entrega não confirma essa cobertura.

O link compartilhado de uma conversa não substitui um backup dos arquivos do projeto, do banco e das variáveis da hospedagem. Arquivos que só aparecem como referências antigas podem precisar ser baixados separadamente da conversa original.
