# Histórico técnico resumido

Este documento registra os pedidos e as decisões identificáveis no contexto e no código disponível. **Não é uma reprodução literal de toda a conversa.** Referências antigas a opções numeradas, sem a proposta completa, não foram reconstruídas como se seu conteúdo fosse conhecido.

## 1. Criação do BRAVUS

- Repositório principal: `luizesantos777/BRAVUS`.
- Pedido inicial de ambiente em nuvem e sistema de gestão, evoluindo para portal de atendentes inspirado nas referências enviadas.
- Identidade BRAVUS em verde, dourado e fundo escuro, com logo da marca.
- A meta diária de vendas foi removida.
- Cadastro de atendentes e emissão/renovação/revogação de tokens pertencem à administração. O atendente recebe seu link de acesso; não se cadastra nem escolhe seu token.
- A página de entrada não deve oferecer instruções de autocadastro ao atendente.

## 2. Hospedagem e dados do portal

- Endereço informado pelo usuário: `https://bravus-omega.vercel.app/`.
- A versão de produção usa API Node.js na Vercel e banco persistente Turso/libSQL. A alternativa local usa SQLite.
- GitHub Pages é uma demonstração estática e não substitui o banco e a API.
- As vendas entram em análise; somente a aprovação libera faturamento, participação e saldo. A administração pode cancelar uma aprovação com motivo, sem apagar a venda ou os comprovantes.
- O administrador registra pagamentos manuais já realizados. Solicitações de repasse pelos atendentes foram desativadas.
- Foram incluídos auditoria, fechamento por período, exportação CSV e recursos de backup privado.
- Alterações no GitHub e gatilhos de deploy foram enviados. Este ambiente não confirmou o estado final da publicação na Vercel porque o acesso estava bloqueado; exportar o código não comprova publicação.

## 3. Regras dos atendentes comuns

O último esclarecimento foi **manter os atendentes como estavam**. A atualização de 12% + R$ 2 é exclusiva dos parceiros.

- Participação padrão de 50% sobre o bruto; metade da taxa do gateway é descontada do atendente e a outra metade fica com a BRAVUS. Fórmulas históricas já registradas são preservadas.
- Checkout principal: 15% + R$ 1,99 por transação, até R$ 1.000.
- PIX manual: 6,99% + R$ 1,69 por venda, com mínimo configurado de R$ 5.
- Buckpay: opção separada para cálculo das taxas, originalmente 6,99% + R$ 1,69. O link externo do checkout é compartilhado.
- Custos de ADS dos atendentes mantêm o desconto existente no saldo.
- Saque de gateway de R$ 5, dividido em R$ 2,50 para cada parte, somente quando o administrador confirma o pagamento. O registro de venda não cobra saque.
- O histórico de cada venda mantém a fórmula e a tarifa aplicadas, salvo migrações expressamente solicitadas.

## 4. Evolução das contas de parceiro

- Portal identificado como **Portal do Parceiro — Acompanhe suas vendas e pagamentos**.
- Gateway automático, com limite de R$ 3.000 por venda e sem seleção manual de checkout.
- A tarifa passou inicialmente por 10%, depois 12% sem valor fixo, e a decisão mais recente foi **12% + R$ 2 por venda**, inclusive nas vendas antigas dos parceiros.
- O parceiro recebe o bruto menos a tarifa integral, sem divisão de 50% com a BRAVUS. Em uma venda de R$ 100, a tarifa atual é R$ 14 e o valor do parceiro é R$ 86.
- Novos repasses de parceiros não têm taxa de saque. Pagamentos já realizados e taxas históricas reais permanecem no histórico.
- ADS de parceiros servem para controle de lucro e ROI e **não são descontados do saldo de repasse**. O parceiro pode registrar o próprio gasto. Registros administrativos antigos podem continuar no banco para o histórico e o relatório, sem reduzir o repasse do parceiro.
- Custo efetivo da BRAVUS no gateway: **5,99% + R$ 1,99 em cada transação**. Esse custo não é cobrado uma segunda vez do parceiro.
- Lucro BRAVUS nas taxas = tarifa cobrada do parceiro menos custo efetivo do gateway. O fechamento também identifica custos históricos de saque da BRAVUS.
- As migrações financeiras são transacionais, auditadas e executadas uma vez. Preservam comprovantes, decisões, tokens, custos efetivos e pagamentos.
- As comparações de **13% + R$ 2**, **12% + R$ 0** e **12% + R$ 2** foram simulações financeiras. **13% não foi aplicado como tarifa final.**
- Tarifas são calculadas e arredondadas por venda, não uma vez por dia ou por parceiro.

## 5. Apresentação e recursos do portal

- Detalhes de tarifas das vendas foram ocultados nos portais de atendentes e parceiros; permanecem disponíveis no admin.
- Ranking compartilhado com pódio, fotos/iniciais, posições, faturamento aprovado, contagem de vendas e indicação do usuário.
- Períodos diário, 7 dias, 30 dias e intervalo personalizado no calendário.
- Perfis têm nome, foto, chave PIX e titular, mensagem personalizada de sucesso e notificações.
- O app geral usa Lucro Certo; o app administrativo usa **GESTÃO**. Textos antigos FireBot foram substituídos nos metadados e nas notificações configuráveis pelo site.
- No iPhone, notificações web exigem a instalação na Tela de Início e um sistema/navegador compatível. O código inclui instruções e identificação do modo instalado.
- Administrador recebe o alerta quando o atendente lança a venda, conforme a escolha do usuário. O alerta não aprova a venda automaticamente.

## 6. Comprovantes e confiabilidade

- Imagens podem ser selecionadas ou coladas por Ctrl+V/⌘V e pelo botão Colar imagem.
- Cada venda recebe seu próprio comprovante. Com várias vendas, a área escolhida define a linha do anexo.
- Imagens de até 20 MB podem ser reduzidas no aparelho; o comprovante armazenado tem limite de 2 MB.
- Foi incluído **Anexar PDF** para atendentes e parceiros. Aceita PDF original de até 2 MB, salva no rascunho e permite abrir ou baixar no admin e no portal.
- Cada venda mantém uma imagem ou PDF. A seleção de outro arquivo substitui o anterior.
- API verifica o formato e mantém acesso privado. O PDF não é convertido em imagem.
- Rascunhos usam IndexedDB. Reenvio depois de uma resposta perdida conserva a chave de idempotência para não duplicar vendas.
- Atualização automática da fila administrativa e aviso de filtros ajudam a localizar vendas recebidas.

## 7. Loja, catálogo e funis

- O usuário identificou uma loja e um checkout em `pagamento.bravuspix.shop`, com catálogo PDF, cores, tamanhos e fluxo de pedidos.
- O código de loja, checkout e funis foi fornecido por ZIP exportado de um projeto ChatGPT/Sites.
- O projeto usa Vinext/React, Cloudflare Workers e D1; não é apenas HTML estático.
- Há funis 1–4, loja, carrinho, frete/pedidos, checkout PIX e cartão e administração de gateways.
- A correspondência completa com todas as mídias e o catálogo publicado mais recente não foi confirmada externamente. A exportação de código omitiu 101 imagens/PDFs; a lista e o importador estão na entrega.

## 8. Gateways e fallback

- Gateway padrão selecionável, ordem de reservas escolhida no painel e regras por valor de ticket.
- PIX pode usar regras por ticket e fallback. Cartão permanece no provedor compatível Beehive.
- Uma cobrança existente continua vinculada à gateway original.
- Uma falha com resultado indefinido não deve produzir outra cobrança em uma gateway diferente. Recuperação e idempotência preservam o pedido.
- As chaves das gateways ficam criptografadas no banco com `PAYMENT_VAULT_KEY`, fora dos links de clientes.
- As regras automáticas começam desativadas até serem configuradas.

## 9. Bio Camisas

- Domínio escolhido: **biocamisas.shop**, comprado na Hostinger.
- O usuário informou que o domínio era novo e ainda não estava vinculado ao sistema.
- Escolha confirmada: usar **o mesmo painel e gateways da BRAVUS**, com identificação Bio Camisas no domínio novo.
- Código preparado para checkout, PIX e cartão, com links próprios do Bio Camisas e manutenção dos links BRAVUS.
- O Worker define a identidade pelo domínio da URL, inclusive atrás de proxy, e substitui o cabeçalho interno de identificação.
- Compartilha banco, senha do painel, gateways, regras e fallback. A sessão de navegador é própria por domínio.
- Não foi confirmada a publicação da alteração no Sites nem a configuração do DNS/HTTPS na Hostinger.

## 10. Situação desta entrega

- Portal: código da `main` até o commit `e93bbb6`, incluindo PDFs; o último commit é um gatilho de deploy, sem mudança adicional de código.
- Checkout: fonte exportada em 07/11/2026, com as atualizações locais de fallback, regras por ticket e Bio Camisas.
- As verificações recentes incluíram 130 testes de API/domínio e 102 cenários de navegador do portal, considerando os cenários repetidos após ajustes de textos; e 38 testes do checkout, além de navegação local em computador e celular.
- Nenhuma cobrança real foi criada nesses testes. Os dados utilizados eram sintéticos.
- O pedido atual é exportar o material e explicar a saída do Sites. Nenhuma publicação foi cancelada, nenhum DNS foi modificado e nenhum banco de produção foi migrado por esta exportação.
