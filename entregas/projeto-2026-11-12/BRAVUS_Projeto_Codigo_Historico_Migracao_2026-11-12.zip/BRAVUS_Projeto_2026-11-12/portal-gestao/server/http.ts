import { createServer } from 'node:http';
import type { IncomingMessage, ServerResponse } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, resolve, sep } from 'node:path';
import { createHash, timingSafeEqual } from 'node:crypto';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { PortalError, PortalStore } from './store.ts';
import { periodLabels } from '../src/domain.ts';
import type { Period } from '../src/domain.ts';
import type { RankingPeriod } from '../src/ranking-domain.ts';
import type { SaleBatch } from '../src/domain.ts';
import type { PushService } from './push.ts';
import type { BackupService } from './backups.ts';
import { readAudit, readFinancialReport } from './admin-controls.ts';
import { financialCsv } from '../src/admin-domain.ts';
import { receiptExtension } from '../src/receipt-types.ts';

const BODY_LIMIT = 12 * 1024 * 1024;
const json = (response: ServerResponse, status: number, value: unknown) => { response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); response.end(JSON.stringify(value)); };
function readJson(request: IncomingMessage, limit = BODY_LIMIT): Promise<unknown> {
  const prepared = (request as IncomingMessage & { body?: unknown }).body;
  if (prepared !== undefined) {
    try {
      const text = Buffer.isBuffer(prepared) ? prepared.toString('utf8') : typeof prepared === 'string' ? prepared : JSON.stringify(prepared);
      if (Buffer.byteLength(text) > limit) return Promise.reject(new PortalError(413, 'O envio excede o limite. Envie menos vendas ou arquivos menores por vez.'));
      return Promise.resolve(JSON.parse(text));
    } catch { return Promise.reject(new PortalError(400, 'O corpo da solicitação deve ser um JSON válido.')); }
  }
  return new Promise((accept, reject) => {
    const parts: Buffer[] = []; let size = 0, rejected = false;
    request.on('data', (part: Buffer) => {
      size += part.length;
      if (size > limit) { if (!rejected) reject(new PortalError(413, 'O envio excede o limite. Envie menos vendas ou arquivos menores por vez.')); rejected = true; parts.length = 0; return; }
      if (!rejected) parts.push(part);
    });
    request.on('end', () => { if (rejected) return; try { accept(JSON.parse(Buffer.concat(parts).toString('utf8'))); } catch { reject(new PortalError(400, 'O corpo da solicitação deve ser um JSON válido.')); } });
    request.on('error', () => reject(new PortalError(400, 'Não foi possível receber os dados.')));
  });
}
export interface PortalHttpOptions { staticDir?: string; allowedOrigins?: string[]; adminKey?: string; push?: PushService; bodyLimit?: number; backups?: BackupService; cronSecret?: string }
export function createPortalHandler(store: PortalStore, options: PortalHttpOptions = {}) {
  const failedAuth = new Map<string, { count: number; started: number }>();
  const adminHash = options.adminKey ? createHash('sha256').update(options.adminKey).digest() : null;
  return async (request: IncomingMessage, response: ServerResponse) => {
    response.setHeader('X-Content-Type-Options', 'nosniff');
    response.setHeader('Referrer-Policy', 'no-referrer');
    response.setHeader('X-Frame-Options', 'DENY');
    const url = new URL(request.url ?? '/', 'http://localhost');
    try {
      if (url.pathname.startsWith('/api/')) {
        const origin = request.headers.origin;
        const forwardedProtocol = request.headers['x-forwarded-proto'];
        const protocol = forwardedProtocol === 'https' ? 'https' : 'http';
        const sameOrigin = origin === `${protocol}://${request.headers.host}`;
        if (origin && !sameOrigin && !options.allowedOrigins?.includes(origin)) throw new PortalError(403, 'Origem não permitida para este portal.');
        if (origin) { response.setHeader('Access-Control-Allow-Origin', origin); response.setHeader('Vary', 'Origin'); }
        if (request.method === 'OPTIONS') {
          response.writeHead(204, { 'Access-Control-Allow-Headers': 'Authorization, Content-Type, Idempotency-Key', 'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS', 'Access-Control-Max-Age': '600' }); response.end(); return;
        }
        if (url.pathname === '/api/health' && request.method === 'GET') { await store.health(); json(response, 200, { status: 'ok', push: options.push ? 'enabled' : 'disabled' }); return; }
        const identity = request.socket.remoteAddress ?? 'unknown';
        const now = Date.now();
        for (const [key, value] of failedAuth) if (now - value.started > 60_000) failedAuth.delete(key);
        if ((failedAuth.get(identity)?.count ?? 0) >= 30) throw new PortalError(429, 'Muitas tentativas. Aguarde um minuto e tente novamente.');
        const authorization = request.headers.authorization ?? '';
        if (url.pathname === '/api/cron/backups') {
          const supplied = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
          if (!options.cronSecret || options.cronSecret.length < 32 || !timingSafeEqual(createHash('sha256').update(supplied).digest(), createHash('sha256').update(options.cronSecret).digest())) throw new PortalError(401, 'Acesso não autorizado.');
          if (request.method !== 'GET') throw new PortalError(405, 'Método não permitido.');
          if (!options.backups) throw new PortalError(503, 'Backups ainda não configurados.');
          json(response, 200, await options.backups.run('daily')); return;
        }
        if (url.pathname.startsWith('/api/admin/')) {
          if (!adminHash) throw new PortalError(503, 'A administração ainda não foi configurada neste servidor.');
          const supplied = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
          if (supplied.length < 32 || supplied.length > 256 || !timingSafeEqual(createHash('sha256').update(supplied).digest(), adminHash)) {
            const count = failedAuth.get(identity); failedAuth.set(identity, { count: (count?.count ?? 0) + 1, started: count?.started ?? now });
            throw new PortalError(401, 'Chave administrativa inválida.');
          }
          const actor = { id: adminHash.toString('hex'), name: 'Administrador' };
          if (url.pathname === '/api/admin/audit' && request.method === 'GET') { json(response, 200, await readAudit(store, url.searchParams)); return; }
          if (/^\/api\/admin\/reports\/financial(?:\.csv)?$/.test(url.pathname) && request.method === 'GET') {
            const report = await readFinancialReport(store, url.searchParams.get('start') ?? '', url.searchParams.get('end') ?? '', url.searchParams.get('attendantId') ?? '');
            if (url.pathname.endsWith('.csv')) { response.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="bravus-fechamento-${report.start}-${report.end}.csv"`, 'Cache-Control': 'private, no-store' }); response.end(financialCsv(report)); }
            else json(response, 200, report);
            return;
          }
          if (url.pathname.startsWith('/api/admin/backups')) {
            if (!options.backups) throw new PortalError(503, 'Backups ainda não configurados.');
            if (url.pathname === '/api/admin/backups' && request.method === 'GET') json(response, 200, await options.backups.status());
            else if (url.pathname === '/api/admin/backups' && request.method === 'POST') json(response, 201, await options.backups.run('manual'));
            else if (/^\/api\/admin\/backups\/[a-zA-Z0-9-]+$/.test(url.pathname) && request.method === 'GET') {
              const id = url.pathname.split('/').at(-1)!, privateUrl = await options.backups.downloadUrl(id);
              if (privateUrl) { response.writeHead(302, { Location: privateUrl, 'Cache-Control': 'private, no-store' }); response.end(); return; }
              const bytes = await options.backups.download(id);
              response.writeHead(200, { 'Content-Type': 'application/gzip', 'Content-Disposition': `attachment; filename="bravus-backup-${id}.json.gz"`, 'Cache-Control': 'private, no-store' });
              await pipeline(Readable.from([bytes]), response);
            } else throw new PortalError(404, 'Cópia não encontrada.');
            return;
          }
          if (url.pathname.startsWith('/api/admin/push/')) {
            if (!options.push) throw new PortalError(503, 'As notificações push ainda não estão disponíveis neste servidor.');
            const scope = adminHash.toString('hex');
            if (url.pathname === '/api/admin/push/config' && request.method === 'GET') json(response, 200, await options.push.adminConfig(scope));
            else if (url.pathname === '/api/admin/push/subscriptions' && request.method === 'POST') json(response, 201, await options.push.adminSubscribe(scope, await readJson(request, options.bodyLimit)));
            else if (url.pathname === '/api/admin/push/subscriptions' && request.method === 'DELETE') json(response, 200, await options.push.adminUnsubscribe(scope, await readJson(request, options.bodyLimit)));
            else throw new PortalError(404, 'Recurso administrativo não encontrado.');
            return;
          }
          const route = url.pathname.match(/^\/api\/admin\/(attendants|payouts|checkouts|sales)\/([a-zA-Z0-9_-]+)(?:\/(token|costs|cancel))?$/);
          if (url.pathname === '/api/admin/dashboard' && request.method === 'GET') {
            if (options.backups && url.searchParams.get('refresh') !== '1') await options.backups.run('daily').catch(() => undefined);
            json(response, 200, (await store.adminDashboard()));
          }
          else if (url.pathname === '/api/admin/sales' && request.method === 'GET') json(response, 200, (await store.adminSales(url.searchParams.get('status') ?? 'pending', url.searchParams.get('attendantId') ?? '', url.searchParams.get('page') ?? '1')));
          else if (route?.[1] === 'sales' && !route[3] && request.method === 'PATCH') json(response, 200, (await store.reviewSale(route[2], await readJson(request, options.bodyLimit), actor)));
          else if (route?.[1] === 'sales' && route[3] === 'cancel' && request.method === 'POST') json(response, 200, await store.cancelSale(route[2], await readJson(request, options.bodyLimit), actor));
          else if (url.pathname === '/api/admin/payouts' && request.method === 'POST') json(response, 201, await store.recordManualPayout(await readJson(request, options.bodyLimit), String(request.headers['idempotency-key'] ?? ''), actor));
          else if (/^\/api\/admin\/receipts\/[a-zA-Z0-9-]+$/.test(url.pathname) && request.method === 'GET') {
            const receipt = (await store.adminReceipt(url.pathname.split('/').at(-1)!));
            response.writeHead(200, { 'Content-Type': receipt.mime, 'Content-Length': receipt.bytes.byteLength, 'Cache-Control': 'private, no-store', 'Content-Disposition': `inline; filename="comprovante.${receiptExtension(receipt.mime)}"` }); response.end(receipt.bytes);
          }
          else if (url.pathname === '/api/admin/attendants' && request.method === 'POST') json(response, 201, (await store.adminCreateAttendant(await readJson(request, options.bodyLimit), actor)));
          else if (route?.[1] === 'attendants' && route[3] === 'token' && request.method === 'POST') json(response, 200, (await store.rotateToken(route[2], actor)));
          else if (route?.[1] === 'attendants' && route[3] === 'costs' && request.method === 'GET') {
            const date = url.searchParams.get('date') ?? '';
            json(response, 200, (await store.adminCosts(route[2], date)));
          }
          else if (route?.[1] === 'attendants' && route[3] === 'costs' && request.method === 'POST') { (await store.adminSetCosts(route[2], await readJson(request, options.bodyLimit), actor)); json(response, 200, { saved: true }); }
          else if (route?.[1] === 'attendants' && !route[3] && request.method === 'PATCH') { (await store.setAttendantActive(route[2], await readJson(request, options.bodyLimit), actor)); json(response, 200, { saved: true }); }
          else if (route?.[1] === 'attendants' && !route[3] && request.method === 'DELETE') json(response, 200, await store.deleteRevokedAccount(route[2], actor));
          else if (route?.[1] === 'checkouts' && !route[3] && request.method === 'PATCH') { (await store.adminSetCheckout(route[2], await readJson(request, options.bodyLimit), actor)); json(response, 200, { saved: true }); }
          else if (route?.[1] === 'payouts' && !route[3] && request.method === 'PATCH') {
            const input = await readJson(request, options.bodyLimit) as { status?: unknown; note?: unknown } | null;
            if (!input || typeof input.status !== 'string' || typeof input.note !== 'string') throw new PortalError(400, 'Informe o status e a observação do pagamento.');
            (await store.markPayout(route[2], input.status as 'paid' | 'cancelled', input.note, actor)); json(response, 200, { saved: true });
          } else throw new PortalError(404, 'Recurso administrativo não encontrado.');
          return;
        }
        let auth;
        try { auth = (await store.authenticate(authorization.startsWith('Bearer ') ? authorization.slice(7) : '')); }
        catch (error) { const count = failedAuth.get(identity); failedAuth.set(identity, { count: (count?.count ?? 0) + 1, started: count?.started ?? now }); throw error; }
        if (url.pathname === '/api/ranking' && request.method === 'GET') {
          const period = url.searchParams.get('period') ?? 'last30';
          if (!Object.hasOwn(periodLabels, period) && period !== 'last30' && period !== 'custom') throw new PortalError(400, 'Período do ranking inválido.');
          json(response, 200, await store.ranking(auth, period as RankingPeriod, url.searchParams.get('start') ?? '', url.searchParams.get('end') ?? ''));
          return;
        }
        const requestedPeriod = url.searchParams.get('period') ?? 'today';
        if (!Object.hasOwn(periodLabels, requestedPeriod)) throw new PortalError(400, 'Período inválido.');
        const period = requestedPeriod as Period;
        if (url.pathname.startsWith('/api/push/')) {
          if (!options.push) throw new PortalError(503, 'As notificações push ainda não estão disponíveis neste servidor.');
          if (url.pathname === '/api/push/config' && request.method === 'GET') json(response, 200, (await options.push.config(auth)));
          else if (url.pathname === '/api/push/subscriptions' && request.method === 'POST') json(response, 201, (await options.push.subscribe(auth, await readJson(request, options.bodyLimit))));
          else if (url.pathname === '/api/push/subscriptions' && request.method === 'DELETE') json(response, 200, (await options.push.unsubscribe(auth, await readJson(request, options.bodyLimit))));
          else throw new PortalError(404, 'Recurso não encontrado.');
        }
        else if (url.pathname === '/api/portal' && request.method === 'GET') json(response, 200, { ...(await store.portal(auth, period)), maxRequestBytes: options.bodyLimit ?? BODY_LIMIT });
        else if (url.pathname === '/api/profile' && request.method === 'PATCH') json(response, 200, (await store.saveProfile(auth, await readJson(request, options.bodyLimit))));
        else if (url.pathname === '/api/partner/ads' && request.method === 'GET') json(response, 200, await store.partnerAds(auth, url.searchParams.get('date') ?? ''));
        else if (url.pathname === '/api/partner/ads' && request.method === 'POST') json(response, 200, await store.savePartnerAds(auth, await readJson(request, options.bodyLimit)));
        else if (url.pathname === '/api/sales' && request.method === 'POST') {
          const batch = await readJson(request, options.bodyLimit), result = (await store.recordSales(auth, batch, String(request.headers['idempotency-key'] ?? '')));
          if (!result.duplicate && options.push) await Promise.allSettled([
            options.push.notifySale(auth, batch as SaleBatch),
            ...(adminHash ? [options.push.notifyAdminSale(adminHash.toString('hex'), auth, batch as SaleBatch)] : []),
          ]);
          json(response, 200, result);
        }
        else if (url.pathname === '/api/payouts' && request.method === 'POST') throw new PortalError(410, 'As solicitações de repasse foram desativadas. Os pagamentos são registrados manualmente pela administração.');
        else if (/^\/api\/receipts\/[a-zA-Z0-9-]+$/.test(url.pathname) && request.method === 'GET') {
          const receipt = (await store.receipt(auth, url.pathname.split('/').at(-1)!));
          response.writeHead(200, { 'Content-Type': receipt.mime, 'Content-Length': receipt.bytes.byteLength, 'Cache-Control': 'private, no-store', 'Content-Disposition': `inline; filename="comprovante.${receiptExtension(receipt.mime)}"` });
          response.end(receipt.bytes);
        } else throw new PortalError(404, 'Recurso não encontrado.');
        return;
      }
      if (request.method !== 'GET' && request.method !== 'HEAD') throw new PortalError(405, 'Método não permitido.');
      if (!options.staticDir) throw new PortalError(404, 'Interface não disponível. Execute npm run build.');
      const root = resolve(options.staticDir);
      const requested = resolve(root, '.' + decodeURIComponent(/^\/parceiro\/?$/.test(url.pathname) ? '/parceiro.html' : url.pathname));
      if (requested !== root && !requested.startsWith(root + sep)) throw new PortalError(404, 'Página não encontrada.');
      let filename = requested;
      try { if (!(await stat(filename)).isFile()) filename = resolve(root, 'index.html'); } catch { filename = resolve(root, 'index.html'); }
      const body = await readFile(filename);
      const types: Record<string, string> = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.webmanifest': 'application/manifest+json' };
      const revalidate = extname(filename) === '.webmanifest' || filename === resolve(root, 'notifications-worker.js');
      response.writeHead(200, { 'Content-Type': types[extname(filename)] ?? 'application/octet-stream', 'Cache-Control': extname(filename) === '.html' ? 'no-store' : revalidate ? 'public, max-age=0, must-revalidate' : 'public, max-age=3600' });
      response.end(request.method === 'HEAD' ? undefined : body);
    } catch (error) {
      if (response.headersSent) { response.end(); return; }
      const status = error instanceof PortalError ? error.status : 500;
      json(response, status, { error: status === 500 ? 'Não foi possível concluir a solicitação. Tente novamente.' : (error as Error).message });
    }
  };
}
export function createPortalServer(store: PortalStore, options: PortalHttpOptions = {}) {
  return createServer(createPortalHandler(store, options));
}
