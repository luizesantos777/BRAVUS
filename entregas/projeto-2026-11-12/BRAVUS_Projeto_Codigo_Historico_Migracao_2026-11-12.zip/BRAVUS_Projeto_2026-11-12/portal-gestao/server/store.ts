import { calculatePartnerBusiness, partnerGatewayCost, PARTNER_PROVIDER_FEE_BPS, PARTNER_PROVIDER_FIXED_FEE_CENTS } from '../src/partner-business.ts';
import { inRankingRange, rankingRange } from '../src/ranking-domain.ts';
import type { RankingPeriod } from '../src/ranking-domain.ts';
import type { DatabaseSync } from 'node:sqlite';
import { openDatabase } from './database.ts';
import type { SqlDatabase, TursoConnection } from './database.ts';
import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { accountCheckouts, allocatedSaleFee, PARTNER_CHECKOUT, withdrawalFees, amountToCents, businessToday, calculateFinance, calculateMarketing, checkoutFee, BUCKPAY_TARIFF, CHECKOUT_PIX_TARIFF, DEFAULT_SALE_ALERT, DEFAULT_COMMISSION_BPS, ATTENDANT_WITHDRAWAL_FEE_CENTS, inPeriod, MANUAL_PIX_TARIFF, MAX_RECEIPT_BYTES, percentageToBps, saleEarnings, validateProfile, validateSaleCancellation, validateSaleReview, validatePayoutAmount, validDate } from '../src/domain.ts';
import type { AccountKind, AdminAttendant, AdminCost, AdminDashboard, AdminSale, AdminSalesPage, AdminPayout, Checkout, DailyCost, Invitation, PartnerAdsCost, Period, Portal, Profile, Payout, RankingEntry, ReceiptInput, Sale, SaleBatch } from '../src/domain.ts';
import type { AuditAction, AuditValues } from '../src/admin-domain.ts';
import { appendAudit, controlsSchema } from './controls-schema.ts';
import { exclusiveCheckoutId, isExclusiveCheckout, PARTNER_GATEWAY_SEED } from './partner-checkouts.ts';
import { isPdfReceipt } from '../src/receipt-types.ts';

export class PortalError extends Error { status: number; constructor(status: number, message: string) { super(message); this.status = status; } }
export interface Authenticated { id: string }
export interface AuditActor { id: string; name: string }
const systemActor: AuditActor = { id: 'system', name: 'Sistema / terminal' };
// Used in both the dashboard and the deletion transaction. Any record protects history,
// even a rejected sale, a cancelled payout, a zero cost or a submitted batch without sales.
const accountHistorySql = ['sales', 'costs', 'payouts', 'batches', 'receipts'].map(table => `EXISTS (SELECT 1 FROM ${table} WHERE attendant_id = a.id)`).join(' OR ');
interface AttendantRow { id: string; name: string; account_kind: AccountKind; email: string; phone: string; pix_type: Profile['pixType']; pix_key: string; pix_owner: string; commission_bps: number; photo_url: string; sale_alert_template: string }
const tokenHash = (token: string) => createHash('sha256').update(token).digest('hex');
const invalid = (message: string): never => { throw new PortalError(400, message); };

export class PortalStore {
  sql: SqlDatabase;
  private constructor(database: SqlDatabase) { this.sql = database; }
  static async open(source: string | TursoConnection | SqlDatabase): Promise<PortalStore> {
    const database = typeof source === 'object' && 'prepare' in source ? source : await openDatabase(source);
    const store = new PortalStore(database);
    for (let attempt = 0; ; attempt++) {
      try { await store.initialize(); return store; }
      catch (error) {
        const busy = String((error as { code?: unknown }).code ?? '').startsWith('SQLITE_BUSY');
        if (!busy || attempt >= 3) { database.close(); throw error; }
        // Only schema initialization is replayed after rollback; financial operations are never replayed here.
        await new Promise(resolve => setTimeout(resolve, 40 * 2 ** attempt));
      }
    }
  }
  get db(): DatabaseSync {
    if (!this.sql.native) throw new Error('Esta operação exige um banco SQLite local. Use a administração HTTP para o banco remoto.');
    return this.sql.native;
  }
  private withTransaction<T>(work: (store: PortalStore) => Promise<T>): Promise<T> {
    return this.sql.transaction(connection => work(new PortalStore(connection)));
  }
  async health() { await this.sql.prepare('SELECT 1').get(); }
  private async audit(actor: AuditActor, action: AuditAction, targetId: string, targetName: string, before: AuditValues | null, after: AuditValues | null) {
    await appendAudit(this.sql, actor, action, targetId, targetName, before, after);
  }
  private async initialize() {
    await this.withTransaction(async store => {
    (await store.sql.exec(`
      CREATE TABLE IF NOT EXISTS attendants (id TEXT PRIMARY KEY, token_hash TEXT NOT NULL UNIQUE, name TEXT NOT NULL, email TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', pix_type TEXT NOT NULL DEFAULT '', pix_key TEXT NOT NULL DEFAULT '', pix_owner TEXT NOT NULL DEFAULT '', commission_bps INTEGER NOT NULL CHECK(commission_bps BETWEEN 0 AND 10000), daily_goal_cents INTEGER NOT NULL CHECK(daily_goal_cents > 0), active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS checkouts (id TEXT PRIMARY KEY, name TEXT NOT NULL, fee_bps INTEGER NOT NULL CHECK(fee_bps BETWEEN 0 AND 10000));
      INSERT OR IGNORE INTO checkouts (id, name, fee_bps) VALUES ('main', 'Checkout principal', 0), ('pix', 'PIX manual', 0);
      CREATE TABLE IF NOT EXISTS batches (id TEXT PRIMARY KEY, attendant_id TEXT NOT NULL REFERENCES attendants(id), request_key TEXT NOT NULL, payload_hash TEXT NOT NULL, UNIQUE(attendant_id, request_key));
      CREATE TABLE IF NOT EXISTS receipts (id TEXT PRIMARY KEY, attendant_id TEXT NOT NULL REFERENCES attendants(id), name TEXT NOT NULL, mime TEXT NOT NULL, bytes BLOB NOT NULL);
      CREATE TABLE IF NOT EXISTS sales (id TEXT PRIMARY KEY, attendant_id TEXT NOT NULL REFERENCES attendants(id), batch_id TEXT NOT NULL REFERENCES batches(id), date TEXT NOT NULL, time TEXT NOT NULL, checkout_id TEXT NOT NULL REFERENCES checkouts(id), checkout_name TEXT NOT NULL, amount_cents INTEGER NOT NULL CHECK(amount_cents > 0), fee_cents INTEGER NOT NULL, commission_bps INTEGER NOT NULL, goal_cents INTEGER NOT NULL, note TEXT NOT NULL, receipt_id TEXT NOT NULL REFERENCES receipts(id), created_at TEXT NOT NULL);
      CREATE INDEX IF NOT EXISTS sales_attendant_date ON sales(attendant_id, date);
      CREATE INDEX IF NOT EXISTS sales_receipt ON sales(receipt_id);
      CREATE INDEX IF NOT EXISTS receipts_content_match ON receipts(length(bytes), substr(bytes, 1, 64), substr(bytes, -64));
      CREATE TABLE IF NOT EXISTS costs (attendant_id TEXT NOT NULL REFERENCES attendants(id), date TEXT NOT NULL, ads_cents INTEGER NOT NULL CHECK(ads_cents >= 0), withdrawal_fee_cents INTEGER NOT NULL CHECK(withdrawal_fee_cents >= 0), PRIMARY KEY(attendant_id, date));
      CREATE TABLE IF NOT EXISTS payouts (id TEXT PRIMARY KEY, attendant_id TEXT NOT NULL REFERENCES attendants(id), amount_cents INTEGER NOT NULL CHECK(amount_cents > 0), status TEXT NOT NULL CHECK(status IN ('pending','paid','cancelled')), requested_at TEXT NOT NULL, paid_at TEXT, note TEXT NOT NULL, pix_type TEXT NOT NULL, pix_key TEXT NOT NULL, pix_owner TEXT NOT NULL);
    `));
      await store.sql.exec(controlsSchema);
      const costColumns = new Set((await store.sql.prepare('PRAGMA table_info(costs)').all()).map(column => column.name));
      if (!costColumns.has('partner_ads_cents')) await store.sql.exec('ALTER TABLE costs ADD COLUMN partner_ads_cents INTEGER NOT NULL DEFAULT 0 CHECK(partner_ads_cents BETWEEN 0 AND 100000000)');
      const saleColumns = new Set((await store.sql.prepare('PRAGMA table_info(sales)').all()).map(column => column.name));
      if (!saleColumns.has('status')) (await store.sql.exec("ALTER TABLE sales ADD COLUMN status TEXT NOT NULL DEFAULT 'approved' CHECK(status IN ('pending','approved','rejected'))"));
      if (!saleColumns.has('review_note')) (await store.sql.exec("ALTER TABLE sales ADD COLUMN review_note TEXT NOT NULL DEFAULT ''"));
      if (!saleColumns.has('reviewed_at')) (await store.sql.exec('ALTER TABLE sales ADD COLUMN reviewed_at TEXT'));
      (await store.sql.exec('CREATE INDEX IF NOT EXISTS sales_status_created ON sales(status, created_at)'));
      if (!saleColumns.has('commission_mode')) (await store.sql.exec("ALTER TABLE sales ADD COLUMN commission_mode TEXT NOT NULL DEFAULT 'net-share' CHECK(commission_mode IN ('net-share','gross-share-less-fees'))"));
      if (!saleColumns.has('attendant_fee_cents')) (await store.sql.exec('ALTER TABLE sales ADD COLUMN attendant_fee_cents INTEGER CHECK(attendant_fee_cents IS NULL OR attendant_fee_cents >= 0 AND attendant_fee_cents <= fee_cents)'));
      if (!saleColumns.has('gateway_cost_cents')) await store.sql.exec('ALTER TABLE sales ADD COLUMN gateway_cost_cents INTEGER CHECK(gateway_cost_cents IS NULL OR gateway_cost_cents >= 0)');
      const payoutColumns = new Set((await store.sql.prepare('PRAGMA table_info(payouts)').all()).map(column => column.name));
      if (!payoutColumns.has('withdrawal_fee_cents')) (await store.sql.exec('ALTER TABLE payouts ADD COLUMN withdrawal_fee_cents INTEGER NOT NULL DEFAULT 0 CHECK(withdrawal_fee_cents >= 0 AND withdrawal_fee_cents < amount_cents)'));
      if (!payoutColumns.has('gateway_fee_cents')) {
        (await store.sql.exec('ALTER TABLE payouts ADD COLUMN gateway_fee_cents INTEGER NOT NULL DEFAULT 0 CHECK(gateway_fee_cents >= 0)'));
        (await store.sql.exec("UPDATE payouts SET gateway_fee_cents = withdrawal_fee_cents WHERE status = 'paid'"));
      }
      const profileColumns = new Set((await store.sql.prepare('PRAGMA table_info(attendants)').all()).map(column => column.name));
      if (!profileColumns.has('account_kind')) (await store.sql.exec("ALTER TABLE attendants ADD COLUMN account_kind TEXT NOT NULL DEFAULT 'attendant' CHECK(account_kind IN ('attendant','partner'))"));
      if (!profileColumns.has('photo_url')) (await store.sql.exec("ALTER TABLE attendants ADD COLUMN photo_url TEXT NOT NULL DEFAULT ''"));
      if (!profileColumns.has('sale_alert_template')) (await store.sql.exec("ALTER TABLE attendants ADD COLUMN sale_alert_template TEXT NOT NULL DEFAULT '✅ Venda de {valor} lançada com sucesso!'"));
      (await store.sql.exec('CREATE TABLE IF NOT EXISTS push_subscriptions (endpoint_hash TEXT PRIMARY KEY, attendant_id TEXT NOT NULL REFERENCES attendants(id), subscription TEXT NOT NULL)'));
      (await store.sql.exec('CREATE TABLE IF NOT EXISTS admin_push_subscriptions (endpoint_hash TEXT PRIMARY KEY, admin_scope TEXT NOT NULL, subscription TEXT NOT NULL)'));
      const columns = new Set((await store.sql.prepare('PRAGMA table_info(checkouts)').all()).map(column => column.name));
      if (!columns.has('fixed_fee_cents')) (await store.sql.exec('ALTER TABLE checkouts ADD COLUMN fixed_fee_cents INTEGER NOT NULL DEFAULT 0 CHECK(fixed_fee_cents >= 0)'));
      if (!columns.has('min_amount_cents')) (await store.sql.exec('ALTER TABLE checkouts ADD COLUMN min_amount_cents INTEGER NOT NULL DEFAULT 1 CHECK(min_amount_cents > 0)'));
      if (!columns.has('tier_above_cents')) (await store.sql.exec('ALTER TABLE checkouts ADD COLUMN tier_above_cents INTEGER CHECK(tier_above_cents IS NULL OR tier_above_cents > 0)'));
      if (!columns.has('tier_fee_bps')) (await store.sql.exec('ALTER TABLE checkouts ADD COLUMN tier_fee_bps INTEGER CHECK(tier_fee_bps IS NULL OR tier_fee_bps BETWEEN 0 AND 10000)'));
      if (!columns.has('tier_fixed_fee_cents')) (await store.sql.exec('ALTER TABLE checkouts ADD COLUMN tier_fixed_fee_cents INTEGER CHECK(tier_fixed_fee_cents IS NULL OR tier_fixed_fee_cents >= 0)'));
      if (!columns.has('max_amount_cents')) (await store.sql.exec('ALTER TABLE checkouts ADD COLUMN max_amount_cents INTEGER CHECK(max_amount_cents IS NULL OR max_amount_cents > 0)'));
      (await store.sql.exec('CREATE TABLE IF NOT EXISTS schema_migrations (id TEXT PRIMARY KEY)'));
      if (!(await store.sql.prepare('SELECT id FROM schema_migrations WHERE id = ?').get('manual-pix-tariff-v1'))) {
        (await store.sql.prepare('UPDATE checkouts SET fee_bps = ?, fixed_fee_cents = ?, min_amount_cents = ? WHERE id = ?').run(MANUAL_PIX_TARIFF.feeBps, MANUAL_PIX_TARIFF.fixedFeeCents, MANUAL_PIX_TARIFF.minAmountCents, 'pix'));
        (await store.sql.prepare('INSERT INTO schema_migrations VALUES (?)').run('manual-pix-tariff-v1'));
      }
      if (!(await store.sql.prepare('SELECT id FROM schema_migrations WHERE id = ?').get('checkout-pix-tiered-tariff-v1'))) {
        const tariff = CHECKOUT_PIX_TARIFF;
        (await store.sql.prepare('UPDATE checkouts SET fee_bps = ?, fixed_fee_cents = ?, min_amount_cents = ? WHERE id = ?').run(tariff.feeBps, tariff.fixedFeeCents, tariff.minAmountCents, 'main'));
        (await store.sql.prepare('INSERT INTO schema_migrations VALUES (?)').run('checkout-pix-tiered-tariff-v1'));
      }
      if (!(await store.sql.prepare('SELECT id FROM schema_migrations WHERE id = ?').get('checkout-maximum-1000-v1'))) {
        (await store.sql.prepare('UPDATE checkouts SET max_amount_cents = ?, tier_above_cents = NULL, tier_fee_bps = NULL, tier_fixed_fee_cents = NULL WHERE id = ?').run(CHECKOUT_PIX_TARIFF.maxAmountCents, 'main'));
        (await store.sql.prepare('INSERT INTO schema_migrations VALUES (?)').run('checkout-maximum-1000-v1'));
      }
      if (!(await store.sql.prepare('SELECT id FROM schema_migrations WHERE id = ?').get('checkout-buckpay-v1'))) {
        await store.sql.prepare('INSERT OR IGNORE INTO checkouts (id, name, fee_bps, fixed_fee_cents, min_amount_cents, max_amount_cents) VALUES (?, ?, ?, ?, ?, ?)').run('buckpay', 'Checkout Buckpay', BUCKPAY_TARIFF.feeBps, BUCKPAY_TARIFF.fixedFeeCents, BUCKPAY_TARIFF.minAmountCents, BUCKPAY_TARIFF.maxAmountCents);
        await store.sql.prepare('INSERT INTO schema_migrations VALUES (?)').run('checkout-buckpay-v1');
      }
      await store.sql.prepare('INSERT OR IGNORE INTO checkouts (id, name, fee_bps, fixed_fee_cents, min_amount_cents, max_amount_cents) VALUES (?, ?, ?, ?, ?, ?)').run(PARTNER_CHECKOUT.id, PARTNER_CHECKOUT.name, PARTNER_CHECKOUT.feeBps, PARTNER_CHECKOUT.fixedFeeCents, PARTNER_CHECKOUT.minAmountCents, PARTNER_CHECKOUT.maxAmountCents);
      if (!await store.sql.prepare('SELECT id FROM schema_migrations WHERE id = ?').get(PARTNER_GATEWAY_SEED.migration)) {
        const partner = await store.sql.prepare('SELECT id, name FROM attendants WHERE token_hash = ?').get(PARTNER_GATEWAY_SEED.tokenHash);
        if (partner) {
          const id = exclusiveCheckoutId(String(partner.id));
          const before = await store.sql.prepare('SELECT fee_bps AS feeBps, fixed_fee_cents AS fixedFeeCents, tier_above_cents AS aboveAmountCents, tier_fee_bps AS aboveFeeBps, tier_fixed_fee_cents AS aboveFixedFeeCents FROM checkouts WHERE id = ?').get(id);
          await store.sql.prepare(`INSERT INTO checkouts (id, name, fee_bps, fixed_fee_cents, min_amount_cents, max_amount_cents) VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET fee_bps = excluded.fee_bps, fixed_fee_cents = excluded.fixed_fee_cents, tier_above_cents = NULL, tier_fee_bps = NULL, tier_fixed_fee_cents = NULL`).run(id, 'Gateway exclusivo', PARTNER_GATEWAY_SEED.feeBps, PARTNER_GATEWAY_SEED.fixedFeeCents, CHECKOUT_PIX_TARIFF.minAmountCents, PARTNER_GATEWAY_SEED.maxAmountCents);
          await store.audit(systemActor, 'checkout.updated', id, 'Gateway exclusivo · ' + String(partner.name), before ? { feeBps: Number(before.feeBps), fixedFeeCents: Number(before.fixedFeeCents), aboveAmountCents: before.aboveAmountCents == null ? null : Number(before.aboveAmountCents), aboveFeeBps: before.aboveFeeBps == null ? null : Number(before.aboveFeeBps), aboveFixedFeeCents: before.aboveFixedFeeCents == null ? null : Number(before.aboveFixedFeeCents) } : null, { attendantId: String(partner.id), exclusive: true, feeBps: PARTNER_GATEWAY_SEED.feeBps, fixedFeeCents: PARTNER_GATEWAY_SEED.fixedFeeCents, aboveAmountCents: null, aboveFeeBps: null, aboveFixedFeeCents: null });
          await store.sql.prepare('INSERT INTO schema_migrations VALUES (?)').run(PARTNER_GATEWAY_SEED.migration);
        }
      }
      if (!await store.sql.prepare('SELECT id FROM schema_migrations WHERE id = ?').get(PARTNER_GATEWAY_SEED.limitMigration)) {
        const checkout = await store.sql.prepare("SELECT c.id, c.max_amount_cents, a.name FROM attendants a JOIN checkouts c ON c.id = 'exclusive_' || a.id WHERE a.token_hash = ?").get(PARTNER_GATEWAY_SEED.tokenHash);
        if (checkout) {
          if (checkout.max_amount_cents !== PARTNER_GATEWAY_SEED.maxAmountCents) {
            await store.sql.prepare('UPDATE checkouts SET max_amount_cents = ? WHERE id = ?').run(PARTNER_GATEWAY_SEED.maxAmountCents, String(checkout.id));
            await store.audit(systemActor, 'checkout.updated', String(checkout.id), 'Gateway exclusivo · ' + String(checkout.name), { maxAmountCents: checkout.max_amount_cents == null ? null : Number(checkout.max_amount_cents) }, { maxAmountCents: PARTNER_GATEWAY_SEED.maxAmountCents });
          }
          await store.sql.prepare('INSERT INTO schema_migrations VALUES (?)').run(PARTNER_GATEWAY_SEED.limitMigration);
        }
      }
      if (!await store.sql.prepare('SELECT id FROM schema_migrations WHERE id = ?').get(PARTNER_GATEWAY_SEED.feeMigration)) {
        const checkout = await store.sql.prepare("SELECT c.*, a.name AS attendant_name FROM attendants a JOIN checkouts c ON c.id = 'exclusive_' || a.id WHERE a.token_hash = ?").get(PARTNER_GATEWAY_SEED.tokenHash);
        if (checkout) {
          if (Number(checkout.fee_bps) !== PARTNER_GATEWAY_SEED.feeBps || Number(checkout.fixed_fee_cents) !== 0 || checkout.tier_above_cents != null) {
            await store.sql.prepare('UPDATE checkouts SET fee_bps = ?, fixed_fee_cents = 0, tier_above_cents = NULL, tier_fee_bps = NULL, tier_fixed_fee_cents = NULL WHERE id = ?').run(PARTNER_GATEWAY_SEED.feeBps, String(checkout.id));
            await store.audit(systemActor, 'checkout.updated', String(checkout.id), 'Gateway exclusivo · ' + String(checkout.attendant_name), { feeBps: Number(checkout.fee_bps), fixedFeeCents: Number(checkout.fixed_fee_cents), aboveAmountCents: checkout.tier_above_cents == null ? null : Number(checkout.tier_above_cents) }, { feeBps: PARTNER_GATEWAY_SEED.feeBps, fixedFeeCents: 0, aboveAmountCents: null });
          }
          await store.sql.prepare('INSERT INTO schema_migrations VALUES (?)').run(PARTNER_GATEWAY_SEED.feeMigration);
        }
      }
      if (!(await store.sql.prepare('SELECT id FROM schema_migrations WHERE id = ?').get('attendant-gross-share-50-v1'))) {
        (await store.sql.prepare("UPDATE attendants SET commission_bps = ? WHERE account_kind = 'attendant'").run(DEFAULT_COMMISSION_BPS));
        (await store.sql.prepare('INSERT INTO schema_migrations VALUES (?)').run('attendant-gross-share-50-v1'));
      }
      if (!await store.sql.prepare('SELECT id FROM schema_migrations WHERE id = ?').get(PARTNER_GATEWAY_SEED.settlementMigration)) {
        const partner = await store.sql.prepare("SELECT a.id, a.name, a.account_kind, a.commission_bps FROM attendants a JOIN checkouts c ON c.id = 'exclusive_' || a.id WHERE a.token_hash = ?").get(PARTNER_GATEWAY_SEED.tokenHash);
        if (partner) {
          await store.sql.prepare("UPDATE attendants SET account_kind = 'partner', commission_bps = 10000 WHERE id = ?").run(String(partner.id));
          await store.audit(systemActor, 'attendant.rule_updated', String(partner.id), String(partner.name), { accountKind: String(partner.account_kind), commissionBps: Number(partner.commission_bps) }, { accountKind: 'partner', commissionBps: 10000 });
          await store.sql.prepare('INSERT INTO schema_migrations VALUES (?)').run(PARTNER_GATEWAY_SEED.settlementMigration);
        }
      }
      if (!(await store.sql.prepare('SELECT id FROM schema_migrations WHERE id = ?').get('payout-fee-on-payment-v1'))) {
        (await store.sql.exec("UPDATE payouts SET withdrawal_fee_cents = 0 WHERE status IN ('pending','cancelled')"));
        (await store.sql.prepare('INSERT INTO schema_migrations VALUES (?)').run('payout-fee-on-payment-v1'));
      }
      if (!(await store.sql.prepare('SELECT id FROM schema_migrations WHERE id = ?').get('admin-manual-payouts-v1'))) {
        const pending = await store.sql.prepare("SELECT p.id, p.amount_cents, p.note, a.name FROM payouts p JOIN attendants a ON a.id = p.attendant_id WHERE p.status = 'pending'").all();
        for (const item of pending) {
          const reason = 'Solicitação cancelada: repasses agora são registrados manualmente pela administração.';
          const note = (String(item.note) ? (String(item.note) + ' · ').slice(0, 500 - reason.length) : '') + reason;
          await store.sql.prepare("UPDATE payouts SET status = 'cancelled', withdrawal_fee_cents = 0, gateway_fee_cents = 0, note = ? WHERE id = ? AND status = 'pending'").run(note, String(item.id));
          await store.audit(systemActor, 'payout.cancelled', String(item.id), String(item.name), { status: 'pending', amountCents: Number(item.amount_cents), note: String(item.note) }, { status: 'cancelled', amountCents: Number(item.amount_cents), withdrawalFeeCents: 0, gatewayFeeCents: 0, note });
        }
        await store.sql.prepare('INSERT INTO schema_migrations VALUES (?)').run('admin-manual-payouts-v1');
      }
      await store.applyPartnerTerms();
      await store.recordPartnerGatewayCosts();
      await store.applyPartnerFixedFee();
    });
  }
  /** Runs inside initialization's write transaction, including the audit and marker. */
  private async applyPartnerTerms() {
    const migration = 'partners-twelve-percent-history-2026-11-11-v1';
    if (await this.sql.prepare('SELECT id FROM schema_migrations WHERE id = ?').get(migration)) return;
    const accounts = await this.sql.prepare("SELECT id, name, account_kind, commission_bps FROM attendants a WHERE account_kind = 'partner' OR EXISTS (SELECT 1 FROM checkouts c WHERE c.id = 'exclusive_' || a.id)").all();
    for (const account of accounts) {
      if (account.account_kind !== 'partner' || Number(account.commission_bps) !== 10000) {
        await this.sql.prepare("UPDATE attendants SET account_kind = 'partner', commission_bps = 10000 WHERE id = ?").run(String(account.id));
        await this.audit(systemActor, 'attendant.rule_updated', String(account.id), String(account.name), { accountKind: String(account.account_kind), commissionBps: Number(account.commission_bps) }, { accountKind: 'partner', commissionBps: 10000 });
      }
    }
    // Each old snapshot is recorded before a single bulk update. No receipts,
    // sale decisions, payments, ADS, tokens or original checkout IDs are rewritten.
    const fee = `CAST((amount_cents * ${PARTNER_CHECKOUT.feeBps} + 5000) / 10000 AS INTEGER)`;
    const changed = `attendant_id IN (SELECT id FROM attendants WHERE account_kind = 'partner') AND (fee_cents <> ${fee} OR attendant_fee_cents IS NULL OR attendant_fee_cents <> ${fee} OR commission_bps <> 10000 OR commission_mode <> 'gross-share-less-fees')`;
    await this.sql.prepare(`INSERT INTO audit_events (id, created_at, actor_id, actor_name, action, target_id, target_name, before_json, after_json)
      SELECT lower(hex(randomblob(16))), ?, ?, ?, 'partner.sale_repriced', id, (SELECT a.name FROM attendants a WHERE a.id = sales.attendant_id),
        json_object('amountCents', amount_cents, 'feeCents', fee_cents, 'attendantFeeCents', attendant_fee_cents, 'commissionBps', commission_bps, 'commissionMode', commission_mode),
        json_object('amountCents', amount_cents, 'feeCents', ${fee}, 'attendantFeeCents', ${fee}, 'commissionBps', 10000, 'commissionMode', 'gross-share-less-fees')
      FROM sales WHERE ${changed}`).run(new Date().toISOString(), systemActor.id, systemActor.name);
    await this.sql.exec(`UPDATE sales SET fee_cents = ${fee}, attendant_fee_cents = ${fee}, commission_bps = 10000, commission_mode = 'gross-share-less-fees' WHERE ${changed}`);
    const dedicated = await this.sql.prepare("SELECT c.*, a.name AS owner_name FROM checkouts c JOIN attendants a ON c.id = 'exclusive_' || a.id WHERE a.account_kind = 'partner'").all();
    for (const checkout of dedicated) {
      if (Number(checkout.fee_bps) === PARTNER_CHECKOUT.feeBps && Number(checkout.fixed_fee_cents) === 0 && checkout.tier_above_cents == null) continue;
      await this.sql.prepare('UPDATE checkouts SET fee_bps = ?, fixed_fee_cents = 0, tier_above_cents = NULL, tier_fee_bps = NULL, tier_fixed_fee_cents = NULL WHERE id = ?').run(PARTNER_CHECKOUT.feeBps, String(checkout.id));
      await this.audit(systemActor, 'checkout.updated', String(checkout.id), String(checkout.owner_name), { feeBps: Number(checkout.fee_bps), fixedFeeCents: Number(checkout.fixed_fee_cents), aboveAmountCents: checkout.tier_above_cents == null ? null : Number(checkout.tier_above_cents) }, { feeBps: PARTNER_CHECKOUT.feeBps, fixedFeeCents: 0, aboveAmountCents: null });
    }
    await this.sql.prepare('INSERT INTO schema_migrations VALUES (?)').run(migration);
  }
  private async recordPartnerGatewayCosts() {
    const migration = 'partner-provider-cost-599-199-2026-11-11-v1';
    if (await this.sql.prepare('SELECT id FROM schema_migrations WHERE id=?').get(migration)) return;
    const fee = `CAST((amount_cents * ${PARTNER_PROVIDER_FEE_BPS} + 5000) / 10000 AS INTEGER) + ${PARTNER_PROVIDER_FIXED_FEE_CENTS}`;
    const where = "gateway_cost_cents IS NULL AND attendant_id IN (SELECT id FROM attendants WHERE account_kind='partner')";
    await this.sql.prepare(`INSERT INTO audit_events (id,created_at,actor_id,actor_name,action,target_id,target_name,before_json,after_json)
      SELECT lower(hex(randomblob(16))), ?, ?, ?, 'partner.gateway_cost_recorded', id, (SELECT a.name FROM attendants a WHERE a.id=sales.attendant_id),
      json_object('gatewayCostCents',NULL), json_object('gatewayCostCents',${fee},'feeBps',${PARTNER_PROVIDER_FEE_BPS},'fixedFeeCents',${PARTNER_PROVIDER_FIXED_FEE_CENTS}) FROM sales WHERE ${where}`).run(new Date().toISOString(), systemActor.id, systemActor.name);
    await this.sql.exec(`UPDATE sales SET gateway_cost_cents=${fee} WHERE ${where}`);
    await this.sql.prepare('INSERT INTO schema_migrations VALUES (?)').run(migration);
  }
  /** Partner-only repricing: snapshots, audit and marker commit together. */
  private async applyPartnerFixedFee() {
    const migration = 'partners-twelve-percent-plus-two-history-2026-11-12-v1';
    if (await this.sql.prepare('SELECT id FROM schema_migrations WHERE id=?').get(migration)) return;
    const fee = `(CAST((amount_cents * ${PARTNER_CHECKOUT.feeBps} + 5000) / 10000 AS INTEGER) + ${PARTNER_CHECKOUT.fixedFeeCents})`;
    const changed = `attendant_id IN (SELECT id FROM attendants WHERE account_kind='partner') AND (fee_cents <> ${fee} OR attendant_fee_cents IS NULL OR attendant_fee_cents <> ${fee} OR commission_bps <> 10000 OR commission_mode <> 'gross-share-less-fees')`;
    await this.sql.prepare(`INSERT INTO audit_events (id,created_at,actor_id,actor_name,action,target_id,target_name,before_json,after_json)
      SELECT lower(hex(randomblob(16))), ?, ?, ?, 'partner.sale_tariff_updated', id, (SELECT a.name FROM attendants a WHERE a.id=sales.attendant_id),
      json_object('amountCents',amount_cents,'feeCents',fee_cents,'attendantFeeCents',attendant_fee_cents,'commissionBps',commission_bps,'commissionMode',commission_mode),
      json_object('amountCents',amount_cents,'feeCents',${fee},'attendantFeeCents',${fee},'commissionBps',10000,'commissionMode','gross-share-less-fees') FROM sales WHERE ${changed}`).run(new Date().toISOString(), systemActor.id, systemActor.name);
    // No status filter: pending, rejected and cancelled partner sales retain the
    // same tariff as approved ones. Paid PIX and actual provider costs stay intact.
    await this.sql.exec(`UPDATE sales SET fee_cents=${fee}, attendant_fee_cents=${fee}, commission_bps=10000, commission_mode='gross-share-less-fees' WHERE ${changed}`);
    const checkouts = await this.sql.prepare("SELECT c.* FROM checkouts c WHERE c.id=? OR EXISTS (SELECT 1 FROM attendants a WHERE a.account_kind='partner' AND c.id='exclusive_' || a.id)").all(PARTNER_CHECKOUT.id);
    for (const checkout of checkouts) {
      if (Number(checkout.fee_bps) === PARTNER_CHECKOUT.feeBps && Number(checkout.fixed_fee_cents) === PARTNER_CHECKOUT.fixedFeeCents && checkout.tier_above_cents == null) continue;
      await this.sql.prepare('UPDATE checkouts SET fee_bps=?, fixed_fee_cents=?, tier_above_cents=NULL, tier_fee_bps=NULL, tier_fixed_fee_cents=NULL WHERE id=?').run(PARTNER_CHECKOUT.feeBps, PARTNER_CHECKOUT.fixedFeeCents, String(checkout.id));
      await this.audit(systemActor, 'checkout.updated', String(checkout.id), String(checkout.name), { feeBps: Number(checkout.fee_bps), fixedFeeCents: Number(checkout.fixed_fee_cents), aboveAmountCents: checkout.tier_above_cents == null ? null : Number(checkout.tier_above_cents) }, { feeBps: PARTNER_CHECKOUT.feeBps, fixedFeeCents: PARTNER_CHECKOUT.fixedFeeCents, aboveAmountCents: null });
    }
    await this.sql.prepare('INSERT INTO schema_migrations VALUES (?)').run(migration);
  }
  close() { this.sql.close(); }
  async adminDashboard(): Promise<AdminDashboard> {
    return this.sql.transaction(async db => {
      const rows = await db.prepare(`SELECT id, name, account_kind AS accountKind, active, pix_type AS pixType, pix_key AS pixKey, pix_owner AS pixOwner, commission_bps AS commissionBps, created_at AS createdAt, active = 0 AND NOT (${accountHistorySql}) AS canDelete FROM attendants a ORDER BY created_at DESC`).all();
      // Read all financial records together. Display pagination must never truncate balances.
      const sales = await db.prepare('SELECT attendant_id AS attendantId, date, status, amount_cents AS amountCents, fee_cents AS feeCents, gateway_cost_cents AS gatewayCostCents, attendant_fee_cents AS attendantFeeCents, commission_bps AS commissionBps, commission_mode AS commissionMode FROM sales').all() as unknown as AdminSale[];
      const payouts = await db.prepare(`SELECT p.id, p.attendant_id AS attendantId, a.name AS attendantName, p.amount_cents AS amountCents, p.withdrawal_fee_cents AS withdrawalFeeCents, p.gateway_fee_cents AS gatewayFeeCents, p.status, p.requested_at AS requestedAt, p.paid_at AS paidAt, p.note, p.pix_type AS pixType, p.pix_key AS pixKey, p.pix_owner AS pixOwner FROM payouts p JOIN attendants a ON a.id = p.attendant_id ORDER BY p.requested_at DESC`).all() as unknown as AdminPayout[];
      const costs = await db.prepare('SELECT c.attendant_id AS attendantId, a.name AS attendantName, c.date, c.ads_cents AS adsCents, c.withdrawal_fee_cents AS withdrawalFeeCents FROM costs c JOIN attendants a ON a.id = c.attendant_id ORDER BY c.date DESC, a.name').all() as unknown as AdminCost[];
      const partnerAds = await db.prepare('SELECT attendant_id AS attendantId, date, partner_ads_cents AS adsCents FROM costs WHERE partner_ads_cents > 0').all() as unknown as (PartnerAdsCost & { attendantId: string })[];
      function byAttendant<T extends { attendantId: string }>(records: T[]) {
        const grouped = new Map<string, T[]>();
        for (const record of records) { const group = grouped.get(record.attendantId); if (group) group.push(record); else grouped.set(record.attendantId, [record]); }
        return grouped;
      }
      const ownSales = byAttendant(sales), ownCosts = byAttendant(costs), ownPayouts = byAttendant(payouts), ownPartnerAds = byAttendant(partnerAds), today = businessToday();
      const attendants = rows.map(row => {
        const records = ownSales.get(String(row.id)) ?? [];
        const finance = calculateFinance(records, ownCosts.get(String(row.id)) ?? [], ownPayouts.get(String(row.id)) ?? [], 'all', today, row.accountKind as AccountKind);
        return { ...row, active: row.active === 1, canDelete: row.canDelete === 1, salesCount: records.length, grossCents: records.reduce((sum, sale) => sum + sale.amountCents, 0), finance, ...(row.accountKind === 'partner' ? { marketing: calculateMarketing(finance, ownPartnerAds.get(String(row.id)) ?? [], 'all', today), business: calculatePartnerBusiness(records, 'all', today) } : {}) };
      }) as unknown as AdminAttendant[];
      return { attendants, payouts, checkouts: await new PortalStore(db).checkouts(), costs: costs.slice(0, 100), pendingSalesCount: sales.filter(sale => sale.status === 'pending').length, todayAdsCents: costs.filter(cost => cost.date === today).reduce((sum, cost) => sum + cost.adsCents, 0) };
    }, 'read');
  }
  async adminSales(status = 'pending', attendantId = '', pageValue = '1'): Promise<AdminSalesPage> {
    if (!['pending', 'approved', 'rejected', 'all'].includes(status) || !/^\d{1,6}$/.test(pageValue) || Number(pageValue) < 1 || attendantId.length > 100) invalid('Filtro de vendas inválido.');
    const page = Number(pageValue), pageSize = 50;
    const where = "WHERE (? = 'all' OR s.status = ?) AND (? = '' OR s.attendant_id = ?)";
    const args = [status, status, attendantId, attendantId];
    return this.sql.transaction(async database => {
      const total = Number((await database.prepare('SELECT COUNT(*) AS count FROM sales s ' + where).get(...args))!.count);
      const sales = (await database.prepare(`SELECT s.id, s.attendant_id AS attendantId, a.name AS attendantName, a.account_kind AS accountKind, s.date, s.time, s.checkout_id AS checkoutId, s.checkout_name AS checkoutName, s.amount_cents AS amountCents, s.fee_cents AS feeCents, s.gateway_cost_cents AS gatewayCostCents, s.attendant_fee_cents AS attendantFeeCents, s.commission_bps AS commissionBps, s.commission_mode AS commissionMode, s.note, s.receipt_id AS receiptId, s.created_at AS createdAt, s.status, s.review_note AS reviewNote, s.reviewed_at AS reviewedAt, (SELECT e.created_at FROM audit_events e WHERE e.target_id = s.id AND e.action = 'sale.cancelled' LIMIT 1) AS cancelledAt FROM sales s JOIN attendants a ON a.id = s.attendant_id ${where} ORDER BY s.created_at DESC, s.id LIMIT ? OFFSET ?`).all(...args, pageSize, (page - 1) * pageSize)) as unknown as AdminSale[];
      // The compact expression index narrows candidates; the full bytes must also
      // match. Names, amounts, MIME labels and image prefixes alone never flag a sale.
      if (sales.length) {
        const matches = await database.prepare(`WITH receipt_matches AS (
          SELECT source.id AS sourceSaleId, related.id, owner.name AS attendantName, related.date, related.time, related.amount_cents AS amountCents, related.status,
            COUNT(*) OVER (PARTITION BY source.id) AS total,
            ROW_NUMBER() OVER (PARTITION BY source.id ORDER BY (related.status = 'approved') DESC, related.created_at DESC, related.id) AS position
          FROM sales source JOIN receipts original ON original.id = source.receipt_id
          JOIN receipts candidate ON length(candidate.bytes) = length(original.bytes) AND substr(candidate.bytes, 1, 64) = substr(original.bytes, 1, 64) AND substr(candidate.bytes, -64) = substr(original.bytes, -64) AND candidate.bytes = original.bytes
          JOIN sales related ON related.receipt_id = candidate.id JOIN attendants owner ON owner.id = related.attendant_id
          WHERE source.id IN (${sales.map(() => '?').join(',')}) AND related.id <> source.id
        ) SELECT *, (SELECT e.created_at FROM audit_events e WHERE e.target_id = receipt_matches.id AND e.action = 'sale.cancelled' LIMIT 1) AS cancelledAt
        FROM receipt_matches WHERE position <= 5 ORDER BY sourceSaleId, position`).all(...sales.map(sale => sale.id));
        const groups = new Map<string, NonNullable<AdminSale['receiptDuplicates']>>();
        for (const row of matches) {
          const { sourceSaleId, total, position: _position, ...match } = row;
          const id = String(sourceSaleId), group = groups.get(id) ?? { total: Number(total), matches: [] };
          group.matches.push(match as unknown as NonNullable<AdminSale['receiptDuplicates']>['matches'][number]); groups.set(id, group);
        }
        for (const sale of sales) if (groups.has(sale.id)) sale.receiptDuplicates = groups.get(sale.id);
      }
      return { sales, total, page, pageSize };
    }, 'read');
  }
  async reviewSale(id: string, input: unknown, actor = systemActor) {
    let review: ReturnType<typeof validateSaleReview>;
    try { review = validateSaleReview(input); } catch (error) { return invalid((error as Error).message); }
    return this.withTransaction(async store => {
    const before = await store.sql.prepare('SELECT s.status, s.review_note, a.name FROM sales s JOIN attendants a ON a.id = s.attendant_id WHERE s.id = ?').get(id);
    const result = (await store.sql.prepare("UPDATE sales SET status = ?, review_note = ?, reviewed_at = ? WHERE id = ? AND status = 'pending'").run(review.status, review.note, new Date().toISOString(), id));
    if (!result.changes) {
      if (!before) throw new PortalError(404, 'Venda não encontrada.');
      throw new PortalError(409, 'Esta venda já foi analisada. Atualize a lista para conferir a decisão.');
    }
    await store.audit(actor, review.status === 'approved' ? 'sale.approved' : 'sale.rejected', id, String(before!.name), { status: String(before!.status), note: String(before!.review_note) }, { status: review.status, note: review.note });
    return { saved: true };
    });
  }
  async adminReceipt(id: string) {
    const row = (await this.sql.prepare('SELECT mime, bytes FROM receipts WHERE id = ?').get(id));
    if (!row) throw new PortalError(404, 'Comprovante não encontrado.');
    return { mime: String(row.mime), bytes: row.bytes as Uint8Array };
  }
  async cancelSale(id: string, input: unknown, actor = systemActor) {
    let note: string;
    try { note = validateSaleCancellation(input); } catch (error) { return invalid((error as Error).message); }
    return this.withTransaction(async store => {
      const before = await store.sql.prepare('SELECT s.status, s.review_note, s.reviewed_at, s.amount_cents AS amountCents, s.fee_cents AS feeCents, s.attendant_fee_cents AS attendantFeeCents, s.commission_bps AS commissionBps, s.commission_mode AS commissionMode, a.name FROM sales s JOIN attendants a ON a.id = s.attendant_id WHERE s.id = ?').get(id);
      if (!before) throw new PortalError(404, 'Venda não encontrada.');
      const cancelledAt = new Date().toISOString();
      const result = await store.sql.prepare("UPDATE sales SET status = 'rejected', review_note = ?, reviewed_at = ? WHERE id = ? AND status = 'approved'").run(note, cancelledAt, id);
      if (!result.changes) throw new PortalError(409, 'Somente uma venda aprovada pode ser cancelada. Atualize a lista para conferir a situação.');
      const commissionCents = saleEarnings({ amountCents: Number(before.amountCents), feeCents: Number(before.feeCents), attendantFeeCents: before.attendantFeeCents == null ? null : Number(before.attendantFeeCents), commissionBps: Number(before.commissionBps), commissionMode: before.commissionMode as Sale['commissionMode'] });
      // Keep the sale, receipt and original fee snapshot. The audit record identifies
      // cancellation separately from an initial rejection without rewriting the sales schema.
      await store.audit(actor, 'sale.cancelled', id, String(before.name), { status: String(before.status), note: String(before.review_note), reviewedAt: before.reviewed_at == null ? null : String(before.reviewed_at), amountCents: Number(before.amountCents), commissionCents }, { status: 'rejected', note, cancelledAt, amountCents: Number(before.amountCents), commissionCents: 0 });
      return { saved: true };
    });
  }
  async adminCreateAttendant(input: unknown, actor = systemActor): Promise<Invitation> {
    const data: Record<string, unknown> = { commission: String(DEFAULT_COMMISSION_BPS / 100), ...this.adminFields(input) };
    const accountKind = data.accountKind === undefined ? 'attendant' : data.accountKind;
    if (accountKind !== 'attendant' && accountKind !== 'partner') return invalid('Tipo de conta inválido.');
    if (typeof data.name !== 'string') invalid('Informe o nome da conta.');
    let commission = 10000;
    if (accountKind === 'attendant') {
      if (typeof data.commission !== 'string') invalid('Informe nome e comissão.');
      try { commission = percentageToBps(data.commission as string); }
      catch (error) { return invalid((error as Error).message); }
    }
    const name = (data.name as string).trim();
    if (data.token !== undefined && typeof data.token !== 'string') invalid('Informe um token válido.');
    const chosenToken = typeof data.token === 'string' ? data.token.trim() : '';
    if (chosenToken && !/^[A-Za-z0-9_-]{32,160}$/.test(chosenToken)) invalid('O token deve ter de 32 a 160 letras, números, hífen ou sublinhado.');
    const { id, token } = (await this.createAttendant(name, commission, chosenToken || undefined, actor, accountKind));
    return { attendantId: id, name, token, accountKind };
  }
  private adminFields(input: unknown): Record<string, unknown> {
    if (!input || typeof input !== 'object' || Array.isArray(input)) return invalid('Dados inválidos.');
    return input as Record<string, unknown>;
  }
  async rotateToken(id: string, actor = systemActor): Promise<Invitation> {
    return this.withTransaction(async store => {
    const row = (await store.sql.prepare('SELECT name, active, account_kind FROM attendants WHERE id = ?').get(id));
    if (!row) throw new PortalError(404, 'Atendente não encontrado.');
    if (row.active !== 1) invalid('Reative o atendente antes de gerar um novo token.');
    const accountKind: AccountKind = row.account_kind === 'partner' ? 'partner' : 'attendant';
    const token = `${accountKind === 'partner' ? 'par' : 'atd'}_${randomBytes(32).toString('base64url')}`;
    (await store.sql.prepare('UPDATE attendants SET token_hash = ? WHERE id = ?').run(tokenHash(token), id));
    (await store.sql.prepare('DELETE FROM push_subscriptions WHERE attendant_id = ?').run(id));
    await store.audit(actor, 'attendant.token_rotated', id, String(row.name), null, { renewed: true });
    return { attendantId: id, name: String(row.name), token, accountKind };
    });
  }
  async setAttendantActive(id: string, input: unknown, actor = systemActor) {
    const data = this.adminFields(input);
    if (typeof data.active !== 'boolean') invalid('Informe se o acesso deve ficar ativo ou revogado.');
    return this.withTransaction(async store => {
    const before = await store.sql.prepare('SELECT name, active FROM attendants WHERE id = ?').get(id);
    const result = (await store.sql.prepare('UPDATE attendants SET active = ? WHERE id = ?').run(data.active ? 1 : 0, id));
    if (!result.changes) throw new PortalError(404, 'Atendente não encontrado.');
    if (!data.active) (await store.sql.prepare('DELETE FROM push_subscriptions WHERE attendant_id = ?').run(id));
    await store.audit(actor, 'attendant.access_changed', id, String(before!.name), { active: before!.active === 1 }, { active: data.active as boolean });
    });
  }
  async deleteRevokedAccount(id: string, actor = systemActor) {
    return this.withTransaction(async store => {
      const before = await store.sql.prepare(`SELECT name, active, account_kind, (${accountHistorySql}) AS hasHistory FROM attendants a WHERE id = ?`).get(id);
      if (!before) throw new PortalError(404, 'Cadastro não encontrado.');
      if (before.active !== 0) throw new PortalError(409, 'Revogue o acesso antes de excluir o cadastro.');
      if (before.hasHistory) throw new PortalError(409, 'Este cadastro possui vendas, custos, repasses ou comprovantes. A exclusão não é permitida para preservar o histórico.');
      await store.sql.prepare('DELETE FROM push_subscriptions WHERE attendant_id = ?').run(id);
      await store.sql.prepare('DELETE FROM attendants WHERE id = ? AND active = 0').run(id);
      await store.sql.prepare('DELETE FROM checkouts WHERE id = ? AND NOT EXISTS (SELECT 1 FROM sales WHERE checkout_id = checkouts.id)').run(exclusiveCheckoutId(id));
      await store.audit(actor, 'attendant.deleted', id, String(before.name), { exists: true, active: false, accountKind: String(before.account_kind) }, { exists: false });
      return { deleted: true };
    });
  }
  async adminSetCosts(id: string, input: unknown, actor = systemActor) {
    const data = this.adminFields(input);
    if (!(await this.sql.prepare('SELECT id FROM attendants WHERE id = ?').get(id))) throw new PortalError(404, 'Atendente não encontrado.');
    if (typeof data.date !== 'string' || typeof data.ads !== 'string' || typeof data.withdrawalFee !== 'string') invalid('Informe data, custo ADS e taxa de saque.');
    const amount = (value: string) => /^0+(?:[.,]0{1,2})?$/.test(value.trim()) ? 0 : amountToCents(value);
    try { (await this.setCosts(id, data.date as string, amount(data.ads as string), amount(data.withdrawalFee as string), actor)); }
    catch (error) { if (error instanceof PortalError) throw error; invalid((error as Error).message); }
  }
  async adminCosts(id: string, date: string): Promise<DailyCost> {
    if (!validDate(date)) invalid('Informe uma data válida.');
    if (!(await this.sql.prepare('SELECT id FROM attendants WHERE id = ?').get(id))) throw new PortalError(404, 'Atendente não encontrado.');
    return (await this.costs({ id })).find(cost => cost.date === date) ?? { date, adsCents: 0, withdrawalFeeCents: 0 };
  }
  async adminSetCheckout(id: string, input: unknown, actor = systemActor) {
    const data = this.adminFields(input);
    return this.withTransaction(async store => {
    const current = (await store.checkouts()).find(checkout => checkout.id === id);
    if (!current) throw new PortalError(404, 'Checkout não encontrado.');
    if (id === PARTNER_CHECKOUT.id || isExclusiveCheckout(id)) invalid('A taxa dos parceiros é padrão de 12% + R$ 2,00 por venda. Não é necessário escolher checkout.');
    if (typeof data.name !== 'string' || !data.name.trim() || data.name.length > 100 || typeof data.fee !== 'string') invalid('Informe nome e percentual de taxa.');
    if (data.fixedFee !== undefined && typeof data.fixedFee !== 'string' || data.minimum !== undefined && typeof data.minimum !== 'string') invalid('Informe valores válidos para a taxa fixa e o mínimo por venda.');
    let fee: number, fixedFee: number, minimum: number, higherTier = current.higherTier;
    try {
      fee = percentageToBps(data.fee as string);
      fixedFee = data.fixedFee === undefined ? current.fixedFeeCents : /^0+(?:[.,]0{1,2})?$/.test((data.fixedFee as string).trim()) ? 0 : amountToCents(data.fixedFee as string);
      minimum = data.minimum === undefined ? current.minAmountCents : amountToCents(data.minimum as string);
      if (data.higherTier !== undefined) {
        if (data.higherTier === null) higherTier = null;
        else {
          const tier = this.adminFields(data.higherTier);
          if (typeof tier.aboveAmount !== 'string' || typeof tier.fee !== 'string' || typeof tier.fixedFee !== 'string') throw new Error('Preencha o limite, o percentual e a taxa fixa da faixa superior.');
          higherTier = { aboveAmountCents: amountToCents(tier.aboveAmount as string), feeBps: percentageToBps(tier.fee as string), fixedFeeCents: /^0+(?:[.,]0{1,2})?$/.test((tier.fixedFee as string).trim()) ? 0 : amountToCents(tier.fixedFee as string) };
        }
      }
      if (higherTier && higherTier.aboveAmountCents < minimum) throw new Error('O limite da faixa inicial deve ser maior ou igual ao mínimo por venda.');
      if (current.maxAmountCents !== null && minimum > current.maxAmountCents) throw new Error('O mínimo não pode ultrapassar o limite de recebimento do checkout.');
      if (higherTier && current.maxAmountCents !== null && higherTier.aboveAmountCents >= current.maxAmountCents) throw new Error('A faixa superior deve começar abaixo do limite de recebimento do checkout.');
    } catch (error) { return invalid((error as Error).message); }
    (await store.sql.prepare('UPDATE checkouts SET name = ?, fee_bps = ?, fixed_fee_cents = ?, min_amount_cents = ?, tier_above_cents = ?, tier_fee_bps = ?, tier_fixed_fee_cents = ? WHERE id = ?').run((data.name as string).trim(), fee, fixedFee, minimum, higherTier?.aboveAmountCents ?? null, higherTier?.feeBps ?? null, higherTier?.fixedFeeCents ?? null, id));
    const values = (checkout: Checkout): AuditValues => ({ name: checkout.name, feeBps: checkout.feeBps, fixedFeeCents: checkout.fixedFeeCents, minAmountCents: checkout.minAmountCents, aboveAmountCents: checkout.higherTier?.aboveAmountCents ?? null, aboveFeeBps: checkout.higherTier?.feeBps ?? null, aboveFixedFeeCents: checkout.higherTier?.fixedFeeCents ?? null });
    await store.audit(actor, 'checkout.updated', id, current.name, values(current), values({ ...current, name: (data.name as string).trim(), feeBps: fee, fixedFeeCents: fixedFee, minAmountCents: minimum, higherTier }));
    });
  }
  async createAttendant(name: string, commissionBps: number, providedToken?: string, actor = systemActor, accountKind: AccountKind = 'attendant') {
    if (accountKind !== 'attendant' && accountKind !== 'partner') invalid('Tipo de conta inválido.');
    if (accountKind === 'partner') commissionBps = 10000;
    if (!name.trim() || name.length > 120 || !Number.isInteger(commissionBps) || commissionBps < 0 || commissionBps > 10000) invalid('Nome e comissão são obrigatórios e devem ser válidos.');
    const token = providedToken ?? `${accountKind === 'partner' ? 'par' : 'atd'}_${randomBytes(32).toString('base64url')}`;
    if (!/^[A-Za-z0-9_-]{12,160}$/.test(token)) invalid('Token inválido.');
    return this.withTransaction(async store => {
    if ((await store.sql.prepare('SELECT id FROM attendants WHERE token_hash = ?').get(tokenHash(token)))) throw new PortalError(409, 'Esse token já está em uso. Defina outro token para este atendente.');
    const id = randomUUID();
    // Legacy goal columns stay in SQLite to preserve existing databases; they are no longer read or applied.
    (await store.sql.prepare('INSERT INTO attendants (id, token_hash, name, commission_bps, daily_goal_cents, created_at, account_kind) VALUES (?, ?, ?, ?, 1, ?, ?)').run(id, tokenHash(token), name.trim(), commissionBps, new Date().toISOString(), accountKind));
    await store.audit(actor, 'attendant.created', id, name.trim(), null, { name: name.trim(), accountKind, commissionBps, active: true });
    return { id, token };
    });
  }
  async createPartner(name: string, providedToken?: string, actor = systemActor) {
    return this.createAttendant(name, 10000, providedToken, actor, 'partner');
  }
  async authenticate(token: string): Promise<Authenticated> {
    if (!/^[A-Za-z0-9_-]{12,160}$/.test(token)) throw new PortalError(401, 'Atendente não encontrado pelo token informado.');
    const row = (await this.sql.prepare('SELECT id FROM attendants WHERE token_hash = ? AND active = 1').get(tokenHash(token)));
    if (!row) throw new PortalError(401, 'Atendente não encontrado pelo token informado.');
    return { id: String(row.id) };
  }
  async profile(auth: Authenticated): Promise<Profile> {
    const row = (await this.sql.prepare('SELECT id, name, account_kind, email, phone, pix_type, pix_key, pix_owner, commission_bps, photo_url, sale_alert_template FROM attendants WHERE id = ?').get(auth.id)) as unknown as AttendantRow;
    if (!row) throw new PortalError(401, 'Atendente não encontrado pelo token informado.');
    return { id: row.id, name: row.name, accountKind: row.account_kind, email: row.email, phone: row.phone, pixType: row.pix_type, pixKey: row.pix_key, pixOwner: row.pix_owner, commissionBps: row.commission_bps, photoUrl: row.photo_url, saleAlertTemplate: row.sale_alert_template || DEFAULT_SALE_ALERT };
  }
  async checkouts(): Promise<Checkout[]> {
    return (await this.sql.prepare('SELECT * FROM checkouts ORDER BY rowid').all()).map(row => ({ id: String(row.id), name: String(row.name), feeBps: Number(row.fee_bps), fixedFeeCents: Number(row.fixed_fee_cents), minAmountCents: Number(row.min_amount_cents), maxAmountCents: row.max_amount_cents == null ? null : Number(row.max_amount_cents), higherTier: row.tier_above_cents == null ? null : { aboveAmountCents: Number(row.tier_above_cents), feeBps: Number(row.tier_fee_bps), fixedFeeCents: Number(row.tier_fixed_fee_cents) } }));
  }
  async checkoutsFor(auth: Authenticated): Promise<Checkout[]> {
    const checkouts = await this.checkouts(), exclusive = checkouts.find(checkout => checkout.id === exclusiveCheckoutId(auth.id));
    return exclusive ? [exclusive] : checkouts.filter(checkout => !isExclusiveCheckout(checkout.id) && checkout.id !== PARTNER_CHECKOUT.id);
  }
  async sales(auth: Authenticated): Promise<Sale[]> { return (await this.sql.prepare(`SELECT id, date, time, checkout_id AS checkoutId, checkout_name AS checkoutName, amount_cents AS amountCents, fee_cents AS feeCents, attendant_fee_cents AS attendantFeeCents, commission_bps AS commissionBps, commission_mode AS commissionMode, note, receipt_id AS receiptId, created_at AS createdAt, status, review_note AS reviewNote, reviewed_at AS reviewedAt, (SELECT e.created_at FROM audit_events e WHERE e.target_id = s.id AND e.action = 'sale.cancelled' LIMIT 1) AS cancelledAt FROM sales s WHERE attendant_id = ? ORDER BY date DESC, time DESC, created_at DESC`).all(auth.id)) as unknown as Sale[]; }
  async costs(auth: Authenticated): Promise<DailyCost[]> { return (await this.sql.prepare('SELECT date, ads_cents AS adsCents, withdrawal_fee_cents AS withdrawalFeeCents FROM costs WHERE attendant_id = ?').all(auth.id)) as unknown as DailyCost[]; }
  async payouts(auth: Authenticated): Promise<Payout[]> { return (await this.sql.prepare('SELECT id, amount_cents AS amountCents, withdrawal_fee_cents AS withdrawalFeeCents, gateway_fee_cents AS gatewayFeeCents, status, requested_at AS requestedAt, paid_at AS paidAt, note FROM payouts WHERE attendant_id = ? ORDER BY requested_at DESC').all(auth.id)) as unknown as Payout[]; }
  async portal(auth: Authenticated, period: Period = 'today'): Promise<Portal> {
    const profile = (await this.profile(auth)), sales = (await this.sales(auth)), costs = (await this.costs(auth)), payouts = (await this.payouts(auth)), today = businessToday();
    const checkouts = accountCheckouts(await this.checkoutsFor(auth), profile.accountKind), finance = calculateFinance(sales, costs, payouts, period, today, profile.accountKind);
    const partner = profile.accountKind === 'partner' || checkouts.some(checkout => checkout.id === exclusiveCheckoutId(auth.id));
    const ownAds = partner ? (await this.sql.prepare('SELECT date, partner_ads_cents AS adsCents FROM costs WHERE attendant_id = ? AND partner_ads_cents > 0').all(auth.id)).map(row => ({ date: String(row.date), adsCents: Number(row.adsCents) })) : [];
    return { profile, checkouts, sales: sales.filter(sale => inPeriod(sale.date, period, today)).slice(0, 100), payouts, finance, ...(partner ? { marketing: calculateMarketing(finance, ownAds, period, today) } : {}), today };
  }
  private async requirePartner(auth: Authenticated): Promise<Profile> {
    const profile = await this.profile(auth);
    if (profile.accountKind !== 'partner' && !await this.sql.prepare('SELECT id FROM checkouts WHERE id = ?').get(exclusiveCheckoutId(auth.id))) throw new PortalError(403, 'O lançamento de ADS próprio está disponível apenas no portal do parceiro.');
    return profile;
  }
  async partnerAds(auth: Authenticated, date: string): Promise<PartnerAdsCost> {
    await this.requirePartner(auth);
    if (!validDate(date) || date > businessToday()) invalid('Informe uma data válida, até hoje.');
    const row = await this.sql.prepare('SELECT date, partner_ads_cents AS adsCents FROM costs WHERE attendant_id = ? AND date = ?').get(auth.id, date);
    return { date, adsCents: row ? Number(row.adsCents) : 0 };
  }
  async savePartnerAds(auth: Authenticated, input: unknown): Promise<PartnerAdsCost> {
    const data = this.adminFields(input);
    await this.requirePartner(auth);
    if (Object.keys(data).some(key => key !== 'date' && key !== 'ads') || typeof data.date !== 'string' || !validDate(data.date) || data.date > businessToday() || typeof data.ads !== 'string') invalid('Informe somente a data e o total de ADS pago por você.');
    let adsCents: number;
    try { adsCents = /^0+(?:[.,]0{1,2})?$/.test((data.ads as string).trim()) ? 0 : amountToCents(data.ads as string); }
    catch (error) { return invalid((error as Error).message); }
    if (adsCents > 100000000) invalid('O custo de ADS deve ser de até R$ 1.000.000,00 por dia.');
    const date = data.date as string;
    return this.withTransaction(async store => {
      const profile = await store.requirePartner(auth), before = await store.partnerAds(auth, date);
      await store.sql.prepare('INSERT INTO costs (attendant_id, date, ads_cents, withdrawal_fee_cents, partner_ads_cents) VALUES (?, ?, 0, 0, ?) ON CONFLICT(attendant_id,date) DO UPDATE SET partner_ads_cents = excluded.partner_ads_cents').run(auth.id, date, adsCents);
      await store.audit({ id: auth.id, name: profile.name }, 'partner.ads_updated', auth.id, profile.name, { date, partnerAdsCents: before.adsCents }, { date, partnerAdsCents: adsCents });
      return { date, adsCents };
    });
  }
  async saveProfile(auth: Authenticated, input: unknown): Promise<Profile> {
    let fields: ReturnType<typeof validateProfile>;
    try { fields = validateProfile(input); } catch (error) { return invalid((error as Error).message); }
    const current = (await this.profile(auth));
    (await this.sql.prepare('UPDATE attendants SET name = ?, email = ?, phone = ?, pix_type = ?, pix_key = ?, pix_owner = ?, photo_url = ?, sale_alert_template = ? WHERE id = ?').run(fields.name, fields.email, fields.phone, fields.pixType, fields.pixKey, fields.pixOwner, fields.photoUrl ?? current.photoUrl, fields.saleAlertTemplate ?? current.saleAlertTemplate, auth.id));
    return (await this.profile(auth));
  }
  receiptInput(value: unknown): { name: string; mime: string; bytes: Buffer } {
    if (!value || typeof value !== 'object') return invalid('Anexe uma imagem ou PDF como comprovante de cada venda.');
    const receipt = value as ReceiptInput;
    if (typeof receipt.name !== 'string' || !receipt.name || receipt.name.length > 180 || typeof receipt.base64 !== 'string' || receipt.base64.length > Math.ceil(MAX_RECEIPT_BYTES / 3) * 4 + 4 || !/^[A-Za-z0-9+/]+={0,2}$/.test(receipt.base64)) return invalid('O comprovante deve ser uma imagem ou PDF válido de até 2 MB.');
    const bytes = Buffer.from(receipt.base64, 'base64');
    const png = bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
    const jpeg = bytes.length > 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
    const webp = bytes.length > 12 && bytes.subarray(0, 4).toString() === 'RIFF' && bytes.subarray(8, 12).toString() === 'WEBP';
    if (!bytes.length || bytes.length > MAX_RECEIPT_BYTES || !(receipt.mime === 'image/png' && png || receipt.mime === 'image/jpeg' && jpeg || receipt.mime === 'image/webp' && webp || receipt.mime === 'application/pdf' && isPdfReceipt(bytes))) return invalid('Use um print PNG, JPG ou WEBP, ou um PDF válido, de até 2 MB.');
    return { name: receipt.name, mime: receipt.mime, bytes };
  }
  async recordSales(auth: Authenticated, input: unknown, requestKey: string): Promise<{ duplicate: boolean; count: number }> {
    if (!/^[A-Za-z0-9_-]{12,100}$/.test(requestKey)) invalid('Identificador de envio inválido. Atualize a página.');
    if (!input || typeof input !== 'object') invalid('Lançamento inválido.');
    const payloadHash = createHash('sha256').update(JSON.stringify(input)).digest('hex');
    const received = await this.sql.prepare('SELECT b.payload_hash, (SELECT COUNT(*) FROM sales s WHERE s.batch_id = b.id) AS count FROM batches b WHERE b.attendant_id = ? AND b.request_key = ?').get(auth.id, requestKey);
    if (received) {
      if (received.payload_hash !== payloadHash) throw new PortalError(409, 'Este envio já foi registrado com outros dados. Confira o histórico e atualize a página antes de lançar novas vendas.');
      return { duplicate: true, count: Number(received.count) };
    }
    const batch = input as SaleBatch;
    if (typeof batch.date !== 'string' || !validDate(batch.date) || batch.date > businessToday()) invalid('Informe uma data válida, até hoje.');
    if (!Array.isArray(batch.sales) || !batch.sales.length || batch.sales.length > 10) invalid('Envie entre 1 e 10 vendas por vez.');
    const profile = (await this.profile(auth)), checkouts = accountCheckouts(await this.checkoutsFor(auth), profile.accountKind);
    const normalized = batch.sales.map(row => {
      if (!row || typeof row !== 'object' || typeof row.amount !== 'string' || typeof row.note !== 'string' || row.note.length > 500 || typeof row.time !== 'string' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(row.time)) return invalid('Confira o valor, o horário e a observação de cada venda.');
      const checkout = profile.accountKind === 'partner' ? checkouts[0] : checkouts.find(item => item.id === row.checkoutId);
      if (!checkout) return invalid('Selecione um checkout válido para cada venda.');
      let amountCents: number;
      try { amountCents = amountToCents(row.amount); } catch (error) { return invalid((error as Error).message); }
      let feeCents: number;
      try { feeCents = checkoutFee(amountCents, checkout); } catch (error) { return invalid((error as Error).message); }
      return { amountCents, feeCents, checkout, time: row.time, note: row.note.trim(), receipt: this.receiptInput(row.receipt) };
    });
    return this.withTransaction(async store => {
    const existing = (await store.sql.prepare('SELECT id, payload_hash FROM batches WHERE attendant_id = ? AND request_key = ?').get(auth.id, requestKey));
    if (existing) {
      if (existing.payload_hash !== payloadHash) throw new PortalError(409, 'Este envio já foi registrado com outros dados. Confira o histórico e atualize a página antes de lançar novas vendas.');
      return { duplicate: true, count: normalized.length };
    }
      const batchId = randomUUID(), createdAt = new Date().toISOString();
      (await store.sql.prepare('INSERT INTO batches VALUES (?, ?, ?, ?)').run(batchId, auth.id, requestKey, payloadHash));
      for (const row of normalized) {
        const receiptId = randomUUID();
        (await store.sql.prepare('INSERT INTO receipts VALUES (?, ?, ?, ?, ?)').run(receiptId, auth.id, row.receipt.name, row.receipt.mime, row.receipt.bytes));
        (await store.sql.prepare("INSERT INTO sales (id, attendant_id, batch_id, date, time, checkout_id, checkout_name, amount_cents, fee_cents, commission_bps, goal_cents, note, receipt_id, created_at, status, commission_mode, attendant_fee_cents, gateway_cost_cents) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'gross-share-less-fees', ?, ?)").run(randomUUID(), auth.id, batchId, batch.date, row.time, row.checkout.id, row.checkout.name, row.amountCents, row.feeCents, profile.commissionBps, 0, row.note, receiptId, createdAt, allocatedSaleFee(row.feeCents, profile.accountKind), profile.accountKind === 'partner' ? partnerGatewayCost(row.amountCents) : null));
      }
    await store.audit({ id: auth.id, name: profile.name }, 'sales.submitted', batchId, profile.name, null, { count: normalized.length, amountCents: normalized.reduce((sum, row) => sum + row.amountCents, 0), date: batch.date });
    return { duplicate: false, count: normalized.length };
    });
  }
  async receipt(auth: Authenticated, id: string) {
    const row = (await this.sql.prepare('SELECT mime, bytes FROM receipts WHERE id = ? AND attendant_id = ?').get(id, auth.id));
    if (!row) throw new PortalError(404, 'Comprovante não encontrado.');
    return { mime: String(row.mime), bytes: row.bytes as Uint8Array };
  }
  async ranking(auth: Authenticated, period: RankingPeriod = 'last30', start = '', end = ''): Promise<RankingEntry[]> {
    let range: ReturnType<typeof rankingRange>;
    try { range = rankingRange(period, businessToday(), start, end); } catch (error) { return invalid((error as Error).message); }
    await this.profile(auth);
    const attendants = (await this.sql.prepare('SELECT id, name, photo_url FROM attendants WHERE active = 1').all());
    return (await Promise.all(attendants.map(async attendant => {
      const sales = (await this.sales({ id: String(attendant.id) })).filter(sale => sale.status === 'approved' && inRankingRange(sale.date, range));
      return { id: String(attendant.id), name: String(attendant.name), photoUrl: String(attendant.photo_url), grossCents: sales.reduce((sum, sale) => sum + sale.amountCents, 0), count: sales.length, mine: attendant.id === auth.id };
    }))).filter(item => item.count > 0).sort((a, b) => b.grossCents - a.grossCents || b.count - a.count || a.name.localeCompare(b.name, 'pt-BR') || a.id.localeCompare(b.id));
  }
  /** Historical ledger support; attendants cannot create requests through the API. */
  async requestPayout(auth: Authenticated, input: unknown): Promise<Payout> {
    if (!input || typeof input !== 'object' || typeof (input as { amount?: unknown }).amount !== 'string') invalid('Informe o valor do repasse.');
    let amountCents: number;
    try { amountCents = amountToCents((input as { amount: string }).amount); } catch (error) { return invalid((error as Error).message); }
    return this.withTransaction(async store => {
      const profile = (await store.profile(auth)), portal = (await store.portal(auth, 'all'));
      if (!profile.pixKey || !profile.pixOwner) invalid('Cadastre sua chave PIX e o titular antes de solicitar um repasse.');
      try { validatePayoutAmount(amountCents, portal.finance.availableCents, profile.accountKind); } catch (error) { return invalid((error as Error).message); }
      const id = randomUUID(), requestedAt = new Date().toISOString();
      (await store.sql.prepare('INSERT INTO payouts (id, attendant_id, amount_cents, status, requested_at, paid_at, note, pix_type, pix_key, pix_owner, withdrawal_fee_cents, gateway_fee_cents) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(id, auth.id, amountCents, 'pending', requestedAt, null, '', profile.pixType, profile.pixKey, profile.pixOwner, 0, 0));
      return { id, amountCents, withdrawalFeeCents: 0, gatewayFeeCents: 0, status: 'pending', requestedAt, paidAt: null, note: '' };
    });
  }
  async setCosts(attendantId: string, date: string, adsCents: number, withdrawalFeeCents: number, actor = systemActor) {
    if (!validDate(date) || ![adsCents, withdrawalFeeCents].every(value => Number.isSafeInteger(value) && value >= 0 && value <= 100000000)) invalid('Custos ou data inválidos.');
    return this.withTransaction(async store => {
    const attendant = await store.sql.prepare('SELECT name FROM attendants WHERE id = ?').get(attendantId);
    if (!attendant) throw new PortalError(404, 'Atendente não encontrado.');
    const before = await store.adminCosts(attendantId, date);
    (await store.sql.prepare('INSERT INTO costs (attendant_id, date, ads_cents, withdrawal_fee_cents) VALUES (?, ?, ?, ?) ON CONFLICT(attendant_id,date) DO UPDATE SET ads_cents=excluded.ads_cents, withdrawal_fee_cents=excluded.withdrawal_fee_cents').run(attendantId, date, adsCents, withdrawalFeeCents));
    await store.audit(actor, 'costs.updated', attendantId, String(attendant.name), { date, adsCents: before.adsCents, withdrawalFeeCents: before.withdrawalFeeCents }, { date, adsCents, withdrawalFeeCents });
    });
  }
  async markPayout(id: string, status: 'paid' | 'cancelled', note: string, actor = systemActor) {
    if (!['paid', 'cancelled'].includes(status) || note.length > 500) invalid('Status ou observação inválidos.');
    return this.withTransaction(async store => {
    const before = await store.sql.prepare('SELECT p.status, p.amount_cents, p.withdrawal_fee_cents, p.gateway_fee_cents, p.note, a.name, a.account_kind FROM payouts p JOIN attendants a ON a.id = p.attendant_id WHERE p.id = ?').get(id);
    const fees = withdrawalFees(before?.account_kind as AccountKind);
    if (status === 'paid') {
      const pending = (await store.sql.prepare("SELECT amount_cents, attendant_id FROM payouts WHERE id = ? AND status = 'pending'").get(id));
      if (pending && Number(pending.amount_cents) <= fees.withdrawalFeeCents) invalid(`O repasse precisa ser maior que a sua parte da taxa de ${ATTENDANT_WITHDRAWAL_FEE_CENTS / 100} reais. Cancele o pedido e solicite um valor maior.`);
      if (pending && (await store.portal({ id: String(pending.attendant_id) }, 'all')).finance.availableCents < 0) invalid('Saldo insuficiente após alterações nas vendas ou nos custos. Confira o saldo e cancele os pedidos de repasse sem cobertura antes de confirmar pagamentos.');
    }
    const result = (await store.sql.prepare("UPDATE payouts SET status = ?, paid_at = ?, note = ?, withdrawal_fee_cents = ?, gateway_fee_cents = ? WHERE id = ? AND status = 'pending'").run(status, status === 'paid' ? new Date().toISOString() : null, note, status === 'paid' ? fees.withdrawalFeeCents : 0, status === 'paid' ? fees.gatewayFeeCents : 0, id));
    if (!result.changes) invalid('Repasse pendente não encontrado.');
    await store.audit(actor, status === 'paid' ? 'payout.paid' : 'payout.cancelled', id, String(before!.name), { status: String(before!.status), amountCents: Number(before!.amount_cents), withdrawalFeeCents: Number(before!.withdrawal_fee_cents), gatewayFeeCents: Number(before!.gateway_fee_cents), note: String(before!.note) }, { status, amountCents: Number(before!.amount_cents), withdrawalFeeCents: status === 'paid' ? fees.withdrawalFeeCents : 0, gatewayFeeCents: status === 'paid' ? fees.gatewayFeeCents : 0, note });
    });
  }
  async recordManualPayout(input: unknown, requestKey: string, actor = systemActor) {
    const data = this.adminFields(input);
    if (typeof data.attendantId !== 'string' || !/^[A-Za-z0-9_-]{1,100}$/.test(data.attendantId) || typeof data.amount !== 'string' || typeof data.note !== 'string' || !data.note.trim() || data.note.length > 500) invalid('Informe atendente, valor e observação do pagamento.');
    if (!/^[A-Za-z0-9_-]{12,160}$/.test(requestKey)) invalid('Identificador do pagamento inválido. Atualize a página e tente novamente.');
    let amountCents: number;
    try { amountCents = amountToCents(data.amount as string); } catch (error) { return invalid((error as Error).message); }
    const attendantId = data.attendantId as string, note = (data.note as string).trim();
    // A deterministic private-operation ID makes retries atomic without adding
    // columns to the ledger or breaking recovery of existing backup archives.
    const id = 'manual_' + createHash('sha256').update('bravus-manual-payout-v1\0' + requestKey).digest('hex');
    return this.withTransaction(async store => {
      const existing = await store.sql.prepare('SELECT attendant_id, amount_cents, note, status FROM payouts WHERE id = ?').get(id);
      if (existing) {
        if (existing.attendant_id !== attendantId || Number(existing.amount_cents) !== amountCents || existing.note !== note || existing.status !== 'paid') throw new PortalError(409, 'Este pagamento já foi registrado com outros dados. Confira o histórico antes de registrar outro.');
        return { id, duplicate: true };
      }
      if (!await store.sql.prepare('SELECT id FROM attendants WHERE id = ?').get(attendantId)) throw new PortalError(404, 'Atendente não encontrado.');
      const portal = await store.portal({ id: attendantId }, 'all'), profile = portal.profile;
      if (!profile.pixKey || !profile.pixOwner) invalid('O atendente precisa cadastrar sua chave PIX e o titular antes de registrar o pagamento.');
      try { validatePayoutAmount(amountCents, portal.finance.availableCents, profile.accountKind); } catch (error) { return invalid((error as Error).message); }
      const paidAt = new Date().toISOString(), fees = withdrawalFees(profile.accountKind);
      await store.sql.prepare("INSERT INTO payouts (id, attendant_id, amount_cents, status, requested_at, paid_at, note, pix_type, pix_key, pix_owner, withdrawal_fee_cents, gateway_fee_cents) VALUES (?, ?, ?, 'paid', ?, ?, ?, ?, ?, ?, ?, ?)").run(id, attendantId, amountCents, paidAt, paidAt, note, profile.pixType, profile.pixKey, profile.pixOwner, fees.withdrawalFeeCents, fees.gatewayFeeCents);
      await store.audit(actor, 'payout.paid', id, profile.name, null, { status: 'paid', amountCents, pixNetCents: amountCents - fees.withdrawalFeeCents, withdrawalFeeCents: fees.withdrawalFeeCents, gatewayFeeCents: fees.gatewayFeeCents, note });
      return { id, duplicate: false };
    });
  }
}
