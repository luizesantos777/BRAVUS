import Ranking from './Ranking.tsx';
import { useEffect, useRef, useState } from 'react';
import type { ClipboardEvent, FormEvent, ReactNode } from 'react';
import { AlertCircle, ArrowRight, CalendarDays, Camera, Check, CheckCircle2, ChevronDown, ClipboardPaste, Copy, DollarSign, ExternalLink, FileImage, FileText, History, Info, KeyRound, LoaderCircle, Megaphone, Plus, RefreshCw, Save, ShieldCheck, ShoppingCart, Trash2, Trophy, UserRound, Wallet, X } from 'lucide-react';
import { amountToCents, businessToday, checkoutFee, dateLabel, demoInitial, demoPortal, DEFAULT_SALE_ALERT, money, payoutNet, saleEarnings, allocatedSaleFee, accountCheckouts, renderSaleAlert, periodLabels, pixLabels, saleStatusLabel } from './domain.ts';
import type { AccountKind, Checkout, Period, Portal } from './domain.ts';
import { ApiError, currentToken, PortalClient, readReceipt } from './client.ts';
import { Brand, BrandIntro } from './Brand.tsx';
import ProfileForm, { ProfileAvatar } from './Profile.tsx';
import { notifyDemoSale } from './notifications.ts';
import { blankDraftRow as blankRow } from './sales-drafts.ts';
import type { DraftRow as SaleRow } from './sales-drafts.ts';
import { useSalesDraft } from './useSalesDraft.ts';
import PartnerAds from './PartnerAds.tsx';
import PartnerFinancialSummary from './PartnerFinancialSummary.tsx';
import { applyPageMetadata } from './page-metadata.ts';
import { publicAssetUrl } from './pwa.ts';
import { clipboardFiles, readClipboardImage } from './clipboard-receipts.ts';
import ReceiptPreview from './ReceiptPreview.tsx';
import { receiptViewFromInput } from './receipts.ts';
import type { ReceiptView } from './receipts.ts';

type Tab = 'sales' | 'marketing' | 'ranking' | 'payouts' | 'profile';
type Notice = { text: string; error?: boolean };
const tabs = [{ id: 'sales', label: 'Lançar Vendas', icon: Plus }, { id: 'marketing', label: 'ADS e ROI', icon: Megaphone }, { id: 'ranking', label: 'Ranking', icon: Trophy }, { id: 'payouts', label: 'Repasses', icon: History }, { id: 'profile', label: 'Meus Dados e PIX', icon: UserRound }] as const;
const MANUAL_PIX_KEY = 'd026e4d9-0a17-4ecf-b2fe-61e0ff386e6f';
const CHECKOUT_URL = 'https://pagamento.bravuspix.shop/checkout';
function initialTab(): Tab {
  const value = new URLSearchParams(window.location.search).get('aba');
  return value === 'perfil' ? 'profile' : value === 'ranking' ? 'ranking' : 'sales';
}

function Dialog({ title, close, children }: { title: string; close: () => void; children: ReactNode }) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => { const dialog = ref.current!; dialog.showModal(); return () => dialog.close(); }, []);
  return <dialog ref={ref} className="dialog" aria-labelledby="dialog-title" onCancel={event => { event.preventDefault(); close(); }} onClick={event => { if (event.target === event.currentTarget) close(); }}><header><h2 id="dialog-title">{title}</h2><button className="icon-button" aria-label="Fechar janela" onClick={close}><X size={19} /></button></header>{children}</dialog>;
}
function Empty({ icon, title, children }: { icon: ReactNode; title: string; children: ReactNode }) { return <div className="empty"><span>{icon}</span><h3>{title}</h3><p>{children}</p></div>; }
function CheckoutCard({ notify, checkout }: { notify: (notice: Notice) => void; checkout?: Checkout }) {
  const input = useRef<HTMLInputElement>(null);
  async function copy() {
    try { await navigator.clipboard.writeText(CHECKOUT_URL); notify({ text: 'Link do checkout copiado!' }); }
    catch { input.current?.focus(); input.current?.select(); notify({ text: 'O link foi selecionado. Use a opção Copiar do seu aparelho.' }); }
  }
  return <section className="checkout-card" aria-labelledby="checkout-title"><div className="checkout-heading"><ShoppingCart size={17} /><div><h3 id="checkout-title">Checkout BRAVUS</h3><p>Copie o link para enviar ao cliente ou abra o checkout.</p>{checkout?.maxAmountCents != null && <small className="checkout-limit">Até {money(checkout.maxAmountCents)} por venda</small>}</div></div><div className="checkout-controls"><label className="sr-only" htmlFor="checkout-link">Link do checkout BRAVUS</label><input ref={input} id="checkout-link" readOnly value={CHECKOUT_URL} spellCheck={false} onFocus={event => event.currentTarget.select()} /><a className="button primary" href={CHECKOUT_URL} target="_blank" rel="noopener noreferrer"><ExternalLink size={14} />Abrir checkout</a><button type="button" className="button secondary" onClick={() => void copy()}><Copy size={14} />Copiar link</button></div></section>;
}
function ManualPixCard({ notify, checkout }: { notify: (notice: Notice) => void; checkout?: Checkout }) {
  const input = useRef<HTMLInputElement>(null);
  async function copy() {
    try {
      await navigator.clipboard.writeText(MANUAL_PIX_KEY);
      notify({ text: 'Chave PIX manual copiada!' });
    } catch {
      input.current?.focus(); input.current?.select();
      notify({ text: 'A chave PIX foi selecionada. Use a opção Copiar do seu aparelho.' });
    }
  }
  return <section className="manual-pix-card" aria-labelledby="manual-pix-title"><div className="manual-pix-heading"><KeyRound size={17} /><div><h3 id="manual-pix-title">PIX manual · Recebimento de vendas</h3><p>Use esta chave nos pagamentos das vendas por PIX manual.</p>{checkout && <small className="manual-pix-limit">A partir de {money(checkout.minAmountCents)} por venda</small>}</div></div><div className="manual-pix-copy"><label className="sr-only" htmlFor="manual-pix-key">Chave PIX manual para receber vendas</label><input ref={input} id="manual-pix-key" type="text" value={MANUAL_PIX_KEY} readOnly spellCheck={false} onFocus={event => event.currentTarget.select()} /><button type="button" className="button primary" onClick={() => void copy()}><Copy size={14} />Copiar chave PIX</button></div></section>;
}
function SaleValuePreview({ row, checkout, index, commissionBps, accountKind }: { row: SaleRow; checkout?: Checkout; index: number; commissionBps: number; accountKind?: AccountKind }) {
  if (!checkout) return null;
  let net: number | null = null, error = '';
  if (row.amount.trim()) {
    try {
      const amountCents = amountToCents(row.amount), feeCents = checkoutFee(amountCents, checkout);
      net = saleEarnings({ amountCents, feeCents, attendantFeeCents: allocatedSaleFee(feeCents, accountKind), commissionBps: accountKind === 'partner' ? 10000 : commissionBps, commissionMode: 'gross-share-less-fees' });
    } catch (cause) { error = (cause as Error).message; }
  }
  return <div className="sale-fee-preview" aria-label={`Resumo da venda ${index + 1}`}><span>{checkout.name}</span>{net !== null && <span>Seu valor: <strong>{money(net)}</strong><i />Antes de ADS</span>}{error && <span className="fee-validation">{error}</span>}</div>;
}
function SalesForm({ client, portal, disabled, refresh, notify, preview }: { client: PortalClient; portal: Portal; disabled: boolean; refresh: () => Promise<void>; notify: (notice: Notice) => void; preview: (receipt: ReceiptView) => void }) {
  const draft = useSalesDraft(client, client.isDemo || portal.profile.id !== 'demo');
  const { rows, date, pending } = draft.draft;
  const { setRows, setDate } = draft;
  const partner = portal.profile.accountKind === 'partner';
  const onlyCheckout = portal.checkouts.length === 1 ? portal.checkouts[0] : undefined;
  useEffect(() => { if (onlyCheckout) draft.selectOnlyCheckout(onlyCheckout.id); }, [onlyCheckout?.id, draft.ready, pending, rows]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [preparing, setPreparing] = useState<Set<string>>(new Set());
  const [attachmentErrors, setAttachmentErrors] = useState<Record<string, string>>({});
  const salesSection = useRef<HTMLElement>(null), pasteFallback = useRef<(event: globalThis.ClipboardEvent) => void>(() => undefined);
  const attachments = useRef(new Map<string, symbol>());
  useEffect(() => () => { attachments.current.clear(); }, []);
  const submitting = useRef(false);
  const pasteLocked = busy || disabled || !draft.ready || draft.clearing || pending;
  const update = (id: string, patch: Partial<SaleRow>) => setRows(previous => previous.map(row => row.id === id ? { ...row, ...patch } : row));
  async function attach(id: string, source?: File | (() => Promise<File>)) {
    if (!source || pasteLocked || submitting.current) return;
    const operation = Symbol(); attachments.current.set(id, operation);
    setPreparing(previous => new Set(previous).add(id));
    update(id, { receipt: null }); setError('');
    setAttachmentErrors(previous => ({ ...previous, [id]: '' }));
    try {
      const file = typeof source === 'function' ? await source() : source;
      if (attachments.current.get(id) !== operation) return;
      const receipt = await readReceipt(file);
      if (attachments.current.get(id) === operation) update(id, { receipt });
    } catch (cause) {
      if (attachments.current.get(id) === operation) setAttachmentErrors(previous => ({ ...previous, [id]: (cause as Error).message }));
    } finally {
      if (attachments.current.get(id) === operation) {
        attachments.current.delete(id);
        setPreparing(previous => { const next = new Set(previous); next.delete(id); return next; });
      }
    }
  }
  function attachPastedFiles(id: string, files: File[]) {
    if (pasteLocked || submitting.current) return;
    if (files.length > 1) {
      // Cancel an older read and clear any previous receipt, matching invalid file uploads.
      attachments.current.delete(id);
      setPreparing(previous => { const next = new Set(previous); next.delete(id); return next; });
      update(id, { receipt: null });
      setAttachmentErrors(previous => ({ ...previous, [id]: 'Cole apenas uma imagem de comprovante por venda.' }));
      return;
    }
    void attach(id, files[0]);
  }
  function pasteReceipt(id: string, event: ClipboardEvent<HTMLDivElement>) {
    const files = clipboardFiles(event.clipboardData);
    if (!files.length) {
      // The paste-only editor must never insert HTML or fetch an image URL from copied markup.
      if (event.target instanceof Element && event.target.closest('[data-receipt-paste-zone]')) {
        event.preventDefault();
        void attach(id, async () => { throw new Error('Copie a imagem do comprovante, não apenas o link ou o texto. Ou escolha Anexar Print.'); });
      }
      return;
    }
    event.preventDefault();attachPastedFiles(id, files);
  }
  pasteFallback.current = event => {
    if (event.defaultPrevented) return;
    const files = clipboardFiles(event.clipboardData), section = salesSection.current;
    if (!files.length || !section) return;
    const target = event.target instanceof Element ? event.target : null, active = document.activeElement;
    const inside = !!target && section.contains(target) || !!active && section.contains(active);
    const neutral = (!target || target === document.body || target === document.documentElement) && (!active || active === document.body || active === document.documentElement);
    if (!inside && !neutral) return;
    event.preventDefault();
    if (pasteLocked || submitting.current) return;
    const row = (target && section.contains(target) ? target.closest<HTMLElement>('[data-receipt-row]') : null) ?? (active && section.contains(active) ? active.closest<HTMLElement>('[data-receipt-row]') : null);
    const id = row?.dataset.receiptRow ?? (rows.length === 1 ? rows[0].id : null);
    if (!id || !rows.some(row => row.id === id)) { setError('Há várias vendas. Clique na área de colagem da venda que deve receber o comprovante.'); return; }
    attachPastedFiles(id, files);
  };
  useEffect(() => {
    const paste = (event: globalThis.ClipboardEvent) => pasteFallback.current(event);
    document.addEventListener('paste', paste);
    return () => document.removeEventListener('paste', paste);
  }, []);
  function removeRow(id: string) {
    attachments.current.delete(id);
    setPreparing(previous => { const next = new Set(previous); next.delete(id); return next; });
    setAttachmentErrors(previous => { const next = { ...previous }; delete next[id]; return next; });
    setRows(previous => previous.filter(row => row.id !== id));
  }
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (submitting.current || busy || disabled || !draft.ready || attachments.current.size) return; setError('');
    try {
      for (const [index, row] of pending ? [] : rows.entries()) {
        amountToCents(row.amount);
        if (!row.receipt || (!partner && !row.checkoutId)) throw new Error(`Venda ${index + 1}: ${partner ? 'anexe o comprovante obrigatório (imagem ou PDF).' : 'selecione o checkout e anexe o comprovante obrigatório (imagem ou PDF).'}`);
        const checkout = partner ? onlyCheckout : portal.checkouts.find(item => item.id === row.checkoutId);
        if (!checkout) throw new Error('Selecione um checkout válido.');
        checkoutFee(amountToCents(row.amount), checkout);
      }
      const payload = { date, sales: rows.map(({ id: _id, ...row }) => row) };
      const limit = portal.maxRequestBytes ?? 12 * 1024 * 1024;
      if (new Blob([JSON.stringify(payload)]).size > limit) throw new Error(`O envio excede ${Math.floor(limit / 1024 / 1024)} MB. Envie menos vendas ou arquivos menores por vez.`);
      setBusy(true); submitting.current = true;
      const saved = await draft.beginSubmission();
      const result = await client.saveSales({ date: saved.date, sales: saved.rows.map(({ id: _id, ...row }) => row) }, saved.requestKey);
      const count = rows.length; await draft.clear(true); setAttachmentErrors({});
      const total = payload.sales.reduce((sum, row) => sum + amountToCents(row.amount), 0);
      const message = renderSaleAlert(portal.profile.saleAlertTemplate ?? DEFAULT_SALE_ALERT, total, count, portal.profile.name);
      notify({ text: client.isDemo ? message + ' · Demonstração: salva somente neste navegador. Esta venda não foi enviada ao administrador.' : message + ' · Enviada à administração. Aguardando aprovação.' });
      if (!result.duplicate) void notifyDemoSale(client, message);
      await refresh();
    } catch (cause) { if (cause instanceof ApiError && (client.isDemo || [400, 401, 403, 404, 413, 422].includes(cause.status))) draft.releaseSubmission(); setError((cause as Error).message); }
    finally { setBusy(false); submitting.current = false; }
  }
  return <section ref={salesSection} className="panel sales-panel"><div className="section-title"><Plus size={17} /><h2>LANÇAMENTO DE VENDAS MANUAIS</h2></div>
    <div className="mandatory"><AlertCircle size={15} /><p><strong>Obrigatório:</strong> Todos os lançamentos de vendas manuais são mandatórios. Suba todas as suas vendas no final do dia ou cadastre cada venda individualmente assim que ocorrer.</p></div>
    <div className={`draft-status ${draft.failed ? 'draft-error' : ''}`}><p aria-live="polite">{draft.message}</p><button type="button" className="button secondary" disabled={!draft.ready || !draft.dirty || draft.clearing || busy || pending || preparing.size > 0} onClick={() => void draft.clear().then(cleared => { if (cleared) setError(''); })}><Trash2 size={14} />Descartar rascunho</button></div>
    {pending && <p className="draft-pending" aria-live="polite">Envio aguardando confirmação. Toque em Confirmar envio para concluir sem duplicar as vendas.</p>}
    {(client.isDemo || portal.profile.id !== 'demo') && <CheckoutCard notify={notify} checkout={portal.checkouts.find(checkout => checkout.id === 'main') ?? onlyCheckout} />}
    {(client.isDemo || portal.profile.id !== 'demo') && portal.checkouts.some(checkout => checkout.id === 'pix') && <ManualPixCard notify={notify} checkout={portal.checkouts.find(checkout => checkout.id === 'pix')} />}
    <form onSubmit={submit}><fieldset disabled={busy || disabled || !draft.ready || draft.clearing}><fieldset disabled={pending}>
      <label className="field-label date-label" htmlFor="sale-date">Data da Venda <span aria-hidden="true">*</span></label><input className="date-input" type="date" id="sale-date" value={date} max={businessToday()} required onChange={event => setDate(event.target.value)} />
      <p className="field-label sales-count">Vendas a Lançar ({rows.length})</p>
      <div className="sale-rows">{rows.map((row, index) => <div className={`sale-row${partner ? ' partner-sale-row' : ''}`} key={row.id} data-receipt-row={row.id} onPaste={event => pasteReceipt(row.id, event)}>
        <span className="row-number">#{index + 1}</span>
        <div className="amount-input"><span>R$</span><input aria-label={`Valor bruto venda ${index + 1}`} placeholder="Valor Bruto (Ex: 197,00)" inputMode="decimal" required maxLength={16} value={row.amount} onChange={event => update(row.id, { amount: event.target.value })} /></div>
        {!partner && <div className="select-wrap"><select aria-label={`Checkout venda ${index + 1}`} required value={row.checkoutId} onChange={event => update(row.id, { checkoutId: event.target.value })}><option value="" disabled>Checkout *</option>{pending && row.checkoutId && !portal.checkouts.some(checkout => checkout.id === row.checkoutId) && <option value={row.checkoutId} disabled>Checkout anterior · confirmar envio</option>}{portal.checkouts.map(checkout => <option key={checkout.id} value={checkout.id}>{checkout.name}</option>)}</select><ChevronDown size={13} /></div>}
        <input type="time" aria-label={`Horário venda ${index + 1}`} required value={row.time} onChange={event => update(row.id, { time: event.target.value })} />
        <button type="button" className={`attach-button ${row.receipt && row.receipt.mime !== 'application/pdf' ? 'attached' : ''}`} aria-label={`Anexar print venda ${index + 1}`} aria-busy={preparing.has(row.id)} disabled={preparing.has(row.id)} onClick={() => document.getElementById(`receipt-${row.id}`)?.click()}>{preparing.has(row.id) ? <LoaderCircle className="spin" size={14} /> : <Camera size={14} />}{preparing.has(row.id) ? 'Preparando arquivo...' : row.receipt && row.receipt.mime !== 'application/pdf' ? 'Print anexado' : 'Anexar Print *'}</button>
        <input className="sr-only" tabIndex={-1} id={`receipt-${row.id}`} type="file" aria-label={`Print da venda ${index + 1}`} accept="image/png,image/jpeg,image/webp,image/heic,image/heif,.png,.jpg,.jpeg,.webp,.heic,.heif" onChange={event => { void attach(row.id, event.target.files?.[0]); event.target.value = ''; }} />
        <button className="icon-button delete-row" type="button" aria-label={`Remover venda ${index + 1}`} disabled={rows.length === 1} onClick={() => removeRow(row.id)}><Trash2 size={16} /></button>
        <input className="observation" aria-label={`Observação venda ${index + 1}`} placeholder="Observação (Ex: Cliente pagou via PIX manual após falha no checkout)..." maxLength={500} value={row.note} onChange={event => update(row.id, { note: event.target.value })} />
        <div className="sale-attachments">
          <div className="pdf-upload-actions"><button type="button" className={`button secondary pdf-attach-button ${row.receipt?.mime === 'application/pdf' ? 'attached' : ''}`} aria-label={`Anexar PDF venda ${index + 1}`} aria-busy={preparing.has(row.id)} disabled={preparing.has(row.id)} onClick={() => document.getElementById(`receipt-pdf-${row.id}`)?.click()}>{preparing.has(row.id) ? <LoaderCircle className="spin" size={16} /> : <FileText size={16} />}{row.receipt?.mime === 'application/pdf' ? 'PDF anexado' : 'Anexar PDF'}</button><small>PDF de até 2 MB · Uma imagem ou PDF por venda</small><input className="sr-only" tabIndex={-1} id={`receipt-pdf-${row.id}`} type="file" aria-label={`PDF da venda ${index + 1}`} accept="application/pdf,.pdf" onChange={event => { void attach(row.id, event.target.files?.[0]); event.target.value = ''; }} /></div>
          <div className="receipt-paste-target" aria-busy={preparing.has(row.id)}>
            {preparing.has(row.id) ? <LoaderCircle size={17} className="spin" /> : <ClipboardPaste size={17} />}
            <div className="receipt-paste-copy"><span>{preparing.has(row.id) ? 'Preparando comprovante...' : 'Cole a imagem do comprovante'}</span><div className="receipt-paste-editor" role="textbox" aria-label={`Área para colar comprovante venda ${index + 1}`} aria-disabled={pasteLocked} contentEditable={!pasteLocked} suppressContentEditableWarning tabIndex={pasteLocked ? -1 : 0} inputMode="none" data-receipt-paste-zone="true" data-placeholder="Clique aqui e use Ctrl+V ou ⌘V" onInput={event => { event.currentTarget.textContent = ''; }} /><small>Ou use o botão Colar imagem. Também funciona nos campos desta venda.</small></div>
            <button className="button secondary receipt-paste-button" type="button" aria-label={`Colar comprovante venda ${index + 1}`} disabled={preparing.has(row.id)} onClick={() => void attach(row.id, readClipboardImage)}>Colar imagem</button>
          </div>
          <SaleValuePreview row={row} checkout={partner ? onlyCheckout : portal.checkouts.find(checkout => checkout.id === row.checkoutId)} index={index} commissionBps={portal.profile.commissionBps} accountKind={portal.profile.accountKind} />
          {attachmentErrors[row.id] && <div role="alert" className="form-error attachment-error"><AlertCircle size={14} />{attachmentErrors[row.id]}</div>}
          {row.receipt && <div className="attachment-detail">{row.receipt.mime === 'application/pdf' ? <FileText size={12} /> : <FileImage size={12} />}<button type="button" onClick={() => preview(receiptViewFromInput(row.receipt!))}>{row.receipt.name}</button><button className="remove-attachment" type="button" aria-label={`${row.receipt.mime === 'application/pdf' ? 'Remover PDF' : 'Remover print'} venda ${index + 1}`} onClick={() => update(row.id, { receipt: null })}><X size={12} /></button></div>}
        </div>
      </div>)}</div></fieldset>
      {error && <div role="alert" className="form-error"><AlertCircle size={14} />{error}</div>}
      <div className="sales-actions"><button type="button" className="button secondary" disabled={pending || rows.length >= 10} onClick={() => setRows(previous => [...previous, blankRow()])}><Plus size={15} />Adicionar Outra Venda</button><button type="submit" className="button primary" disabled={preparing.size > 0}>{busy || preparing.size ? <LoaderCircle className="spin" size={15} /> : <Save size={15} />}{busy ? 'Enviando vendas...' : preparing.size ? 'Preparando comprovantes...' : pending ? 'Confirmar envio' : 'Salvar e Enviar Vendas'}</button></div>
      <p className="form-caption">Até 10 vendas por envio · Imagens de até 20 MB, reduzidas quando necessário. PDF de até 2 MB. Confira o comprovante antes de enviar.</p>
    </fieldset></form>
  </section>;
}

export default function App() {
  const [client, setClient] = useState(() => new PortalClient(currentToken()));
  const [portal, setPortal] = useState<Portal | null>(null), [period, setPeriod] = useState<Period>('today'), [tab, setTab] = useState<Tab>(initialTab);
  const [loading, setLoading] = useState(true), [error, setError] = useState<{ text: string; status: number } | null>(null);
  const [notice, setNotice] = useState<Notice | null>(null);
  const [receiptUrl, setReceiptUrl] = useState<ReceiptView | null>(null);
  const tabRefs = useRef<Array<HTMLButtonElement | null>>([]);
  useEffect(() => { const update = () => { setClient(new PortalClient(currentToken())); setPortal(null); setTab(initialTab()); }; window.addEventListener('hashchange', update); return () => window.removeEventListener('hashchange', update); }, []);
  useEffect(() => { let cancelled = false; setLoading(true); setError(null); client.portal(period).then(value => { if (!cancelled) setPortal(value); }).catch(cause => { if (!cancelled) setError({ text: (cause as Error).message, status: cause instanceof ApiError ? cause.status : 0 }); }).finally(() => { if (!cancelled) setLoading(false); }); return () => { cancelled = true; }; }, [client, period]);
  useEffect(() => { if (!notice) return; const timer = window.setTimeout(() => setNotice(null), 8000); return () => window.clearTimeout(timer); }, [notice]);
  useEffect(() => () => { if (receiptUrl?.url.startsWith('blob:')) URL.revokeObjectURL(receiptUrl.url); }, [receiptUrl]);
  async function refresh() { setLoading(true); try { setPortal(await client.portal(period)); setError(null); } catch (cause) { setError({ text: (cause as Error).message, status: cause instanceof ApiError ? cause.status : 0 }); } finally { setLoading(false); } }
  async function viewReceipt(id: string) { try { setReceiptUrl(await client.receipt(id)); } catch (cause) { setNotice({ text: (cause as Error).message, error: true }); } }
  const rawDisplay = portal ?? demoPortal(demoInitial(), period), canInteract = !loading && !error && !!portal;
  const display = { ...rawDisplay, checkouts: accountCheckouts(rawDisplay.checkouts, rawDisplay.profile.accountKind) };
  const profile = display.profile, finance = display.finance, partner = profile.accountKind === 'partner';
  const partnerPortal = partner || display.checkouts.some(checkout => checkout.id === 'exclusive_' + profile.id);
  const visibleTabs = tabs.filter(item => item.id !== 'marketing' || partnerPortal);
  const identified = client.isDemo || !!portal;
  const partnerEntry = document.documentElement.dataset.portalEntry === 'partner' || /\/parceiro(?:\.html)?\/?$/.test(window.location.pathname);
  const publicPartnerEntry = partnerEntry && client.isDemo;
  useEffect(() => {
    applyPageMetadata(publicPartnerEntry ? 'partner' : identified ? partnerPortal ? 'partner' : 'attendant' : partnerEntry ? 'partner' : 'loading');
    if (identified && !client.isDemo && (partnerPortal || partnerEntry)) {
      const url = new URL(publicAssetUrl(partnerPortal ? 'parceiro.html' : ''));
      url.search = window.location.search; url.hash = '/atendente/' + client.token;
      url.searchParams.delete('token');
      if (url.href !== window.location.href) window.history.replaceState(window.history.state, '', url);
    }
  }, [identified, partnerPortal, partnerEntry, publicPartnerEntry, client]);
  useEffect(() => { if (!partnerPortal && tab === 'marketing') setTab('sales'); }, [partnerPortal, tab]);
  if (publicPartnerEntry) return <div className="portal-shell"><header className="portal-header"><span className="brand"><Brand /></span></header><main><BrandIntro accountKind="partner" /><section className="panel"><h2>Acesso individual do parceiro</h2><p className="section-description">Use o link individual enviado pela administração para abrir suas vendas e pagamentos.</p></section></main></div>;
  return <div className="portal-shell"><a className="skip-link" href="#portal-main" onClick={event => { event.preventDefault(); document.getElementById('portal-main')?.focus(); }}>Pular para o conteúdo</a>
    <header className="portal-header"><a className="brand" href="#" onClick={event => { event.preventDefault(); setTab('sales'); }} aria-label="BRAVUS início"><Brand /></a><div className="header-access"><span className={`access-status ${client.isDemo ? 'demo' : ''}`}><ShieldCheck size={12} />{client.isDemo ? 'Demonstração' : 'Acesso individual'}</span><span className="attendant-name">{portal?.profile.name ?? 'Seu portal'}</span><button className="avatar" aria-label="Abrir meus dados" onClick={() => setTab('profile')}><ProfileAvatar photoUrl={profile.photoUrl} name={profile.name} /></button></div></header>
    <main id="portal-main" tabIndex={-1}>
      {tab !== 'profile' && (identified || partnerEntry) && <BrandIntro accountKind={partnerPortal || !identified && partnerEntry ? 'partner' : profile.accountKind} />}
      {error && <div className="auth-error" role="alert"><AlertCircle size={15} /><span>{error.text}{error.status === 401 && ' Peça um novo link ao responsável pelo BRAVUS.'}</span>{error.status !== 401 && <button onClick={() => void refresh()}>Tentar novamente</button>}</div>}
      {tab !== 'profile' && identified && <section className="panel financial-panel" aria-busy={loading}><div className="financial-heading"><div className="section-title"><DollarSign size={18} /><h2>{partnerPortal ? 'EXTRATO FINANCEIRO DO PARCEIRO' : 'EXTRATO FINANCEIRO & COMISSÕES'}</h2></div><div className="period-picker"><CalendarDays size={15} /><select aria-label="Período do extrato" value={period} onChange={event => setPeriod(event.target.value as Period)}>{Object.entries(periodLabels).map(([key, label]) => <option value={key} key={key}>{label}</option>)}</select><ChevronDown size={13} /></div></div>
        {partnerPortal ? <PartnerFinancialSummary portal={display} /> : <>
        <div className="financial-grid attendant-financial-grid"><article className="metric"><h3>FATURAMENTO<br />CONSOLIDADO</h3><strong>{money(finance.grossCents)}</strong><small>{finance.count} {finance.count === 1 ? 'venda' : 'vendas'}</small></article><article className="metric"><h3>CUSTO ADS ( <span className="status-dot" /> )</h3><strong>- {money(finance.adsCents)}</strong><small>Repasse por gasto</small></article><article className={`metric balance ${finance.availableCents < 0 ? 'negative' : ''}`}><h3>SALDO ACUMULADO ATUAL</h3><strong>{money(finance.availableCents)}</strong><small>Disponível para repasse</small></article></div>
        <dl className="finance-breakdown"><div><dt>Seu valor nas vendas aprovadas</dt><dd>{money(finance.commissionCents)}</dd></div><div><dt>Saques e ajustes no período</dt><dd>− {money(finance.withdrawalFeeCents)}</dd></div></dl>
        </>}
        {portal && finance.debtCents > 0 && <div className="finance-details"><span className="debt-text">Custos pendentes no período: {money(finance.debtCents)}</span></div>}
        {tab !== 'ranking' && <button className="button secondary ranking-shortcut" disabled={!canInteract} onClick={() => setTab('ranking')}><Trophy size={16} />Ver pódio e ranking<ArrowRight size={14} /></button>}
      </section>}
      {tab !== 'profile' && finance.pendingSalesCount > 0 && <div className="pending-sales-notice"><History size={15} /><span><strong>{finance.pendingSalesCount} venda(s) em análise · {money(finance.pendingSalesCents)}</strong><br />{partnerPortal ? 'O valor será liberado após a aprovação da administração.' : 'A comissão será liberada após a aprovação da administração.'}</span></div>}
      <nav className={`portal-tabs${partner ? ' partner-tabs' : ''}${partnerPortal ? ' marketing-tabs' : ''}`} role="tablist" aria-label={partnerPortal ? 'Portal do parceiro' : 'Portal do atendente'} onKeyDown={event => { const index = visibleTabs.findIndex(item => item.id === tab); const next = event.key === 'ArrowRight' ? (index + 1) % visibleTabs.length : event.key === 'ArrowLeft' ? (index + visibleTabs.length - 1) % visibleTabs.length : event.key === 'Home' ? 0 : event.key === 'End' ? visibleTabs.length - 1 : -1; if (next >= 0) { event.preventDefault(); setTab(visibleTabs[next].id); tabRefs.current[next]?.focus(); } }}>{visibleTabs.map((item, index) => <button ref={element => { tabRefs.current[index] = element; }} key={item.id} type="button" id={`tab-${item.id}`} role="tab" aria-selected={tab === item.id} aria-controls={`panel-${item.id}`} tabIndex={tab === item.id ? 0 : -1} className={tab === item.id ? 'active' : ''} onClick={() => setTab(item.id)}><item.icon size={15} /><span>{item.label}{item.id === 'payouts' ? ` (${display.payouts.length})` : ''}</span></button>)}</nav>
      <div role="tabpanel" id={`panel-${tab}`} aria-labelledby={`tab-${tab}`}>
        {tab === 'marketing' && partnerPortal && <PartnerAds key={client.token} client={client} report={display.marketing} period={period} disabled={!canInteract} refresh={refresh} notify={setNotice} />}
        {tab === 'sales' && <><SalesForm key={client.token || 'demo'} client={client} portal={display} disabled={!canInteract} refresh={refresh} notify={setNotice} preview={setReceiptUrl} /><section className="panel history-panel"><div className="section-title"><History size={17} /><h2>VENDAS LANÇADAS</h2><span className="item-count">{display.sales.length}</span><button className="icon-button refresh-button" aria-label="Atualizar vendas" disabled={loading} onClick={() => void refresh()}><RefreshCw size={14} className={loading ? 'spin' : ''} /></button></div>{display.sales.length ? <div className="table-scroll"><table><thead><tr><th>Data / Horário</th><th>Checkout</th><th>Valor bruto</th><th>Seu valor</th><th>Situação</th><th>Observação</th><th>Comprovante</th></tr></thead><tbody>{display.sales.map(sale => <tr key={sale.id}><td>{dateLabel(sale.date)}<small>{sale.time}</small></td><td>{sale.checkoutName}</td><td className="money-cell">{money(sale.amountCents)}</td><td className="money-cell">{money(saleEarnings(sale))}{(sale.commissionMode !== 'gross-share-less-fees' || sale.attendantFeeCents == null || partner && (sale.commissionBps !== 10000 || sale.attendantFeeCents !== sale.feeCents)) && <small>Regra anterior</small>}</td><td><span className={`sale-status ${sale.status}`}>{saleStatusLabel(sale)}</span>{sale.reviewNote && <small className="sale-review-note">{sale.reviewNote}</small>}</td><td className="note-cell">{sale.note || '—'}</td><td><button className="receipt-link" onClick={() => void viewReceipt(sale.receiptId)} aria-label={`Ver comprovante da venda de ${money(sale.amountCents)}`}><FileImage size={14} />Ver comprovante</button></td></tr>)}</tbody></table></div> : <Empty icon={<History size={24} />} title="Nenhuma venda neste período">Seus lançamentos aparecerão aqui depois do envio.</Empty>}<p className="history-caption">Exibindo até 100 vendas do período selecionado.</p></section></>}
        {tab === 'ranking' && <Ranking key={client.token || 'demo'} client={client} today={display.today} refreshKey={portal} />}
        {tab === 'payouts' && <section className="panel payouts-panel"><div className="section-title"><History size={17} /><h2>MEUS REPASSES</h2></div><div className="payout-summary"><div><span>Saldo disponível</span><strong>{money(finance.availableCents)}</strong></div><div><span>Taxas de saque já pagas</span><strong>{money(finance.paidPayoutCents - finance.paidPayoutNetCents)}</strong></div><div><span>Total pago</span><strong>{money(finance.paidPayoutNetCents)}</strong></div></div><p className="payout-help">Os repasses são feitos e registrados manualmente pela administração. O histórico será atualizado após o pagamento. {partnerPortal ? <>Novos repasses são <strong>sem taxa de saque</strong>: o valor registrado é o valor enviado no PIX. ADS servem apenas para controle de lucro e ROI, sem desconto no repasse.</> : <>A taxa do gateway é dividida somente no pagamento.</>}</p>{!profile.pixKey && <div className="pix-reminder"><Info size={14} /><span>Cadastre sua chave PIX para receber os pagamentos da administração.</span><button onClick={() => setTab('profile')}>Cadastrar PIX <ArrowRight size={13} /></button></div>}{display.payouts.length ? <div className="table-scroll"><table><thead><tr><th>Solicitado em</th><th>Valor reservado / debitado</th><th>Taxa cobrada</th><th>PIX pago</th><th>Status</th><th>Pagamento</th><th>Observação</th></tr></thead><tbody>{display.payouts.map(payout => <tr key={payout.id}><td>{new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short', timeZone: 'America/Sao_Paulo' }).format(new Date(payout.requestedAt))}</td><td className="money-cell">{money(payout.amountCents)}</td><td className="money-cell">{money(payout.withdrawalFeeCents ?? 0)}</td><td className="money-cell">{payout.status === 'paid' ? money(payoutNet(payout)) : '—'}</td><td><span className={`payout-badge ${payout.status}`}>{payout.status === 'pending' ? 'Em análise' : payout.status === 'paid' ? 'Pago' : 'Cancelado'}</span></td><td>{payout.paidAt ? new Intl.DateTimeFormat('pt-BR').format(new Date(payout.paidAt)) : '—'}</td><td>{payout.note || '—'}</td></tr>)}</tbody></table></div> : <Empty icon={<Wallet size={26} />} title="Nenhum repasse por enquanto">Os pagamentos registrados pela administração aparecerão aqui.</Empty>}</section>}
        {tab === 'profile' && (portal ? <ProfileForm key={`${profile.id}-${client.token}`} profile={profile} client={client} disabled={!canInteract} refresh={refresh} notify={setNotice} /> : loading ? <div className="panel loading-state" role="status"><LoaderCircle size={22} className="spin" />Carregando seus dados...</div> : null)}
      </div>
      <footer className="portal-footer"><span><span className="footer-brand">BRAVUS BRASIL</span> Pesca · Agro · Aventura</span>{!client.isDemo && <button onClick={async () => { try { await navigator.clipboard.writeText(window.location.href); setNotice({ text: 'Seu link individual foi copiado. Compartilhe apenas com o responsável pelo acesso.' }); } catch { setNotice({ text: 'Não foi possível copiar o link neste navegador.', error: true }); } }}><KeyRound size={12} />Copiar meu link individual<Copy size={11} /></button>}{!partner && <a href="#/admin">Administração</a>}</footer>
    </main>
    {notice && <div className={`toast ${notice.error ? 'error' : ''}`} role={notice.error ? 'alert' : 'status'}>{notice.error ? <AlertCircle size={17} /> : <CheckCircle2 size={17} />}<span>{notice.text}</span><button className="icon-button" aria-label="Fechar aviso" onClick={() => setNotice(null)}><X size={16} /></button></div>}
    {receiptUrl && <Dialog title="Comprovante da venda" close={() => setReceiptUrl(null)}><ReceiptPreview receipt={receiptUrl} imageAlt="Print do comprovante da venda" /></Dialog>}
  </div>;
}
