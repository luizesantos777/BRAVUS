import { DEFAULT_COMMISSION_BPS, DEMO_KEY, demoInitial, saleStatusLabels, validateProfile, validDate } from './domain.ts';
import type { DemoData } from './domain.ts';

export function readDemoData(): DemoData {
  const saved = localStorage.getItem(DEMO_KEY);
  if (!saved) return demoInitial();
  try {
    const data = JSON.parse(saved) as DemoData;
    if (data.version !== 1 || !Array.isArray(data.sales) || !Array.isArray(data.payouts) || !Array.isArray(data.costs) || !data.receipts || typeof data.receipts !== 'object') throw new Error();
    data.profile = { ...demoInitial().profile, ...data.profile }; validateProfile(data.profile);
    if (data.submittedBatches && (typeof data.submittedBatches !== 'object' || Array.isArray(data.submittedBatches) || Object.keys(data.submittedBatches).length > 100 || !Object.values(data.submittedBatches).every(entry => entry && /^[a-f0-9]{64}$/.test(entry.hash) && Number.isInteger(entry.count) && entry.count > 0 && entry.count <= 10))) throw new Error();
    if (data.settlementVersion !== 1) { data.profile.commissionBps = DEFAULT_COMMISSION_BPS; data.settlementVersion = 1; }
    data.sales = data.sales.map(sale => ({ ...sale, status: sale.status ?? 'approved', reviewNote: sale.reviewNote ?? '', reviewedAt: sale.reviewedAt ?? null }));
    if (!data.sales.every(sale => typeof sale.id === 'string' && validDate(sale.date) && Number.isSafeInteger(sale.amountCents) && Number.isSafeInteger(sale.feeCents) && Number.isInteger(sale.commissionBps) && sale.commissionBps >= 0 && sale.commissionBps <= 10000 && (sale.commissionMode === undefined || sale.commissionMode === 'net-share' || sale.commissionMode === 'gross-share-less-fees') && (sale.attendantFeeCents == null || Number.isSafeInteger(sale.attendantFeeCents) && sale.attendantFeeCents >= 0 && sale.attendantFeeCents <= sale.feeCents) && Object.hasOwn(saleStatusLabels, sale.status) && typeof sale.reviewNote === 'string')) throw new Error();
    if (!data.payouts.every(payout => Number.isSafeInteger(payout.amountCents) && payout.amountCents > 0 && (payout.withdrawalFeeCents === undefined || Number.isSafeInteger(payout.withdrawalFeeCents) && payout.withdrawalFeeCents >= 0 && payout.withdrawalFeeCents < payout.amountCents))) throw new Error();
    data.payouts = data.payouts.map(payout => payout.status === 'paid' ? { ...payout, gatewayFeeCents: payout.gatewayFeeCents ?? payout.withdrawalFeeCents ?? 0 } : { ...payout, withdrawalFeeCents: 0, gatewayFeeCents: 0 });
    if (data.manualPayoutsVersion !== 1) {
      data.payouts = data.payouts.map(payout => payout.status === 'pending' ? { ...payout, status: 'cancelled', withdrawalFeeCents: 0, gatewayFeeCents: 0, note: 'Solicitação cancelada: pagamentos manuais pela administração.' } : payout);
      data.manualPayoutsVersion = 1;
    }
    return data;
  } catch { throw new Error('Não foi possível ler a demonstração salva. Seus dados foram preservados; use outro navegador para experimentar.'); }
}
export function writeDemoData(data: DemoData) {
  try { localStorage.setItem(DEMO_KEY, JSON.stringify(data)); }
  catch { throw new Error('Não foi possível salvar a demonstração. Verifique o espaço de armazenamento do navegador.'); }
}
