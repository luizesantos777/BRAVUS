import type { PartnerBusinessSummary } from './partner-business.ts';
export type Period = 'today' | 'yesterday' | 'week' | 'month' | 'all';
export type AccountKind = 'attendant' | 'partner';
export type PixType = '' | 'email' | 'cpf' | 'cnpj' | 'phone' | 'random';
export type PayoutStatus = 'pending' | 'paid' | 'cancelled';
export type SaleStatus = 'pending' | 'approved' | 'rejected';
export const saleStatusLabels: Record<SaleStatus, string> = { pending: 'Em análise', approved: 'Aprovada', rejected: 'Recusada' };
export const periodLabels: Record<Period, string> = { today: 'Hoje', yesterday: 'Ontem', week: 'Últimos 7 dias', month: 'Este mês', all: 'Todo o período' };
export const pixLabels: Record<PixType, string> = { '': 'Selecione o tipo', email: 'E-mail', cpf: 'CPF', cnpj: 'CNPJ', phone: 'Telefone', random: 'Chave aleatória' };
export interface Profile { id: string; accountKind?: AccountKind; name: string; email: string; phone: string; pixType: PixType; pixKey: string; pixOwner: string; commissionBps: number; photoUrl: string; saleAlertTemplate: string }
export interface CheckoutTier { aboveAmountCents: number; feeBps: number; fixedFeeCents: number }
export interface CheckoutTierInput { aboveAmount: string; fee: string; fixedFee: string }
export interface Checkout { id: string; name: string; feeBps: number; fixedFeeCents: number; minAmountCents: number; higherTier: CheckoutTier | null; maxAmountCents: number | null }
export interface Sale { id: string; date: string; time: string; checkoutId: string; checkoutName: string; amountCents: number; feeCents: number; attendantFeeCents?: number | null; commissionBps: number; commissionMode?: 'net-share' | 'gross-share-less-fees'; note: string; receiptId: string; createdAt: string; status: SaleStatus; reviewNote: string; reviewedAt: string | null; cancelledAt?: string | null }
export function saleStatusLabel(sale: Pick<Sale, 'status' | 'cancelledAt'>) { return sale.cancelledAt ? 'Cancelada' : saleStatusLabels[sale.status]; }
export interface ReceiptDuplicates { total: number; matches: (Pick<Sale, 'id' | 'date' | 'time' | 'amountCents' | 'status' | 'cancelledAt'> & { attendantName: string })[] }
export interface AdminSale extends Sale { attendantId: string; attendantName: string; accountKind?: AccountKind; gatewayCostCents?: number | null; receiptDuplicates?: ReceiptDuplicates }
export interface AdminSalesPage { sales: AdminSale[]; total: number; page: number; pageSize: number }
export interface AdminCost extends DailyCost { attendantId: string; attendantName: string }
export interface DailyCost { date: string; adsCents: number; withdrawalFeeCents: number }
export interface PartnerAdsCost { date: string; adsCents: number }
export interface MarketingSummary { earningsCents: number; chargedAdsCents: number; ownAdsCents: number; totalAdsCents: number; profitCents: number; roiPercent: number | null }
export interface MarketingReport extends MarketingSummary { history: PartnerAdsCost[] }
export interface Payout { id: string; amountCents: number; withdrawalFeeCents?: number; gatewayFeeCents?: number; status: PayoutStatus; requestedAt: string; paidAt: string | null; note: string }
export interface ReceiptInput { name: string; mime: string; base64: string }
export interface SaleInput { amount: string; checkoutId: string; time: string; note: string; receipt: ReceiptInput | null }
export interface SaleBatch { date: string; sales: SaleInput[] }
export interface Finance { grossCents: number; feeCents: number; transactionFeeCents: number; gatewayFeeCents: number; businessGatewayFeeCents: number; withdrawalFeeCents: number; businessShareCents: number; adsCents: number; commissionCents: number; availableCents: number; pendingPayoutCents: number; paidPayoutCents: number; paidPayoutNetCents: number; debtCents: number; count: number; pendingSalesCount: number; pendingSalesCents: number; rejectedSalesCount: number }
export interface Portal { maxRequestBytes?: number; profile: Profile; checkouts: Checkout[]; sales: Sale[]; payouts: Payout[]; finance: Finance; marketing?: MarketingReport; today: string }
export interface RankingEntry { id: string; name: string; photoUrl: string; grossCents: number; count: number; mine: boolean }
export interface AdminAttendant extends Pick<Profile, 'pixType' | 'pixKey' | 'pixOwner'> { id: string; accountKind?: AccountKind; name: string; active: boolean; canDelete?: boolean; commissionBps: number; createdAt: string; salesCount: number; grossCents: number; finance: Finance; marketing?: MarketingReport; business?: PartnerBusinessSummary }
export interface AdminPayout extends Payout { attendantId: string; attendantName: string; pixType: PixType; pixKey: string; pixOwner: string }
export interface AdminDashboard { attendants: AdminAttendant[]; payouts: AdminPayout[]; checkouts: Checkout[]; pendingSalesCount: number; todayAdsCents: number; costs: AdminCost[] }
export interface Invitation { attendantId: string; accountKind?: AccountKind; name: string; token: string }
export interface DemoData { version: 1; settlementVersion?: 1; manualPayoutsVersion?: 1; submittedBatches?: Record<string, { hash: string; count: number }>; profile: Profile; sales: Sale[]; payouts: Payout[]; costs: DailyCost[]; receipts: Record<string, ReceiptInput> }
export const MAX_RECEIPT_BYTES = 2 * 1024 * 1024;
export const MAX_SALE_CENTS = 100_000_000;
export const DEFAULT_COMMISSION_BPS = 5000;
export const PARTNER_GATEWAY_FEE_BPS = 1200;
export const PARTNER_FIXED_FEE_CENTS = 200;
export const PARTNER_CHECKOUT: Checkout = { id: 'partner', name: 'Gateway do parceiro', feeBps: PARTNER_GATEWAY_FEE_BPS, fixedFeeCents: PARTNER_FIXED_FEE_CENTS, minAmountCents: 1, maxAmountCents: 300000, higherTier: null };
export const GATEWAY_WITHDRAWAL_FEE_CENTS = 500;
export const ATTENDANT_GATEWAY_FEE_BPS = 5000;
export const ATTENDANT_WITHDRAWAL_FEE_CENTS = 250;
export const DEMO_KEY = 'bravus.attendant.demo.v1';
export const DEFAULT_SALE_ALERT = '✅ Venda de {valor} lançada com sucesso!';
export const MAX_AVATAR_BYTES = 256 * 1024;
export function renderSaleAlert(template: string, amountCents: number, count: number, name: string): string {
  const values: Record<string, string> = { valor: money(amountCents), qtd: String(count), nome: name };
  return template.replace(/\{(valor|qtd|nome)\}/g, (_match, key: string) => values[key]);
}
export function detectPixType(value: string): PixType {
  const key = value.trim(), digits = key.replace(/\D/g, '');
  if (!key) return '';
  if (key.includes('@')) return 'email';
  if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(key)) return 'random';
  if (key.startsWith('+') || /[()]/.test(key)) return 'phone';
  if (digits.length === 14) return 'cnpj';
  if (digits.length === 11 && !/^(\d)\1+$/.test(digits)) {
    const check = (length: number) => { const sum = [...digits.slice(0, length)].reduce((total, digit, index) => total + Number(digit) * (length + 1 - index), 0); const mod = (sum * 10) % 11; return mod === 10 ? 0 : mod; };
    if (check(9) === Number(digits[9]) && check(10) === Number(digits[10])) return 'cpf';
  }
  return 'phone';
}
export function validateAvatar(value: string): string {
  if (!value) return '';
  const match = value.match(/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$/);
  if (!match || value.length > Math.ceil(MAX_AVATAR_BYTES / 3) * 4 + 40) throw new Error('Use uma foto PNG, JPG ou WEBP de até 256 KB após o ajuste.');
  let bytes: string;
  try { bytes = atob(match[2]); } catch { throw new Error('A foto de perfil é inválida.'); }
  const valid = match[1] === 'png' && bytes.startsWith('\x89PNG\r\n\x1a\n') || match[1] === 'jpeg' && bytes.startsWith('\xff\xd8\xff') || match[1] === 'webp' && bytes.startsWith('RIFF') && bytes.slice(8, 12) === 'WEBP';
  if (!valid || bytes.length > MAX_AVATAR_BYTES) throw new Error('A foto de perfil é inválida.');
  return value;
}
export const money = (cents: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(cents / 100);
export function splitGatewayFee(feeCents: number): number { return Math.floor((feeCents * ATTENDANT_GATEWAY_FEE_BPS + 5000) / 10000); }
/** Partners bear the gateway fee in full and retain the remaining gross amount. */
export function allocatedSaleFee(feeCents: number, accountKind?: AccountKind): number { return accountKind === 'partner' ? feeCents : splitGatewayFee(feeCents); }
/** One automatic partner tariff; shared attendant tariffs remain separate. */
export function accountCheckouts(checkouts: Checkout[], accountKind?: AccountKind): Checkout[] {
  if (accountKind !== 'partner') return checkouts.filter(checkout => checkout.id !== PARTNER_CHECKOUT.id);
  const checkout = checkouts.find(item => item.id.startsWith('exclusive_')) ?? checkouts.find(item => item.id === PARTNER_CHECKOUT.id) ?? PARTNER_CHECKOUT;
  return [{ ...checkout, feeBps: PARTNER_GATEWAY_FEE_BPS, fixedFeeCents: PARTNER_FIXED_FEE_CENTS, higherTier: null }];
}
export function withdrawalFees(accountKind?: AccountKind) { return accountKind === 'partner' ? { withdrawalFeeCents: 0, gatewayFeeCents: 0 } : { withdrawalFeeCents: ATTENDANT_WITHDRAWAL_FEE_CENTS, gatewayFeeCents: GATEWAY_WITHDRAWAL_FEE_CENTS }; }
export function attendantSaleFee(sale: Pick<Sale, 'feeCents' | 'attendantFeeCents'>): number { return sale.attendantFeeCents ?? sale.feeCents; }
/** Every sale keeps its own formula and allocated fee; missing allocations preserve historical full-fee records. */
export function saleEarnings(sale: Pick<Sale, 'amountCents' | 'feeCents' | 'attendantFeeCents' | 'commissionBps' | 'commissionMode'>): number {
  if (sale.commissionMode === 'gross-share-less-fees') return sale.amountCents - Math.floor((sale.amountCents * (10000 - sale.commissionBps) + 5000) / 10000) - attendantSaleFee(sale);
  return Math.round((sale.amountCents - sale.feeCents) * sale.commissionBps / 10000);
}
export function payoutNet(payout: Pick<Payout, 'amountCents' | 'withdrawalFeeCents'>): number { return payout.amountCents - (payout.withdrawalFeeCents ?? 0); }
export function payoutExpectedNet(payout: Pick<Payout, 'amountCents' | 'withdrawalFeeCents' | 'status'>, accountKind?: AccountKind): number {
  return payout.status === 'pending' ? payout.amountCents - withdrawalFees(accountKind).withdrawalFeeCents : payoutNet(payout);
}
export function validatePayoutAmount(amountCents: number, availableCents: number, accountKind?: AccountKind): void {
  const fee = withdrawalFees(accountKind).withdrawalFeeCents;
  if (!Number.isSafeInteger(amountCents) || amountCents <= fee) throw new Error(fee ? `O saque deve ser maior que sua parte da taxa: ${money(fee)}.` : 'Informe um valor de repasse maior que zero.');
  if (amountCents > availableCents) throw new Error('O valor ultrapassa seu saldo disponível para repasse.');
}
export function checkoutFee(amountCents: number, checkout: Checkout): number {
  if (!Number.isSafeInteger(amountCents) || amountCents <= 0 || amountCents > MAX_SALE_CENTS) throw new Error('Informe um valor de venda válido.');
  if (amountCents < checkout.minAmountCents) throw new Error(`${checkout.name}: valor mínimo de ${money(checkout.minAmountCents)} por venda.`);
  if (checkout.maxAmountCents != null && amountCents > checkout.maxAmountCents) throw new Error(`${checkout.name}: valor máximo de ${money(checkout.maxAmountCents)} por venda.`);
  const tariff = checkout.higherTier && amountCents > checkout.higherTier.aboveAmountCents ? checkout.higherTier : checkout;
  return Math.floor((amountCents * tariff.feeBps + 5000) / 10000) + tariff.fixedFeeCents;
}
export function checkoutRateLabel(checkout: Checkout, amountCents?: number): string {
  const label = (tariff: Pick<Checkout, 'feeBps' | 'fixedFeeCents'>) => `${new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(tariff.feeBps / 100)}% + ${money(tariff.fixedFeeCents)} por venda`;
  const tier = checkout.higherTier;
  const maximum = checkout.maxAmountCents != null ? ` · Até ${money(checkout.maxAmountCents)} por venda` : '';
  if (!tier) return label(checkout) + maximum;
  const limit = money(tier.aboveAmountCents);
  if (amountCents === undefined) return `Até ${limit}: ${label(checkout)} · Acima de ${limit}: ${label(tier)}${maximum}`;
  return (amountCents > tier.aboveAmountCents ? `${label(tier)} · Acima de ${limit}` : `${label(checkout)} · Até ${limit}`) + maximum;
}
export const MANUAL_PIX_TARIFF = { feeBps: 699, fixedFeeCents: 169, minAmountCents: 500, higherTier: null, maxAmountCents: null };
export const CHECKOUT_PIX_TARIFF = { feeBps: 1500, fixedFeeCents: 199, minAmountCents: 1, higherTier: null, maxAmountCents: 100000 };
export const BUCKPAY_TARIFF = { ...CHECKOUT_PIX_TARIFF, feeBps: 699, fixedFeeCents: 169 };
export function percentageToBps(value: string): number {
  if (!/^\d{1,3}(?:[.,]\d{1,2})?$/.test(value.trim())) throw new Error('Informe um percentual entre 0 e 100, com até duas casas decimais.');
  const [whole, fraction = ''] = value.trim().replace(',', '.').split('.');
  const bps = Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
  if (bps > 10000) throw new Error('O percentual não pode ultrapassar 100%.');
  return bps;
}
export function businessToday(date = new Date()): string {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(date);
  const part = (type: string) => parts.find(item => item.type === type)!.value;
  return `${part('year')}-${part('month')}-${part('day')}`;
}
export const businessTime = () => new Intl.DateTimeFormat('pt-BR', { timeZone: 'America/Sao_Paulo', hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date());
export function validDate(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
export const dateLabel = (value: string) => new Intl.DateTimeFormat('pt-BR').format(new Date(`${value}T12:00:00Z`));
export function amountToCents(value: string): number {
  let normalized = value.trim();
  if (/^\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?$/.test(normalized)) normalized = normalized.replaceAll('.', '');
  if (!/^\d+(?:[.,]\d{1,2})?$/.test(normalized)) throw new Error('Informe um valor válido, como 197,00.');
  const [whole, fraction = ''] = normalized.replace(',', '.').split('.');
  const cents = Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
  if (!Number.isSafeInteger(cents) || cents <= 0 || cents > MAX_SALE_CENTS) throw new Error('O valor deve ser maior que zero e de até R$ 1.000.000,00.');
  return cents;
}
export function inPeriod(date: string, period: Period, today: string) {
  if (period === 'all') return true;
  if (period === 'today') return date === today;
  if (period === 'month') return date.slice(0, 7) === today.slice(0, 7) && date <= today;
  const start = new Date(`${today}T12:00:00Z`);
  start.setUTCDate(start.getUTCDate() - (period === 'yesterday' ? 1 : 6));
  const lower = start.toISOString().slice(0, 10);
  return period === 'yesterday' ? date === lower : date >= lower && date <= today;
}
export function calculateFinance(sales: Sale[], costs: DailyCost[], payouts: Payout[], period: Period, today: string, accountKind?: AccountKind): Finance {
  const pending = sales.filter(sale => sale.status === 'pending' && inPeriod(sale.date, period, today));
  const rejectedSalesCount = sales.filter(sale => sale.status === 'rejected' && inPeriod(sale.date, period, today)).length;
  sales = sales.filter(sale => !sale.status || sale.status === 'approved');
  const dates = new Set([...sales.map(sale => sale.date), ...costs.map(cost => cost.date)]);
  let earned = 0, commissionCents = 0, debtCents = 0;
  for (const date of dates) {
    const daily = sales.filter(sale => sale.date === date);
    const commission = daily.reduce((sum, sale) => sum + saleEarnings(sale), 0);
    // Partner ADS remain available to profit/ROI reporting, but never debit the
    // payout ledger, regardless of who entered the advertising cost or its date.
    const cost = costs.filter(cost => cost.date === date).reduce((sum, cost) => sum + (accountKind === 'partner' ? 0 : cost.adsCents) + cost.withdrawalFeeCents, 0);
    earned += commission - cost;
    if (inPeriod(date, period, today)) {
      commissionCents += commission;
      debtCents += Math.max(0, cost - commission);
    }
  }
  const filtered = sales.filter(sale => inPeriod(sale.date, period, today));
  const filteredCosts = costs.filter(cost => inPeriod(cost.date, period, today));
  const pendingPayoutCents = payouts.filter(payout => payout.status === 'pending').reduce((sum, payout) => sum + payout.amountCents, 0);
  const paidPayoutCents = payouts.filter(payout => payout.status === 'paid').reduce((sum, payout) => sum + payout.amountCents, 0);
  const transactionFeeCents = filtered.reduce((sum, sale) => sum + attendantSaleFee(sale), 0);
  const gatewayFeeCents = filtered.reduce((sum, sale) => sum + sale.feeCents, 0), businessGatewayFeeCents = gatewayFeeCents - transactionFeeCents;
  const withdrawalFeeCents = filteredCosts.reduce((sum, cost) => sum + cost.withdrawalFeeCents, 0) + payouts.filter(payout => payout.status === 'paid' && inPeriod(businessToday(new Date(payout.paidAt ?? payout.requestedAt)), period, today)).reduce((sum, payout) => sum + (payout.withdrawalFeeCents ?? 0), 0);
  const businessShareCents = filtered.reduce((sum, sale) => sum + sale.amountCents - sale.feeCents - saleEarnings(sale), 0);
  const paidPayoutNetCents = payouts.filter(payout => payout.status === 'paid').reduce((sum, payout) => sum + payoutNet(payout), 0);
  return { grossCents: filtered.reduce((sum, sale) => sum + sale.amountCents, 0), feeCents: transactionFeeCents + withdrawalFeeCents, transactionFeeCents, gatewayFeeCents, businessGatewayFeeCents, withdrawalFeeCents, businessShareCents, adsCents: filteredCosts.reduce((sum, cost) => sum + cost.adsCents, 0), commissionCents, availableCents: earned - pendingPayoutCents - paidPayoutCents, pendingPayoutCents, paidPayoutCents, paidPayoutNetCents, debtCents, count: filtered.length, pendingSalesCount: pending.length, pendingSalesCents: pending.reduce((sum, sale) => sum + sale.amountCents, 0), rejectedSalesCount };
}
export function calculateMarketingSummary(earningsCents: number, chargedAdsCents: number, ownAdsCents: number): MarketingSummary {
  const totalAdsCents = chargedAdsCents + ownAdsCents, profitCents = earningsCents - totalAdsCents;
  return { earningsCents, chargedAdsCents, ownAdsCents, totalAdsCents, profitCents, roiPercent: totalAdsCents > 0 ? profitCents / totalAdsCents * 100 : null };
}
export function calculateMarketing(finance: Finance, ownCosts: PartnerAdsCost[], period: Period, today: string): MarketingReport {
  const history = ownCosts.filter(cost => inPeriod(cost.date, period, today)).map(cost => ({ date: cost.date, adsCents: cost.adsCents }));
  return { ...calculateMarketingSummary(finance.commissionCents, finance.adsCents, history.reduce((sum, cost) => sum + cost.adsCents, 0)), history: history.sort((a, b) => b.date.localeCompare(a.date)).slice(0, 100) };
}
export function validateSaleReview(input: unknown): { status: 'approved' | 'rejected'; note: string } {
  if (!input || typeof input !== 'object') throw new Error('Informe a decisão sobre a venda.');
  const data = input as Record<string, unknown>;
  if (data.status !== 'approved' && data.status !== 'rejected' || typeof data.note !== 'string' || data.note.length > 500) throw new Error('Informe uma decisão válida e uma observação de até 500 caracteres.');
  const note = data.note.trim();
  if (data.status === 'rejected' && !note) throw new Error('Informe o motivo da recusa.');
  return { status: data.status, note };
}
export function validateSaleCancellation(input: unknown): string {
  const note = (input as { note?: unknown } | null)?.note;
  if (typeof note !== 'string' || !note.trim() || note.length > 500) throw new Error('Informe o motivo do cancelamento, com até 500 caracteres.');
  return note.trim();
}
export function validateProfile(value: unknown): Pick<Profile, 'name' | 'email' | 'phone' | 'pixType' | 'pixKey' | 'pixOwner'> & Partial<Pick<Profile, 'photoUrl' | 'saleAlertTemplate'>> {
  if (!value || typeof value !== 'object') throw new Error('Dados de perfil inválidos.');
  const source = value as Record<string, unknown>;
  function field(name: string, max: number) {
    if (typeof source[name] !== 'string' || source[name].length > max) throw new Error('Confira os dados do perfil.');
    return source[name].trim();
  }
  const name = field('name', 120), email = field('email', 160), phone = field('phone', 40), pixType = field('pixType', 10) as PixType, pixKey = field('pixKey', 180), pixOwner = field('pixOwner', 120);
  if (!name) throw new Error('Informe seu nome.');
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Informe um e-mail válido.');
  if (!Object.hasOwn(pixLabels, pixType)) throw new Error('Selecione um tipo de chave PIX válido.');
  if (pixType || pixKey || pixOwner) {
    if (!pixType || !pixKey || !pixOwner) throw new Error('Preencha o tipo, a chave PIX e o nome do titular.');
    const digits = pixKey.replace(/\D/g, '');
    if (pixType === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(pixKey)) throw new Error('A chave PIX deve ser um e-mail válido.');
    if (pixType === 'cpf' && (digits.length !== 11 || /^(\d)\1+$/.test(digits))) throw new Error('Informe um CPF com 11 dígitos.');
    if (pixType === 'cnpj' && (digits.length !== 14 || /^(\d)\1+$/.test(digits))) throw new Error('Informe um CNPJ com 14 dígitos.');
    if (pixType === 'phone' && ![10, 11, 12, 13].includes(digits.length)) throw new Error('Informe um telefone PIX válido, com DDD.');
    if (pixType === 'random' && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(pixKey)) throw new Error('Informe uma chave aleatória PIX válida.');
  }
  const extra: Partial<Pick<Profile, 'photoUrl' | 'saleAlertTemplate'>> = {};
  if (source.photoUrl !== undefined) {
    if (typeof source.photoUrl !== 'string') throw new Error('A foto de perfil é inválida.');
    extra.photoUrl = validateAvatar(source.photoUrl);
  }
  if (source.saleAlertTemplate !== undefined) {
    if (typeof source.saleAlertTemplate !== 'string' || !source.saleAlertTemplate.trim() || source.saleAlertTemplate.length > 240) throw new Error('O alerta de venda deve ter de 1 a 240 caracteres.');
    if (/\{(?!valor\}|qtd\}|nome\})[^}]*\}/.test(source.saleAlertTemplate)) throw new Error('Use {valor}, {qtd} e {nome} como variáveis do alerta.');
    extra.saleAlertTemplate = source.saleAlertTemplate.trim();
  }
  return { name, email, phone, pixType, pixKey, pixOwner, ...extra };
}
export function demoInitial(): DemoData {
  return { version: 1, settlementVersion: 1, profile: { id: 'demo', name: 'Atendente de demonstração', email: '', phone: '', pixType: '', pixKey: '', pixOwner: '', commissionBps: DEFAULT_COMMISSION_BPS, photoUrl: '', saleAlertTemplate: DEFAULT_SALE_ALERT }, sales: [], payouts: [], costs: [], receipts: {} };
}
export const demoCheckouts: Checkout[] = [{ id: 'main', name: 'Checkout principal', ...CHECKOUT_PIX_TARIFF }, { id: 'pix', name: 'PIX manual', ...MANUAL_PIX_TARIFF }, { id: 'buckpay', name: 'Checkout Buckpay', ...BUCKPAY_TARIFF }];
export function demoPortal(data: DemoData, period: Period): Portal {
  const today = businessToday();
  return { profile: data.profile, checkouts: demoCheckouts, sales: data.sales.filter(sale => inPeriod(sale.date, period, today)).sort((a, b) => b.createdAt.localeCompare(a.createdAt)), payouts: data.payouts, finance: calculateFinance(data.sales, data.costs, data.payouts, period, today, data.profile.accountKind), today };
}
